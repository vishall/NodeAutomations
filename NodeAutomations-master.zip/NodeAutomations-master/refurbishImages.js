// Please don't use this automation until you are sure about this code
var beautify = require('js-beautify');
var fs = require('fs');
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};
var recursive = require('recursive-readdir');

var newPathsContainer = [],
    conditionNewArray = [],
    conditionRefurbArray = [];
recursive('D:/kanban_new/productCatalogueData_Master/catalogueData/device/dongles', function(err, files) {
    var allJsonFiles = files.filter(function(file) {
        return file.substr(-5) === '.json';
    });
    allJsonFiles.forEach(function(file) {
        checkStandard(file);
        if (json["condition"] == "Refurb" || json["model"].toLowerCase().indexOf("offer") >= 0 || json["model"].toLowerCase().indexOf("refurb") >= 0) {
            conditionRefurbArray.push(file);
        } else {
            conditionNewArray.push(file);
        }
    });
    var conditionNewFile = conditionNewArray.toString().split(",").sort(function(a, b) {
        return b - a
    });
    var conditionRefurbFile = conditionRefurbArray.toString().split(",").sort(function(a, b) {
        return b - a
    });
    if (conditionRefurbFile.length > 0)
        imageChecker(conditionRefurbFile, conditionNewFile);
});

function imageChecker(conditionRefurbFile, conditionNewFile) {
    for (var refurb = 0; refurb < conditionRefurbFile.length; refurb++) {
        var refurbImages, setFlag = false;
        var imagePath = conditionRefurbFile[refurb].substr(0, conditionRefurbFile[refurb].lastIndexOf("\\")).replace("\\", "/");
        checkStandard(conditionRefurbFile[refurb]);
        var refurnJson = json;
        var refurnModel = refurnJson["model"].toLowerCase().toString();
        for (var newDevice = 0; newDevice < conditionNewFile.length; newDevice++) {
            checkStandard(conditionNewFile[newDevice]);
            var updatedPath = conditionNewFile[newDevice].substr(conditionNewFile[newDevice].substr(0, conditionNewFile[newDevice].lastIndexOf("\\")).lastIndexOf("\\"), conditionNewFile[newDevice].length);
            updatedPath = updatedPath.substr(0, updatedPath.lastIndexOf("\\")).replace(/\\/g, '/') + "/";
            model = json["model"].toLowerCase().toString();
            if (refurnModel.indexOf(model) >= 0 && refurnJson["brand"] == json["brand"]) {
                var imagesArray = ["listSingle", "listHalf", "listDouble", "details", "tariff", "basket", "side", "back"];
                for (var img = 0; img < imagesArray.length; img++) {
                    if (refurnJson["images"]["standard"][imagesArray[img]]) {
                        if (refurnJson["images"]["standard"][imagesArray[img]].indexOf("image") === -1) {
                            refurnJson["images"]["standard"][imagesArray[img]] = "" + "${image('" + updatedPath + refurnJson["images"]["standard"][imagesArray[img]] + "')}";
                        } else {
                            var arr = refurnJson["images"]["standard"][imagesArray[img]].toString().split("\'");
                            refurnJson["images"]["standard"][imagesArray[img]] = "" + "${image('" + updatedPath + arr[1] + "')}";
                        }
                    }
                }
                recursive(imagePath, function(err, files) {
                    var allRefurbImages = files.filter(function(file) {
                        return file.substr(-4) === '.png' || file.substr(-4) === '.jpg';
                    });
                    refurbImages = allRefurbImages.toString().split(",");
                    for (var deleteFile = 0; deleteFile < refurbImages.length; deleteFile++) {
                        fs.unlink(refurbImages[deleteFile], function(err) {
                            if (err) {
                                return console.error(err);
                            }
                        });
                    }
                });
                break;
            }
        }
        if (setFlag) {

        }
        console.log(refurnJson["model"] + " updated")
        var fileNewContent = JSON.stringify(refurnJson);
        convertBacktoOriginalState(fileNewContent, conditionRefurbFile[refurb], newPathsContainer);
    }
}

function checkStandard(file) {
    var content = require(file);
    var newContent = content;
    var newSearch = newContent.match(pathRegExp);
    if (newSearch != null) {
        var uniqueArray = newSearch.filter(function(elem, pos) {
            return newSearch.indexOf(elem) == pos;
        });
        for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
            var planPathValue = '"' + uniqueArray[jCount] + '"';
            var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
            newPathsContainer.push(uniqueArray[jCount]);
            newContent = newContent.replace(regExpCheck, planPathValue);
            var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
        }
        json = JSON.parse(newContent);
    } else {
        json = JSON.parse(newContent);
    }
    return json;
}

function writeToFile(file, content) {
    fs.writeFile(file, content, function(err) {
        if (err) {
            console.log(err);
        }
    });
}

function convertBacktoOriginalState(newContent, file, newPathsContainer) {
    var originalState;
    newContent = beautify(newContent, {
        indent_size: 3,
        "preserve_newlines": false,
        "keep_array_indentation": true
    });
    for (var jCount = 0; jCount < newPathsContainer.length; jCount++) {
        var oldPathValue = '"' + newPathsContainer[jCount] + '"';
        var regExpCheck = new RegExp(escapeRegExp(oldPathValue), "g");
        newContent = newContent.replace(regExpCheck, newPathsContainer[jCount]);
    }
    writeToFile(file, newContent);
}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}