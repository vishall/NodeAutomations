//THis is for checking Duplicates GUIDs
var fs = require('graceful-fs');
var colors = require('colors');

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');
var guid_Collection = [],
    guIDDupliactes = [],
    guidArray = [],
    idWithSpace = [],
    lead_guid_collection = [],
    leadGuidArray = [],
	skuWithSpace = [];
var xters;
var regExp = /"id"(((\s*)(:|=)(\s*)))(((.|\n)[^,\r](?!((.+?)(:|=))))+)/;
var regExp1 = /"leadModelInFamily"(((\s*)(:|=)(\s*)))(((.|\n)[^,\r](?!((.+?)(:|=))))+)/;
var skuRegExp = /"code"(((\s*)(:|=)(\s*)))(((.|\n)[^,\r](?!((.+?)(:|=))))+")/;
var cataloguepath = process.argv[2];

recursive(cataloguepath, function(err, files) {
    var fileCount = 0;
    var index = 0;
    var myArray = [],
        myArray1 = [],
		skuArray = [];
    guid_Collection = [], guIDDupliactes = [],skuCollection = [];
    files.filter(function(file) {
            return file.substr(-5) === '.json';
        })
        .forEach(function(file) {
            var xters = require(file);
            myArray = xters.match(regExp);
            myArray1 = xters.match(regExp1);
			skuArray = xters.match(skuRegExp);
            index++;
            if (myArray != null) {
                var obj = {
                    name: file,
                    id: myArray[0]
                }
                guid_Collection.push(myArray[0]);
            }
            if (myArray1 != null) {
                var obj = {
                    name: file,
                    id: myArray1[0]
                }
                lead_guid_collection.push(myArray1[0]);
            }if (skuArray != null) {
                var obj = {
                    name: file,
                    id: skuArray[0]
                }
                skuCollection.push(skuArray[0]);
            }
        })
    for (var i = 0; i < guid_Collection.length; i++) {
        var arr = guid_Collection[i].toString().split(":");
        guidArray.push(arr[1].substring(arr[1].indexOf("\""),arr[1].length));
    }
    verifyGUIDEntry(guidArray);    
    for (var i = 0; i < lead_guid_collection.length; i++) {
        var arr = lead_guid_collection[i].toString().split(":");
        leadGuidArray.push(arr[1].substring(arr[1].indexOf("\""),arr[1].length));
    }
    checkSpace(guidArray);
    checkSpace(leadGuidArray);
	for (var i = 0; i < skuCollection.length; i++) {
        var arr = skuCollection[i].toString().split(":");
        skuWithSpace.push(arr[1].substring(arr[1].indexOf("\""),arr[1].length));
    }
	checkSpace(skuWithSpace);
    if (idWithSpace.length > 0 || guIDDupliactes.length > 0){
        console.log('\x1b[31m%s\x1b[0m: ',"Extra space found in " + idWithSpace.length + " GUID/SKU please check: " + idWithSpace + "& There are " + guIDDupliactes.length+ " duplicate GUID found in prodcatlog: " + guIDDupliactes);
		process.exit(1);
		}
});


function verifyGUIDEntry(guidArray) {
    var sorted_arr = guidArray.slice().sort();
    for (var i = 0; i < guidArray.length - 1; i++) {
        if (sorted_arr[i + 1] == sorted_arr[i]) {
            guIDDupliactes.push(sorted_arr[i]);
        }
    }
}

function checkSpace(leadGuidArray) {
    for (var i = 0; i < leadGuidArray.length - 1; i++) {
        if (/\s/g.test(leadGuidArray[i])) {
            idWithSpace.push(leadGuidArray[i])
        }
    }
}
function checkSpace(leadGuidArray) {
    for (var i = 0; i < leadGuidArray.length - 1; i++) {
        if (/\s/g.test(leadGuidArray[i])) {
            idWithSpace.push(leadGuidArray[i])
        }
    }
}
