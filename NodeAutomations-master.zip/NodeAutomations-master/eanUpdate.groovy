#!/usr/bin/env groovy

@Grab(group="com.fasterxml.jackson.core", module = "jackson-databind", version="2.4.4")
import com.fasterxml.jackson.databind.*
import com.fasterxml.jackson.core.util.*
import com.fasterxml.jackson.core.JsonGenerator
import com.fasterxml.jackson.core.JsonFactory
import com.fasterxml.jackson.core.io.IOContext

import groovy.io.FileType

import java.util.regex.Matcher
import java.util.regex.Pattern

println '''
This script read EAN to sku mapping from csv file and updates EANs in devices and accessories
Needs two inputs ->

input 1 -> <base directory of data repository>/catalogueData 
input 2 -> full path to EAN-SKU csv file


D:/IdeaProjects/productCatalogueData_Master2/catalogueData
D:/NodeAutomations-master/NodeAutomations-master/EAN 05-07-2017.csv
'''

File rootDataDirectory = new File('D:/IdeaProjects/productCatalogueData_Master2/catalogueData')
File eanToSkuCsvFile = new File('D:/NodeAutomations-master/NodeAutomations-master/EAN 05-07-2017.txt')

println 'Reading csv file '+ eanToSkuCsvFile.getName()
Map skuToEanMap = EanUtils.getSkuToEANMap(eanToSkuCsvFile)
println 'Reading csv file done'

new File(rootDataDirectory, "device").eachFileRecurse(FileType.FILES) { File dataFile ->
    if (dataFile.name.endsWith(".json")) {
        EanUtils.updateDataFile(dataFile, skuToEanMap)
    }
}

new File(rootDataDirectory, "accessories").eachFileRecurse(FileType.FILES) { File dataFile ->
    if (dataFile.name.endsWith(".json")) {
        EanUtils.updateDataFile(dataFile, skuToEanMap)
    }
}

println '=======completed========='

class EanUtils {
    static ObjectMapper objectMapper = new ObjectMapper()
    static ObjectMapper stringMapper = new ObjectMapper(new Factory())
    static {
        stringMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
    }
    def static updateDataFile(File dataFile, Map skuToEanMap) {

        def dataString = dataFile.text
        def savedStrings = [:]

        def regex = "(\\\$[^\\}]*\\})"
        Pattern pattern = Pattern.compile(regex)
        Matcher matcher = pattern.matcher(dataString)

        while(matcher.find()) {
            def existingString = matcher.group(1)
            String random = "\"RANDOM-" + new Random().nextInt().toString() + "\""
            savedStrings[random] = existingString
            dataString = dataString.replace(existingString, random)
        }

        def dataMap = objectMapper.readValue(dataString, Map)

        if(dataMap.sku?.code && skuToEanMap.containsKey(dataMap.sku.code)){
            dataMap.ean = skuToEanMap.get(dataMap.sku.code)

            StringWriter result = new StringWriter()
            stringMapper.writeValue(result, dataMap)
            def updatedDataString = result.toString()

            savedStrings.each {
                updatedDataString = updatedDataString.replace(it.key as String, it.value as String)
            }

            dataFile.withWriter {Writer writer->
                writer.write(updatedDataString)
            }
        }
    }

    def static getSkuToEANMap(File eanToSkuCsvFile) {
        def skuToEANMap = [:]
        eanToSkuCsvFile.readLines().each {line ->
            skuToEANMap.put(line.split(",")[2], line.split(",")[0])
        }
        return skuToEANMap
    }
}

class Factory extends JsonFactory {
    @Override
    protected JsonGenerator _createGenerator(Writer out, IOContext ctxt) throws IOException {
        return super._createGenerator(out, ctxt).setPrettyPrinter(getPrettyPrinter());
    }

    def getPrettyPrinter () {
        DefaultPrettyPrinter defaultPrettyPrinter = new DefaultPrettyPrinter ()
        defaultPrettyPrinter.withArrayIndenter(DefaultPrettyPrinter.Lf2SpacesIndenter.instance)
    }
}