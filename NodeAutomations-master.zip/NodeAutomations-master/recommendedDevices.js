var beautify = require('js-beautify');
var fs = require('fs');
//var prettyjson = require('prettyjson');
var options = {
  noColor: true
};

require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

var deviceDetailsCol = [], modifiedFileCount =0;


recursive('C:/Idea/productCatalogueData_Master/catalogueData/', function (err, files) {
	var recommendedDevicesFile = 'C:/Idea/productCatalogueData_Master/catalogueData/recommendedDevices/recommendedDevices.json',
    var jsonFileCount = 0, jsonFilesIndex = 0;
    var json;
    console.log(files.length);
	"phones" :[abc]
	var recommendedDevicesFileString =recommendedDevicesFile.toString();
	for(var count=0; count++)
	var devicePathsObject = accyAssociationContainer[count]["phones"];
	//console.log(devicePathsObject);
    for(var devicePathsObjectCount= 0;devicePathsObjectCount<devicePathsObject.length;devicePathsObjectCount++){
        accyJSON["byFamily"]["phones"]="";
       //console.log("${linkTo('"+devicePathsObject[devicePathsObjectCount]["url"]+"')}");
        newPathsContainer.push("${linkTo('"+devicePathsObject[devicePathsObjectCount]["url"]+"')}");
		
    }
    console.log("-------------------");
    //console.log(newPathsContainer);
     var fileNewContent = JSON.stringify(accyJSON);
     convertBacktoOriginalState(fileNewContent,file,newPathsContainer);

	
    //var htmlArray =jsonFiles
               //     .toString();
                    
    //console.log(htmlArray);
    
    //var htmlArray = htmlArray.split(",");
    //console.log(htmlArray[1]);
	
    fs.readFile(recommendedDevicesFile, 'utf8', function (err,data) {
      if (err) {
        return console.log(err);
      }
  
           
    });

});