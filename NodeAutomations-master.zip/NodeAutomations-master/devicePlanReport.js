// Please don't use this automation until you are sure about this code
var fs = require('graceful-fs');
var excelbuilder = require('excel4node');
var pathRegExp = /\$\{(.*?)\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};
var recursive = require('recursive-readdir');

var newPathsContainer = [],
    conditionNewArray = [],
    conditionRefurbArray = [],
    deviceDetailsCol = [],
    jsonFilesIndex = 0;
prodcatlogPath = 'D:/IdeaProjects/productCatalogueData_Master2/catalogueData/';
recursive(prodcatlogPath + 'device', function(err, files) {
    var allJsonFiles = files.filter(function(file) {
        return file.substr(-5) === '.json';
    });
    deviceDetailsCol = [];
    allJsonFiles.forEach(function(file) {
        checkStandard(file);
        //console.log(file);
        var deviceJSON = json;
                if (deviceJSON["relationships"]) {
                    for (var plan = 0; plan < deviceJSON["relationships"].length; plan++) {
                        if (deviceJSON["relationships"][plan]["prices"] && deviceJSON["relationships"][plan]["prices"][0]["monthly"]) {
                            var temp = deviceJSON["relationships"][plan]["id"].toString().split("\'");
                            file = prodcatlogPath + temp[1].trim();
                            checkStandard(file);
                            deviceJSON["relationships"][plan]["id"] = json["id"];
                            deviceJSON["relationships"][plan]["AirtimePrice"] = json["price"];
                            deviceJSON["relationships"][plan]["commitmentLength"] = json["commitmentLength"];
                        }
                    }
                }
        deviceDetails(deviceJSON);
        jsonFilesIndex++;
        if (allJsonFiles.length === jsonFilesIndex) {
            generateExcelFile(deviceDetailsCol);
        }
    });
});

function deviceDetails(deviceJSON) {
    if (deviceJSON["classification"]) {
        if (deviceJSON["classification"]["memory"]) {
            if (deviceJSON["relationships"]) {
                for (var plan = 0; plan < deviceJSON["relationships"].length; plan++) {
                    if (deviceJSON["relationships"][plan]["prices"] && deviceJSON["relationships"][plan]["prices"].length > 1) {
                        for (var monthly = 0; monthly < deviceJSON["relationships"][plan]["prices"].length; monthly++) {
                            var deviceObj = {
                                "guid": deviceJSON["id"],
                                "brand": deviceJSON["brand"],
                                "model": deviceJSON["model"],
                                "memory": deviceJSON["classification"]["memory"]["display"],
                                "planId": deviceJSON["relationships"][plan]["id"],
                                "costToO2": deviceJSON["costToO2"],
                                "duration": deviceJSON["relationships"][plan]["commitmentLength"],
                                "MonthlyDevicePrice": deviceJSON["relationships"][plan]["prices"][monthly]["monthly"],
                                "AirtimePrice": deviceJSON["relationships"][plan]["AirtimePrice"],
                                "cashPrice": deviceJSON["cashPrice"],
                                "DeviceUpfrontCost": deviceJSON["relationships"][plan]["prices"][monthly]["oneOff"],
                                "stockInfo": deviceJSON["stockInfo"]["stock"],
                                "consumerNew": deviceJSON["channelPermissions"]["ConsumerNew"],
                                "consumerUpgrade": deviceJSON["channelPermissions"]["ConsumerUpgrade"],
                                "voiceNew": deviceJSON["channelPermissions"]["VoiceNew"],
                                "voiceUpgrade": deviceJSON["channelPermissions"]["VoiceUpgrade"],
                                "lifecycle": deviceJSON["lifecycle"]["status"]
                            }
                            deviceDetailsCol.push(deviceObj);
                        }
                    }
                }
            }
        }
    }
}

function checkStandard(file) {
    var content = require(file);
    var newContent = content;
    var newSearch = newContent.match(pathRegExp);
    if (newSearch != null) {
        var uniqueArray = newSearch.filter(function(elem, pos) {
            return newSearch.indexOf(elem) == pos;
        });
        for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
            var planPathValue = '"' + uniqueArray[jCount] + '"';
            var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
            newPathsContainer.push(uniqueArray[jCount]);
            newContent = newContent.replace(regExpCheck, planPathValue);
            var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
        }
        json = JSON.parse(newContent);
    } else {
        json = JSON.parse(newContent);
    }
    return json;
}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function generateExcelFile(collection) {
    var wb = new excelbuilder.WorkBook();
    var wbOpts = {
        jszip: {
            compression: 'DEFLATE'
        }
    }
    var wb2 = new excelbuilder.WorkBook(wbOpts);
    var ws = wb.WorkSheet('devices');
    var wsOpts = {
        margins: {
            left: .75,
            right: .75,
            top: 1.0,
            bottom: 1.0,
            footer: .5,
            header: .5
        },
        printOptions: {
            centerHorizontal: true,
            centerVertical: false
        },
        view: {
            zoom: 100
        },
        outline: {
            summaryBelow: true
        }
    }
    var ws2 = wb.WorkSheet('devices', wsOpts);
    ws.Cell(1, 1).String('GUID');
    ws.Cell(1, 2).String('Brand');
    ws.Cell(1, 3).String('DeviceName');
    ws.Cell(1, 4).String('Memory');
    ws.Cell(1, 5).String('PlanId');
    ws.Cell(1, 6).String('CostToO2');
    ws.Cell(1, 7).String('Duration');
    ws.Cell(1, 8).String('MonthlyDevicePrice');
    ws.Cell(1, 9).String('AirtimePrice');
    ws.Cell(1, 10).String('CashPrice');
    ws.Cell(1, 11).String('DeviceUpfrontCost');
    ws.Cell(1, 12).String('StockInfo');
    ws.Cell(1, 13).String('ConsumerNew');
    ws.Cell(1, 14).String('ConsumerUpgrade');
    ws.Cell(1, 15).String('VoiceNew');
    ws.Cell(1, 16).String('VoiceUpgrade');
    ws.Cell(1, 17).String('lifecycle');
    for (var skuCountLength = 0; skuCountLength < collection.length; skuCountLength++) {
        var row = skuCountLength + 2;
        ws.Cell(row, 1).String(collection[skuCountLength]["guid"]);
        ws.Cell(row, 2).String(collection[skuCountLength]["brand"]);
        ws.Cell(row, 3).String(collection[skuCountLength]["model"]);
        ws.Cell(row, 4).String(collection[skuCountLength]["memory"]);
        ws.Cell(row, 5).String(collection[skuCountLength]["planId"]);
        ws.Cell(row, 6).String(collection[skuCountLength]["costToO2"]);
        ws.Cell(row, 7).String(collection[skuCountLength]["duration"]);
        ws.Cell(row, 8).String(collection[skuCountLength]["MonthlyDevicePrice"]);
        ws.Cell(row, 9).String(collection[skuCountLength]["AirtimePrice"]);
        ws.Cell(row, 10).String(collection[skuCountLength]["cashPrice"]);
        ws.Cell(row, 11).String(collection[skuCountLength]["DeviceUpfrontCost"]);
        ws.Cell(row, 12).String(collection[skuCountLength]["stockInfo"]);
        ws.Cell(row, 13).String(collection[skuCountLength]["consumerNew"]);
        ws.Cell(row, 14).String(collection[skuCountLength]["consumerUpgrade"]);
        ws.Cell(row, 15).String(collection[skuCountLength]["voiceNew"]);
        ws.Cell(row, 16).String(collection[skuCountLength]["voiceUpgrade"]);
        ws.Cell(row, 17).String(collection[skuCountLength]["lifecycle"]);
    }
    ws.Row(1).Height(30);
    ws.Column(1).Width(50);
    var myStyle = wb.Style();
    myStyle.Font.Bold();
    myStyle.Font.Italics();
    myStyle.Font.Family('Times New Roman');
    myStyle.Font.Color('FF0000');
    myStyle.Fill.Color('CCCCCC');
    ws.Cell(1, 1).Style(myStyle);
    ws.Cell(1, 2).Style(myStyle);
    ws.Cell(1, 3).Style(myStyle);
    ws.Cell(1, 4).Style(myStyle);
    ws.Cell(1, 5).Style(myStyle);
    ws.Cell(1, 6).Style(myStyle);
    ws.Cell(1, 7).Style(myStyle);
    ws.Cell(1, 8).Style(myStyle);
    ws.Cell(1, 9).Style(myStyle);
    ws.Cell(1, 10).Style(myStyle);
    ws.Cell(1, 11).Style(myStyle);
    ws.Cell(1, 12).Style(myStyle);
    ws.Cell(1, 13).Style(myStyle);
    ws.Cell(1, 14).Style(myStyle);
    ws.Cell(1, 15).Style(myStyle);
    ws.Cell(1, 16).Style(myStyle);
    ws.Cell(1, 17).Style(myStyle);
    wb.write("ExcelOutput/CreditDrildownreport_01-03-2017.xlsx", function(err) {
        console.log("done");
    });

}