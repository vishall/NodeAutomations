var beautify = require('js-beautify');
var fs = require('fs');
var prettyjson = require('prettyjson');
var options = {
  noColor: true
};

    merchPricesSheetURL = 'ExcelOutput/NewTariffAutomationSheet_04_08_2017.xlsx',
	priorityCell = 'A'
	deviceIdCell = 'B',
	pidCell = 'C',
	upfrontCell = 'D',
	additionalRCell = 'E',
	secondaryRCell = 'F',
	primaryCell = 'G',
	includedCell1 = 'H',
	includedCell2 = 'I',
	includedCell3 = 'J',
    payGTab_Min_Count = 1,payGTab_Max_Count = 6;
    
    var XLSX = require('xlsx'),excelbuilder = require('excel4node');


function loadPayGSKUPrices(){
    try{
        cashPriceCollection = [], paygPriceCollection = [];
        var workbook = XLSX.readFile(merchPricesSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading merchandising Pricing Sheet...");
        console.log(sheet_name_list);
        
        sheet_name_list.forEach(function(y) {
            
         if( y === "Sheet1"){
			 
          var worksheet = workbook.Sheets[y];
          for (z in worksheet) {
			  
              if(payGTab_Min_Count <= payGTab_Max_Count){
                  if(z[0] === '!') continue;
                  var priority = priorityCell+payGTab_Min_Count;
                  var deviceId = deviceIdCell+payGTab_Min_Count;
                  var upfront = upfrontCell+payGTab_Min_Count;
                  var pid = pidCell+payGTab_Min_Count;
                  var additionalR = additionalRCell+payGTab_Min_Count;
                  var secondaryR = secondaryRCell+payGTab_Min_Count;
                  var primary = primaryCell+payGTab_Min_Count;
                  var included1 = includedCell1+payGTab_Min_Count;
                  var included2 = includedCell2+payGTab_Min_Count;
                  var included3 = includedCell3+payGTab_Min_Count;
                  
			
				
                  var priceDeatils = {
                     "priority": worksheet[priority].v,
					 "deviceId": worksheet[deviceId].v,
                     "upfront": worksheet[upfront].v,
                     "pid": worksheet[pid].v,
                     "additionalR": worksheet[additionalR].v,
                     "secondaryR": worksheet[secondaryR].v,
                     "primary": worksheet[primary].v,
                     "included": [ worksheet[included1].v,worksheet[included2].v,worksheet[included3].v]
					 }
                  paygPriceCollection.push(priceDeatils);
                  //console.log(paygPriceCollection);
                  payGTab_Min_Count++;  
				  
             }
          }
         }
       });
  }
  catch(e){
        console.log("Oops.......");
        console.log("Something is wrong with Merch Price sheet");
        console.log(e);
  }
}




require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

var deviceDetailsCol = [], modifiedFileCount =0;




function addCnCFlag(){
loadPayGSKUPrices();
console.log(paygPriceCollection.length);
var tariffupsellpath = "D:/IdeaProjects/productCatalogueData_Master2/catalogueData/media/attachments/common/tariffUpsell.txt"
	
 	    fs.readFile(tariffupsellpath, 'utf8', function (err,data) {
			var myFlag = true;
			for(key in paygPriceCollection){
				myFlag = true;
				
				
      if (err) {
        return console.log(err);
      }
        data = JSON.parse(data);
		
         var objectLen = Object.keys(data).length;
        for (var x in data) { 
		
  if(data[x].deviceId==paygPriceCollection[key].deviceId){

			for (var y in data[x].tariffRows){
				

	if(data[x].tariffRows[y].planId == paygPriceCollection[key].pid && data[x].tariffRows[y].upfrontCostInPence == paygPriceCollection[key].upfront){	
				
		if(paygPriceCollection[key].additionalR!="NA" && paygPriceCollection[key].additionalR!="na" && paygPriceCollection[key].additionalR!="undefined" ){
				data[x].tariffRows[y].additional = paygPriceCollection[key].additionalR;
				
				}
		if(paygPriceCollection[key].secondaryR!="NA" && paygPriceCollection[key].secondaryR!="na" && paygPriceCollection[key].secondaryR!="undefined" ){
				data[x].tariffRows[y].secondary = paygPriceCollection[key].secondaryR;
				
				}
		if(paygPriceCollection[key].primary!="NA" && paygPriceCollection[key].primary!="na" && paygPriceCollection[key].primary!="undefined" ){
				data[x].tariffRows[y].primary = paygPriceCollection[key].primary;
				
				}
		if(paygPriceCollection[key].included!="NA" && paygPriceCollection[key].included!="na" && paygPriceCollection[key].included!="undefined" ){
				data[x].tariffRows[y].included = paygPriceCollection[key].included;
				
				}
		console.log(data[x].deviceId);
				}
       
	}
  }else if(myFlag) { 
		myFlag = false;
		//console.log(paygPriceCollection[key].deviceId);

		}
	
        }
		
          
     data=JSON.stringify(data);
        //console.log(data);
       data = beautify(data, { indent_size: 2 }); 
       writeToFile(tariffupsellpath,data);      
    }
    }); 
   }





function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}



function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } 
	else{console.log("modified");}
});
     
}
addCnCFlag();