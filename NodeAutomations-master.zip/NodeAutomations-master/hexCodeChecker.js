// Please don't use this automation until you are sure about this code
var beautify = require('js-beautify');
var fs = require('fs');
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};
var recursive = require('recursive-readdir');

var newPathsContainer = [], conditionNewArray = [], conditionRefurbArray = [];
recursive('C:/Kanban/Kanban/catalogueData/device/sony', function(err, files) {
	var allJsonFiles = files.filter(function(file) {
		if(file.indexOf("device\tablets") < 0)
			return file.substr(-5) === '.json';
    });
   allJsonFiles.forEach(function(file) {
		checkStandard(file);
		if(json["condition"]=="New" && json["classification"]){
			conditionNewArray.push(file);
			}
		else if(json["condition"]=="Refurb" && json["classification"]){
			conditionRefurbArray.push(file);
		}
	});
	 var conditionNewFile = conditionNewArray.toString().split(",");
	 var conditionRefurbFile = conditionRefurbArray.toString().split(",");
	 if(conditionRefurbFile.length>0)
		hexCodeChecker(conditionRefurbFile,conditionNewFile);
});

function hexCodeChecker(conditionRefurbFile,conditionNewFile){
	for(var refurb =0; refurb <conditionRefurbFile.length;refurb++){
		var refurbFile = conditionRefurbFile[refurb];
		checkStandard(conditionRefurbFile[refurb]);
		var refurnJson = json;
		var refurnModel=refurnJson["model"].toLowerCase().toString();
			for (var newDevice = 0;newDevice < conditionNewFile.length;newDevice++){
				checkStandard(conditionNewFile[newDevice]);
				if(json["classification"]){
					model=json["model"].toLowerCase().toString();
					if(refurnModel.indexOf(model) >= 0){
						refurnJson["classification"]["colour"]["primary"] = json["classification"]["colour"]["primary"];
					}
				}
			}
		var fileNewContent = JSON.stringify(refurnJson);
			convertBacktoOriginalState(fileNewContent, refurbFile, newPathsContainer);
	}
}

function checkStandard(file) {
    var content = require(file);
    var newContent = content;
    var newSearch = newContent.match(pathRegExp);
    if (newSearch != null) {
        var uniqueArray = newSearch.filter(function(elem, pos) {
            return newSearch.indexOf(elem) == pos;
        });
        for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
            var planPathValue = '"' + uniqueArray[jCount] + '"';
            var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
            newPathsContainer.push(uniqueArray[jCount]);
            newContent = newContent.replace(regExpCheck, planPathValue);
            var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
        }
        json = JSON.parse(newContent);
    } else {
        json = JSON.parse(newContent);
    }
    return json;
}

function writeToFile(file, content) {
    fs.writeFile(file, content, function(err) {
        if (err) {
            console.log(err);
        }
    });
}

function convertBacktoOriginalState(newContent, file, newPathsContainer) {
    var originalState;
    newContent = beautify(newContent, {
        indent_size: 3,
        "preserve_newlines": false,
        "keep_array_indentation": true
    });
    for (var jCount = 0; jCount < newPathsContainer.length; jCount++) {
        var oldPathValue = '"' + newPathsContainer[jCount] + '"';
        var regExpCheck = new RegExp(escapeRegExp(oldPathValue), "g");
        newContent = newContent.replace(regExpCheck, newPathsContainer[jCount]);
    }
    writeToFile(file, newContent);
}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}