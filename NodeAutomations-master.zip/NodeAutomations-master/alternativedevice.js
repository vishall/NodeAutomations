var beautify = require('js-beautify');
var fs = require('fs');
var prettyjson = require('prettyjson');
var options = {
  noColor: true
};

    merchPricesSheetURL = 'ExcelOutput/Related_Product.xlsx',
    payGSKUCellColumn = 'A',alternativeDevices1 = 'B',alternativeDevices2 = 'C',alternativeDevices3 = 'D',alternativeDevices4 = 'E',
    payGTab_Min_Count = 1,payGTab_Max_Count =27;
    
    var XLSX = require('xlsx'),excelbuilder = require('excel4node');


function loadPayGSKUPrices(){
    try{
        cashPriceCollection = [], paygPriceCollection = [];
        var workbook = XLSX.readFile(merchPricesSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading merchandising Pricing Sheet...");
        //console.log(sheet_name_list);
        
        sheet_name_list.forEach(function(y) {
            
         if( y === "Sheet1"){
          var worksheet = workbook.Sheets[y];
		 
          for (z in worksheet) {
			  //console.log(workbook.Sheets[y]);
              if(payGTab_Min_Count <= payGTab_Max_Count){
                  if(z[0] === '!') continue;
                  var skuCell = payGSKUCellColumn+payGTab_Min_Count;
				  //console.log(alternativeDevices1);
                  var alternative1 = alternativeDevices1+payGTab_Min_Count;
				  var alternative2 = alternativeDevices2+payGTab_Min_Count;
				  var alternative3 = alternativeDevices3+payGTab_Min_Count;
				  var alternative4 = alternativeDevices4+payGTab_Min_Count;
				  
					if(worksheet[alternative1].v % 1 == 0){
						//console.log(worksheet[alternative4].v);
						worksheet[alternative1].v = worksheet[alternative1].v.toFixed(2);
						//console.log("updated : "+worksheet[alternative4].v);
					}
				//console.log(alternative1);
                  var priceDeatils = {
                     "sku": worksheet[skuCell].v,
                     "alternativeDevices1": worksheet[alternative1].v,
                     "alternativeDevices2": worksheet[alternative2].v,
                     "alternativeDevices3": worksheet[alternative3].v,
                     "alternativeDevices4": worksheet[alternative4].v
                  }
                  paygPriceCollection.push(priceDeatils);
                  
                  payGTab_Min_Count++; 
             }
          }
         }
       });
  }
  catch(e){
        console.log("Oops.......");
        console.log("Something is wrong with Merch Price sheet");
        console.log(e);
  }
}




require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

var deviceDetailsCol = [], modifiedFileCount =0;

recursive('D:/IdeaProjects/productCatalogueData_Master2/catalogueData/device/tablets/', function (err, files) {
    
    var jsonFileCount = 0, jsonFilesIndex = 0;
    var json;
    console.log(files.length);
    var jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
    deviceDetailsCol =[];
    loadPayGSKUPrices();
    jsonFiles.forEach(function(file) {
        var content =  require(file);
       // console.log(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        //if(json["id"] == "8281864e-faf7-4d28-86d1-5346b64f1c7cdvsd")
        addCnCFlag(json,file,newPathsContainer,paygPriceCollection);
        
    });
});

function addCnCFlag(json,file,newPathsContainer,paygPriceCollection){
var sku = json["sku"]["code"];
    //console.log(paygPriceCollection);
//check the sku id to change the set of plans
   for(key in paygPriceCollection){
   //console.log(paygPriceCollection[key].sku)
    if(sku == paygPriceCollection[key].sku){
         console.log(paygPriceCollection[key].sku)
		if(json["alternativeDevices"]){
            json["alternativeDevices"]=[];
			json["alternativeDevices"].push({"id" : paygPriceCollection[key].alternativeDevices1});
			json["alternativeDevices"].push({"id" : paygPriceCollection[key].alternativeDevices2});
			json["alternativeDevices"].push({"id" : paygPriceCollection[key].alternativeDevices3});
			json["alternativeDevices"].push({"id" : paygPriceCollection[key].alternativeDevices4});
		}
		else{
            //if you want to check how many devices dont have alternative devices
			//json["alternativeDevices"] = "dummmy";
            json["alternativeDevices"]=[];
			json["alternativeDevices"].push({"id" : paygPriceCollection[key].alternativeDevices1});
			json["alternativeDevices"].push({"id" : paygPriceCollection[key].alternativeDevices2});
			json["alternativeDevices"].push({"id" : paygPriceCollection[key].alternativeDevices3});
			json["alternativeDevices"].push({"id" : paygPriceCollection[key].alternativeDevices4});
		}
		
        

    }
   
   }
   
   


	 
    var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent,file,newPathsContainer);

}


function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
        modifiedFileCount++;
        
        //console.log("Modified Files"+modifiedFileCount);
        fs.appendFile("ExcelOutput/log.txt",file+ "\r\n", function(err) {
                if(err) {
                    return console.log(err);
                }
				else{
					
				}
            }); 
    }
	
});
     
}


function convertBacktoOriginalState(newContent,file,newPathsContainer){
    var originalState;
    
    newContent = beautify(newContent, { indent_size: 2 });
    for(var jCount =0;jCount<newPathsContainer.length;jCount++){
               var oldPathValue = '"'+newPathsContainer[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(oldPathValue),"g");
               newContent = newContent.replace(regExpCheck,newPathsContainer[jCount]);
    }
	fs.writeFile("ExcelOutput/log.txt","",function(err) {
		if(err) {return console.log(err);}
	});
    writeToFile(file,newContent);  
    
}