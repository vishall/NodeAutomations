/* This Script will valoidate the Device PayG and Pay Monthly Prices */
/* Please fill the below information before runing the script */

var prodCatURL = 'D:/IdeaProjects/productCatalogueData_Master/catalogueData/',
    dataAllwoanceSheetURL = 'D:/NodeAutomations-master/NodeAutomations-master/ExcelOutput/BoltOnAssociation.xlsx',
    planPids = 'B', iphonePids = 'C', blackberryPids = 'D', smartphonePids = 'A',pidContainer=[],max=49,min=2;

var pidContainerObj = {};

/* Do not modify the below script if you are not sure about the changes*/


var fs = require('fs'), XLSX = require('xlsx'),excelbuilder = require('excel4node'),
         recursive = require('recursive-readdir'),beautify = require('js-beautify'),
         prettyjson = require('prettyjson'),modifiedFileCount =0;
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;



require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

Array.prototype.move = function (old_index, new_index) {
    if (new_index >= this.length) {
        var k = new_index - this.length;
        while ((k--) + 1) {
            this.push(undefined);
        }
    }
    this.splice(new_index, 0, this.splice(old_index, 1)[0]);
    return this; // for testing purposes
};

function showObject(obj) {
  var arrValue = [],arrKey=[],i=0,j=0,objArray={};
  for (var p in obj) {
    if( obj.hasOwnProperty(p) ) {
      arrKey[i++]=p;
       arrValue[j++]=obj[p];
    } 
  } 

  swapPosition(arrKey,arrValue); 
  objArray = convertArrToObj(arrKey,arrValue);
  return objArray;
}

function swapPosition(arrKey,arrValue){
arrKey.move(8,4);
console.log(arrKey);
arrValue.move(8,4);
console.log(arrValue);
}

function convertArrToObj(arrKey,arrValue){
var objArr = {};
for(var j=0; j<arrKey.length; j++){
objArr[arrKey[j]] = arrValue[j];
} 
//console.log(objArr);
return objArr;
}

function loadPids(){
    try{
        var workbook = XLSX.readFile(dataAllwoanceSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading Pids Sheet...");
        console.log(sheet_name_list);
        sheet_name_list.forEach(function(y) {

          if( y === "Smartphone"){
              var worksheet = workbook.Sheets[y];
              for (z in worksheet) {
                  if(min <= max){
                      if(z[0] === '!') continue;
                      // console.log("entered matrix");
                      
                      var plan = planPids+min;
//                      var iphone = iphonePids+min;
//                      var blackberry = blackberryPids+min;
                      var smartphone = smartphonePids+min;
           
                      
            var pidMatrix = {     
                    "plan" : worksheet[plan].v,
                    "smartphone" : worksheet[smartphone].v
//                    "iphone" : worksheet[iphone].v,
//                    "blackberry" : worksheet[blackberry].v
                    
                     };
                      
                    //console.log(pidMatrix); 
                    //console.log(min); 
                       min++;
                     pidContainer.push(pidMatrix);
                      
                  }
              }
          }
              
       });
        
       //console.log(pidContainer);
        addImsID(pidContainer)
        
        
  }
  catch(e){
        console.log("Oops.......");
        console.log("Something is wrong with plan sheet");
        console.log(e);
  }
}

function addImsID(pidContainer){
    //console.log(pidContainer);
    recursive('D:/IdeaProjects/productCatalogueData_Master2/catalogueData/dataAllowanceGroups/', function (err, files) {
          var jsonFileCount = 0, jsonFilesIndex = 0;
    var json;
    //console.log("No of files change: "+files.length);
    var jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
    deviceDetailsCol =[];
    jsonFiles.forEach(function(file) {
        var content =  require(file);
        //console.log(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        
        var objectLen = Object.keys(json.members).length;
        var count = 0;
        console.log(objectLen);
        console.log("pidleng " +pidContainer.length);


        
        for (var z in pidContainer) {
            for(var i=1; i<objectLen; i++){

        count++;
        if (pidContainer[z].smartphone == json["members"][i]["productID"] ) {
        console.log(count+"   "+json["members"][i]["productID"]);
        
            
        json["members"][i]["imsProductID"] = pidContainer[z].plan;

        json["members"][i] = showObject(json["members"][i]);

  }
//        else{
//                console.log("Not Found : " + pidContainer[z].smartphone);
//                
//            }
        }
    }
        
       var fileNewContent = JSON.stringify(json);
        
        console.log(fileNewContent);
        
        
    convertBacktoOriginalState(fileNewContent,file,newPathsContainer);  
         });  
        
    
    });
    
    
    
}
    
 





function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
        modifiedFileCount++;
        console.log("Modified Files"+modifiedFileCount);
        
    }
});
     
}







    
 function convertBacktoOriginalState(newContent,file,newPathsContainer){
    var originalState;
    
    newContent = beautify(newContent, { indent_size: 3, "preserve_newlines": false ,"keep_array_indentation": true });
    for(var jCount =0;jCount<newPathsContainer.length;jCount++){
               var oldPathValue = '"'+newPathsContainer[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(oldPathValue),"g");
               newContent = newContent.replace(regExpCheck,newPathsContainer[jCount]);
    }
    writeToFile(file,newContent);  
    
}


// Main Function for the Application
(function(){
    console.log("Application has started");
    loadPids();
    //console.log(tariffCollectionTRS);
})();

