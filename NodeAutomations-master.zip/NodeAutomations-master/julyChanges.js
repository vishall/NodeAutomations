// For july monthly changes
var fs = require('graceful-fs');
var beautify = require('js-beautify');

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};
var recursive = require('recursive-readdir');
var pathRegExp = /\$\{(.*?)\}/g;
var refurbJsonList = [];
var newPathsContainer = [],
    temp;
recursive('D:/kanban_new/productCatalogueData_Master/catalogueData/device/', function(err, files) {
    var allJsonFiles = files.filter(function(file) {
        return file.substr(-5) === '.json';
    });
    allJsonFiles.forEach(function(file) {
        checkStandard(file);
        var model = json["model"].toString().toLowerCase();
        if (model.indexOf("refurb") >= 0)
            refurbJsonList.push(file.replace(/\\/g, '/'));
    });
    refurbJsonList = refurbJsonList.toString().split(",")
    for (var val in refurbJsonList) {
        checkStandard(refurbJsonList[val]);
        if (!json["condition"])
            json["condition"] = "Refurb";
        updateModel(json);
        updateModelFamily(json);
        updateCcaProductInformation(json);
        updatefulfillmentData(json);
		updateSnippet(json);

        temp = refurbJsonList[val];
        var fileNewContent = JSON.stringify(json);
        convertBacktoOriginalState(fileNewContent, temp, newPathsContainer);
    }
});

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function updateSnippet(json) {
	if(json["id"]==json["leadModelInFamily"]){
		json["snippet"] = ""+"Grab one of our second hand phones and get the phone you want, for less. They all come with a 12 month warranty. And if you change your mind, you have 14 days to return it.<br><br><u><span class='refurb-grade-link'><a href='#'>Find out more</a></span></u>";
	}
	if(json["promotion"]){
		delete json["promotion"];
	json["promotion"] = {
      "postpay": {
         "sash": "Like New"
      },
      "prepay":{
         "sash": "Like New"
      }
   };
	}
}


function updateCcaProductInformation(json) {
    var brand = json["brand"];
    var model = json["model"].toString().toLowerCase();
    var lead = json["modelFamily"];
    if (json["classification"])
        if (json["classification"]["memory"])
            if (json["classification"]["memory"]["display"])
                var size = json["classification"]["memory"]["display"];
    json["ccaProductInformation"] = "" + brand + " " + lead + " " + size;
	if (json["ccaProductInformation"].indexOf("undefined")>=0)
		json["ccaProductInformation"] = "" + brand + " " + lead
	
    if (json["classification"]) {
        if (!json["classification"]["refurbGrade"])
            if (model.indexOf("almost") >= 0)
                json["classification"]["refurbGrade"] = {
                    "display": "Almost Perfect",
                    "code": "2"
                }
            else
                json["classification"]["refurbGrade"] = {
                    "display": "Perfect",
                    "code": "1"
                }
    } else {
        json["classification"] = {
            "refurbGrade": {
                "display": "Perfect",
                "code": "1"
            }
        }
    }
}

function updatefulfillmentData(json) {
    var sku = json["sku"]["code"];
    var productType = json["fulfillmentData"]["productType"];
    var model = json["model"];
    var brand = json["brand"];
    var newProdName = productType + " " + brand + " " + model + " " + sku;
    if (newProdName.length > 50) {
        newProdName = productType + " " + model + " " + sku;
        if (newProdName.length > 50) {
            newProdName = productType + " " + model;
            if (newProdName.length > 50)
                newProdName = newProdName.replace("Like New", "");
            if (newProdName.length > 50)
                console.log(newProdName);
        }
    }
    json["fulfillmentData"]["productName"] = "" + newProdName;
}

function updateModelFamily(json) {
    var modelFamily = json["modelFamily"].toString().toLowerCase();
    modelFamily = modelFamily.replace("refurb", "like new");
    if (modelFamily.indexOf("grade a") >= 0)
        modelFamily = modelFamily.replace(" grade a", "");
    else if (modelFamily.indexOf("grade b") >= 0)
        modelFamily = modelFamily.replace(" grade b", "");
	    modelFamily = uppercase(modelFamily);
    json["modelFamily"] = modelFamily;
}
function updateModel(json) {
    var model = json["model"].toString().toLowerCase();
    model = model.replace("refurb", "like new");
    if (model.indexOf("grade b") >= 0)
        model = model.replace("grade b", "almost perfect");
    else if (model.indexOf("grade a") >= 0)
        model = model.replace("grade a", "perfect");
    else
        model = model.replace("like new", "perfect like new");
    model = uppercase(model);
	if(model.indexOf("gb")>= 0)
		model = model.replace("gb","GB");
    json["model"] = model;
}

function uppercase(input) {
    var inputArray = input.split(' ');
    var outputArray = [];
    for (var x = 0; x < inputArray.length; x++) {
        outputArray.push(inputArray[x].charAt(0).toUpperCase() + inputArray[x].slice(1));
    }
    input = outputArray.join(' ');
    if (input.indexOf("Iphone") >= 0)
        input = input.replace("Iphone", "iPhone");
	else if (input.indexOf("Ipad") >= 0)
        input = input.replace("Ipad", "iPad");
    return input;
}

function checkStandard(file) {
    var content = require(file);
    var newContent = content;
    var newSearch = newContent.match(pathRegExp);
    if (newSearch != null) {
        var uniqueArray = newSearch.filter(function(elem, pos) {
            return newSearch.indexOf(elem) == pos;
        });
        for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
            var planPathValue = '"' + uniqueArray[jCount] + '"';
            var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
            newPathsContainer.push(uniqueArray[jCount]);
            newContent = newContent.replace(regExpCheck, planPathValue);
            var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
        }
        json = JSON.parse(newContent);
    } else {
        json = JSON.parse(newContent);
    }
    return json;
}

function writeToFile(file, content) {
    fs.writeFile(file, content, function(err) {
        if (err) {
            console.log(err);
        }
    });
}

function convertBacktoOriginalState(newContent, file, newPathsContainer) {
    var originalState;
    newContent = beautify(newContent, {
        indent_size: 3,
        "preserve_newlines": false,
        "keep_array_indentation": true
    });
    for (var jCount = 0; jCount < newPathsContainer.length; jCount++) {
        var oldPathValue = '"' + newPathsContainer[jCount] + '"';
        var regExpCheck = new RegExp(escapeRegExp(oldPathValue), "g");
        newContent = newContent.replace(regExpCheck, newPathsContainer[jCount]);
    }
    writeToFile(file, newContent);
}

function cleanUp(json){
	var devicePromo = json["attachments"].toString().split(",");
	for(var val=0; val<devicePromo.length;val++){
		if(devicePromo[val].toLowerCase().indexOf("refurb") >=0 && devicePromo[val].indexOf("deviceSubheaderpromo")>=0){
			devicePromo.splice(val, 1);
		}
	}
	json["attachments"] = devicePromo;
}