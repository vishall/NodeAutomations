var beautify = require('js-beautify');
var fs = require('graceful-fs');
var prettyjson = require('prettyjson');
var options = {
  noColor: true
};
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

recursive('D:/IdeaProjects/productCatalogueData_Master2/catalogueData/device/', function(err, files) {
     var jsonFileCount = 0, jsonFilesIndex = 0;
    var json;
    console.log(files.length);
    var jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
    deviceDetailsCol =[];
    jsonFiles.forEach(function(file) {
        var content =  require(file);
        //console.log(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        //if(json["id"] == "8281864e-faf7-4d28-86d1-5346b64f1c7cdvsd")
        checkFullfilmentData(json,file,newPathsContainer);
        
    });
});
function checkFullfilmentData(json,file,newPathsContainer){
    var sku = json["sku"]["code"],tempArr = [];
	var productType = json["fulfillmentData"]["productType"];
	var model = json["model"];
	var brand = json["brand"];
	
         var newProdName =productType+" "+brand+" "+model+" "+sku;
		 if(newProdName.length>41){
			 newProdName =productType+" "+model+" "+sku;
			 if(newProdName.length>41){
				 newProdName =productType+" "+model;
			 }			 
		 }
		 if(newProdName.length>41){
				tempArr = newProdName.split(" ");
		function removeMe(mystring){
			    var index = tempArr.indexOf(mystring);
				if (index !== -1) {
				tempArr.splice(index, 1);
				}
			};
		function changeMe(mystring,changetxt){
			    newProdName = newProdName.replace(mystring,changetxt);
				
			}
			
			
			removeMe("Like");
			removeMe("New");
			removeMe("new");
			removeMe("O2");
			removeMe("Offer");
			
			newProdName = tempArr.join(" ");
			
			if(newProdName.length>41){
			changeMe("Almost","Almst");
			changeMe("Perfect","Prft");
			changeMe("Perfectly","Prftly");
			changeMe("Fine");
			}
				
			}
		if(json["fulfillmentData"]["productName"]!=newProdName){
			if(newProdName.length<41){
				//console.log(json["fulfillmentData"]["productName"]);
				json["fulfillmentData"]["productName"] = ""+newProdName;
				var fileNewContent = JSON.stringify(json);
				convertBacktoOriginalState(fileNewContent,file,newPathsContainer);
			}
			else
				fs.stat(file,function(err, stats){
			 if(err) {return console.log(err);}
			 else {}
				 console.log(newProdName + " \n");
			});
		 }
		 
           

}
function convertBacktoOriginalState(newContent,file,newPathsContainer){
    var originalState;
    
    newContent = beautify(newContent, { indent_size: 2 });
    for(var jCount =0;jCount<newPathsContainer.length;jCount++){
               var oldPathValue = '"'+newPathsContainer[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(oldPathValue),"g");
               newContent = newContent.replace(regExpCheck,newPathsContainer[jCount]);
    }
	fs.writeFile("ExcelOutput/log.txt","",function(err) {
		if(err) {return console.log(err);}
	});
    writeToFile(file,newContent);  
    
}
function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
       // modifiedFileCount++;
        
        //console.log("Modified Files"+modifiedFileCount);
        fs.appendFile("ExcelOutput/log.txt",file+ "\r\n", function(err) {
                if(err) {
                    return console.log(err);
                }
				else{
					
				}
            }); 
    }
	
});
     
}
function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}