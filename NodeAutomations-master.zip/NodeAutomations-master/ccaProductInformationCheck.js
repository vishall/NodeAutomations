var beautify = require('js-beautify');
var fs = require('graceful-fs');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

recursive('C:/Kanban/productCatalogueData_Master/catalogueData/device/lg', function(err, files) {
    var json;
    console.log(files.length);
    var jsonFiles = files.filter(function(file) {return file.substr(-5) === '.json'; });
    deviceDetailsCol =[];
    jsonFiles.forEach(function(file) {
        var content =  require(file);
        //console.log(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        checkFullfilmentData(json,file,newPathsContainer);
        
    });
});
function checkFullfilmentData(json,file,newPathsContainer){
	var model = json["model"];
	var brand = json["brand"];
	var lead = json["modelFamily"];
	if(json["classification"])
		if(json["classification"]["memory"])
			if(json["classification"]["memory"]["display"])
				var size=  json["classification"]["memory"]["display"];
		 if(size == "n/a"){
			 if(json["ccaProductInformation"] !=brand+" "+lead){
			json["ccaProductInformation"]= ""+brand+" "+lead;
		var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent,file,newPathsContainer);
		}}
		else{
			if(json["ccaProductInformation"] !=brand+" "+lead+" "+size){
				json["ccaProductInformation"]= ""+brand+" "+lead+" "+size;
			var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent,file,newPathsContainer);
			}}
		if (json["ccaProductInformation"].indexOf("undefined")>=0){
			if(json["ccaProductInformation"] !=brand + " " + lead){
		json["ccaProductInformation"] = "" + brand + " " + lead;
	var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent,file,newPathsContainer);
	}}
        

}
function convertBacktoOriginalState(newContent,file,newPathsContainer){
    var originalState;
    
    newContent = beautify(newContent, { indent_size: 2 });
    for(var jCount =0;jCount<newPathsContainer.length;jCount++){
               var oldPathValue = '"'+newPathsContainer[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(oldPathValue),"g");
               newContent = newContent.replace(regExpCheck,newPathsContainer[jCount]);
    }
	fs.writeFile("ExcelOutput/log.txt","",function(err) {
		if(err) {return console.log(err);}
	});
    writeToFile(file,newContent);  
    
}
function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
        //modifiedFileCount++;
        
        //console.log("Modified Files"+modifiedFileCount);
        fs.appendFile("ExcelOutput/log.txt",file+ "\r\n", function(err) {
                if(err) {
                    return console.log(err);
                }
				else{
					
				}
            }); 
    }
	
});
     
}
function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}