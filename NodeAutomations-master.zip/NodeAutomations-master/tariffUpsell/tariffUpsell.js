
var express = require('express');
var app = express();
var fs = require('graceful-fs');
var beautify = require('js-beautify');
var getPlanID = require("./Scripts/server/getPlanID.js");
var postRibbonsGetFileName = require("./Scripts/server/postRibbonsGetFileName.js");
var postFileNameGetPromoCode = require("./Scripts/server/postFileNameGetPromoCode.js");
var checkPromoCodeRefOperations = require("./Scripts/server/checkPromoCodeRefOperations.js");

global.prodCatalogLoc='',global.browsingDesktopFilePath='',global.upgradeDesktopFilePath='',filenamesArr=[],inputGUID ='',global.fileData = "";
var primaryRibbon='',secondaryRibbon='';


app.set('view engine', 'jade');
app.engine('html', require('ejs').renderFile);
app.use("/Scripts", express.static(__dirname + '/Scripts'));
app.use("/Style", express.static(__dirname + '/Style'));
app.use("/Images", express.static(__dirname + '/Images'));
app.use(require('body-parser').json({ type : '*/*',limit: '1000mb' }));

app.get('/home', function (req, res) {
  res.render('index.html');
});

app.post('/postDeviceIdReadFileContent', function (req, res) {

  inputGUID = (req.body)[0];
  var pathObj=setPath((req.body)[1]);
  var tariffRowsFound='',isElementFound=false;

  prodCatalogLoc=pathObj["prodcatalogpath"];
  browsingDesktopFilePath=pathObj["browsingDesktopfilepath"];
  upgradeDesktopFilePath=pathObj["upgradeDesktopfilepath"];
  
  fileData=fs.readFileSync(prodCatalogLoc+'/media/attachments/common/tariffUpsell.txt');
  var objectsInFile=JSON.parse(fileData.toString());


    for(var index in objectsInFile) {
      var currentVal=objectsInFile[index];
        if(currentVal.deviceId==inputGUID){
        tariffRowsFound=currentVal.tariffRows;
        isElementFound=true;
        break;
        }
    }


  /*  if(isElementFound===false){
       res.send({ fileData: 'notResultsFound',planIDsJsonFileData:JSON.parse(JSON.stringify(data))});
    } else {

        getPlanID.getPlanIdsByDeviceId(inputGUID,prodCatalogLoc).then(function (data) {
         //send data to the browser(client machine) 
          res.setHeader('Content-Type', 'application/json');
          res.send({fileData:tariffRowsFound, planIDsJsonFileData: JSON.parse(JSON.stringify(data))});
        });
      }*/


       getPlanID.getPlanIdsByDeviceId(inputGUID,prodCatalogLoc).then(function (data) {
         //send data to the browser(client machine) 
         if(isElementFound===false){
            tariffRowsFound="notResultsFound";
          } 

          res.setHeader('Content-Type', 'application/json');
          res.send({fileData:tariffRowsFound, planIDsJsonFileData: JSON.parse(JSON.stringify(data))});
        });

});


app.post('/writeNewDeviceIdInTariffUpsell', function (req, res) {

    inputGUID = (req.body)[0];
    var objectsInFile=JSON.parse(fileData.toString());
    //push new object in tariffUpsell.txt
    var newDevideIdElement={'deviceId':inputGUID,'tariffRows': []};
    objectsInFile.unshift(newDevideIdElement);

    newContent = beautify(JSON.stringify(objectsInFile,null,3), {indent_size: 3,
    "preserve_newlines": false, "keep_array_indentation": true });

    fs.writeFile(prodCatalogLoc+'/media/attachments/common/tariffUpsell.txt',newContent, function(err) {
      if (err) {
        fileData=fs.readFileSync(prodCatalogLoc+'/media/attachments/common/tariffUpsell.txt');
       res.send({ response:false});
      }
      else {
        fileData=fs.readFileSync(prodCatalogLoc+'/media/attachments/common/tariffUpsell.txt');
         res.send({ response:true});
      }
    });


});


app.post('/saveIntoFile', function (req, res) {

  var data = (req.body);
  var objectsinFile=JSON.parse(fileData.toString());

  for(var index in objectsinFile) {
    var currentVal=objectsinFile[index];
      if(currentVal.deviceId==inputGUID){
        currentVal.tariffRows=data;
        break;
      }
  }

  newContent = beautify(JSON.stringify(objectsinFile,null,3), {indent_size: 3,
  "preserve_newlines": false, "keep_array_indentation": true });

  fs.writeFile(prodCatalogLoc+'/media/attachments/common/tariffUpsell.txt',newContent, function(err) {
    if (err) {
     res.send({ response: false });
    }
    else {
     res.send({ response: true });
    }
  });

});

app.post('/sendRibbonDataGetFileNames', function (req, res) {

  primaryRibbon = (req.body)[0];
  secondaryRibbon = (req.body)[1];
  var pathObj=setPath((req.body)[2]);

  prodCatalogLoc=pathObj["prodcatalogpath"];
  browsingDesktopFilePath=pathObj["browsingDesktopfilepath"];
  upgradeDesktopFilePath=pathObj["upgradeDesktopfilepath"];

  postRibbonsGetFileName.checkRibbonsPresent(primaryRibbon,secondaryRibbon,prodCatalogLoc).then(function (data) {

    filenamesArr=data;
    res.send({filenameArr:filenamesArr});  
   });

});

app.post('/postFileReadReference', function (req, res) {
  
   var  filename = (req.body)[0];
   var promocode='',bdRefArr=[],udRefArr=[];
   var browsingDRefFoundArr=postFileNameGetPromoCode.checkRefereinBrowseDesktop(filename,browsingDesktopFilePath);
   var upgradeDRefFoundArr=postFileNameGetPromoCode.checkRefereinUpgradeDesktop(filename,upgradeDesktopFilePath);
   
   var bdRefArr=postFileNameGetPromoCode.getPromoCodeRefArr(browsingDRefFoundArr);
   var udRefArr=postFileNameGetPromoCode.getPromoCodeRefArr(upgradeDRefFoundArr);

   var RibbonTextObj=postRibbonsGetFileName.getRibbonsFromTheFile(filename,browsingDesktopFilePath);
   res.send({BDRef:bdRefArr, UDRef: udRefArr ,RibbonTextObj:RibbonTextObj});
   
  
});

app.post('/postfileNamePromoCodeCreateFilegetRef', function (req, res) {
  debugger;
  var htmlFileName = (req.body)[0];
  var BDrefPromoCode = (req.body)[1];
  var UDrefPromoCode = (req.body)[2];
  var primaryRibbon= (req.body)[4],secondaryRibbon= (req.body)[5];
 
  var isFileCreated=false;
  var isFileAlreadyPresentInDir=false;
  var isPromCodRefPreBD=false;
  var isPromCodRefPreUD=false;
  var isBDRefCreated=false;
  var isUDRefCreated=false;

  //passing prod cat log path to set all the path
  var pathObj=setPath((req.body)[3]);
  prodCatalogLoc=pathObj["prodcatalogpath"];
  browsingDesktopFilePath=pathObj["browsingDesktopfilepath"];
  upgradeDesktopFilePath=pathObj["upgradeDesktopfilepath"];

  var BDfilePath=browsingDesktopFilePath+"\\media\\browsingDesktop.json";
  var UDfilePath=upgradeDesktopFilePath+"\\media\\upgradeDesktop.json";


 if(BDrefPromoCode==='disabled'){
    isPromCodRefPreBD=true;
 } else {
    //isPromCodRefPreBD=checkPromoCodeRefOperations.checkIfRefAlreadyPresent(BDrefPromoCode,BDfilePath);
    isPromCodRefPreBD=checkPromoCodeRefOperations.isPromoRefPresentForHtmlFile(htmlFileName,BDfilePath);
 }

 if(UDrefPromoCode==='disabled'){
    isPromCodRefPreUD=true;
 } else {
    isPromCodRefPreUD=checkPromoCodeRefOperations.isPromoRefPresentForHtmlFile(htmlFileName,UDfilePath);
 }

  // check if file is present in rop down list if not check if it is present in directory if it is not present we can create hml file with the name
  var isFilePresentInDdl=checkPromoCodeRefOperations.checkIfFileNamePresentInDropDownList(htmlFileName,filenamesArr);
  if(!isFilePresentInDdl){
         isFileAlreadyPresentInDir=postFileNameGetPromoCode.checkHtmlFilePresent(htmlFileName,prodCatalogLoc);
    
     } else { isFileAlreadyPresentInDir=true; }




  
   //check for conditions if file is already present or promo code is already present.
  if(isFileAlreadyPresentInDir && (BDrefPromoCode!='disabled') && (UDrefPromoCode!='disabled')){

      if(!isPromCodRefPreBD && !isPromCodRefPreUD){
            checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,BDrefPromoCode,BDfilePath).then(function (data) {
              isBDRefCreated= data;

              checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,UDrefPromoCode,UDfilePath).then(function (data) {
                  isUDRefCreated= data;

                  if(isBDRefCreated && isUDRefCreated){
                     res.send({ response: "FilePresentBDUDRefCreated" });
                  } else {
                    res.send({ response: false });
                  }

             }); 

             });

      } else if(!isPromCodRefPreBD){

          checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,BDrefPromoCode,BDfilePath).then(function (data) {
              isBDRefCreated= data;
               if(isBDRefCreated){
                   res.send({ response: "FileUDPresentBDRefCreated" });
                } else {
                  res.send({ response: false });
                }

            });

      } else if(!isPromCodRefPreUD){
          checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,UDrefPromoCode,UDfilePath).then(function (data) {
            isUDRefCreated= data;

            if(isUDRefCreated){
               res.send({ response: "FileBDPresentUDRefCreated" });
            } else {
              res.send({ response: false });
            }

          }); 

      } else if(isPromCodRefPreBD && isPromCodRefPreUD) {
        res.send({ response: "FileBDandUDRefAlreadyPresent" });
      }

  } else if (isFileAlreadyPresentInDir && (BDrefPromoCode!='disabled')){
    
      if(!isPromCodRefPreBD){

            checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,BDrefPromoCode,BDfilePath).then(function (data) {
                isBDRefCreated= data;
                 if(isBDRefCreated){
                     res.send({ response: "BDRefCreated" });
                  } else {
                    res.send({ response: false });
                  }

              });

        }
  } else if(isFileAlreadyPresentInDir && (UDrefPromoCode!='disabled')){
 
    if(!isPromCodRefPreUD){
            checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,UDrefPromoCode,UDfilePath).then(function (data) {
              isUDRefCreated= data;

              if(isUDRefCreated){
                 res.send({response:"UDRefCreated"});  
              } else {
                res.send({ response: false });
              }

            }); 

        }
  } else if(!isFileAlreadyPresentInDir && (BDrefPromoCode!='disabled') && (UDrefPromoCode!='disabled')){
    //create HTML file 

    postFileNameGetPromoCode.createHTMLFile(htmlFileName,primaryRibbon,secondaryRibbon,prodCatalogLoc).then(function (data) {
      isFileCreated=data;
    
     if(!isPromCodRefPreBD && !isPromCodRefPreUD){
            checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,BDrefPromoCode,BDfilePath).then(function (data) {
              isBDRefCreated= data;

              checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,UDrefPromoCode,UDfilePath).then(function (data) {
                  isUDRefCreated= data;

                  if(isFileCreated && isBDRefCreated && isUDRefCreated){
                     res.send({ response: "FileBDUDRefCreated" });
                  } else {
                    res.send({ response: false });
                  }

             }); 

             });

      } else if(!isPromCodRefPreBD){

          checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,BDrefPromoCode,BDfilePath).then(function (data) {
              isBDRefCreated= data;
               if(isFileCreated && isBDRefCreated){
                   res.send({ response: "UDPresentFileBDRefCreated" });
                } else {
                  res.send({ response: false });
                }

            });

      } else if(!isPromCodRefPreUD){
          checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,UDrefPromoCode,UDfilePath).then(function (data) {
            isUDRefCreated= data;

            if(isFileCreated && isUDRefCreated){
               res.send({ response: "BDPresentFileUDRefCreated" });
            } else {
              res.send({ response: false });
            }

          }); 

      } else if(isPromCodRefPreBD && isPromCodRefPreUD && isFileCreated){

          res.send({ response: "BDUDPresentFileCreated" });
      }

    });
  } else if(!isFileAlreadyPresentInDir && (BDrefPromoCode!='disabled')){
      //create HTML file 
      postFileNameGetPromoCode.createHTMLFile(htmlFileName,primaryRibbon,secondaryRibbon,prodCatalogLoc).then(function (data) {
        isFileCreated=data;
     
        if(!isPromCodRefPreBD){

              checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,BDrefPromoCode,BDfilePath).then(function (data) {
                  isBDRefCreated= data;
                   if(isFileCreated && isBDRefCreated){
                       res.send({ response: "FileBDRefCreated" });
                    } else {
                      res.send({ response: false });
                    }

                });

          }

      });
  } else if(!isFileAlreadyPresentInDir && (UDrefPromoCode!='disabled')){
   //create HTML file 
    postFileNameGetPromoCode.createHTMLFile(htmlFileName,primaryRibbon,secondaryRibbon,prodCatalogLoc).then(function (data) {
      isFileCreated=data;
      var isPromCodRefPreUD=checkPromoCodeRefOperations.checkIfRefAlreadyPresent(UDrefPromoCode,UDfilePath);
      if(!isPromCodRefPreUD){
            checkPromoCodeRefOperations.insertPromoCodeRefInBDAndUD(htmlFileName,UDrefPromoCode,UDfilePath).then(function (data) {
              isUDRefCreated= data;

              if(isFileCreated && isUDRefCreated){
                 res.send({ response: "FileUDRefCreated" });
              } else {
                res.send({ response: false });
              }

            }); 

        }

    });
  }

});

app.listen(8187, function () {
  console.log("app listening on port 8187 ! Open 'http://localhost:8187/home' in browser.");
});

function setPath(windowfilepath){
  var obj={};
  var path=windowfilepath,catlogpath='',specialChar="\\";

  obj.browsingDesktopfilepath=windowfilepath;
  obj.upgradeDesktopfilepath=windowfilepath;
  
  path.split('').forEach( function( value ) { 

    if(specialChar==value){
      value='/';
    }
    catlogpath=catlogpath+value;

  });

  obj.prodcatalogpath=catlogpath;

  return obj;

}






