define('callBacks',["jquery","displayData"],function($,displayData){

	//Success callback function call 
	var OnReadFileSuccess = function(data){
		var dataFound=displayData.getPlanIdFromJSONFileByDevideID(data.planIDsJsonFileData,data.fileData);
			if(dataFound){
			displayData.getTariffRowsByDevideID(data.fileData);
			displayData.colorCloneForSamePlanID();
		}		
	}

 /*   //Success callback OnwriteNewDeviceIdInTariffUpsellSuccess
    var OnwriteNewDeviceIdInTariffUpsellSuccess = function(data){
        alert(data.response);
        if(data.response===true){
            alert('Device Id created in tariffUpsell.txt file Successfully.'); 
        } else {
            alert('Sorry..problem occurred while saving the data !');
        }
            
    }*/


	var ribbonSendSuccess=function(data){

		if(data.filenameArr.length>0){

            $('#ddlFilename').css("display","inline-block");
            $('#fileNotFoundErrMsg').css("display","none");
            $('option', $('#ddlFilename')).not(':eq(0)').remove()
          	$.each(data.filenameArr, function (i, entry) {
          	 	 $('#ddlFilename').append( new Option(entry,entry) )
          	});

        } else {
            
           $('.displayPrimaryRbn').css("display","none");
           $('.displaySeconaryRbn').css("display","none");
           $('#txt-refernce-filename').prop("disabled", false);
           $('#txt-BD-ref-promocode').prop("disabled", false);
           $('#txt-UD-ref-promocode').prop("disabled", false);
           $('#btnValidate').prop("disabled", false);
           $('#txt-refernce-filename').val('');
           $('#txt-ref-promocode').val('');
           $('#ddlFilename').css("display","none");
           $('#fileNotFoundErrMsg').css("display","inline-block");

        }
    }

    var onDropCall=function (ele) {
				//get all SortOrdinal textbox
				allSortOrdinalEle=$('#TariffRowContainer').children().get();
				//Reset global variable to 1
				globalSortOrdinalValue=1;
				
				allSortOrdinalEle.forEach(function (element, index) {
						$(element).find('.clsSortOrdinal').find('.clsUpfrontCostInput').val(globalSortOrdinalValue);
						globalSortOrdinalValue++;
				});
	};

    var OnSaveFileSuccess=function(data){

        if(data.response){ 

            //alert('Data saved successfully..!!');
          /* $('#saveSuccessMsg').css('display','block');
           setTimeout(function(){
              $('#saveSuccessMsg').css('display','none');
           },3000); */
             modalDialogBoxMessage="Data saved successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

         } else { 
            //alert('Sorry..problem occurred while saving the data !');
                modalDialogBoxMessage="Sorry..problem occurred while saving the data !!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });
         }
    }

    var OnSaveFileFail=function(err){
       // alert('Ooops.... Some Problem Occurred !');
       modalDialogBoxMessage="Ooops.... Some Problem Occurred !!";
        $("#lblMessageBox").text(modalDialogBoxMessage);
        $( "#msgDialog" ).dialog({
         modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
        });
    }
    
    var OnReferenceFoundSuccess=function(data){
        var htmlfilename =$('#ddlFilename').val();
        var fileNametxtBox =$('#txt-refernce-filename');
        var BDrefPromoCode =$('#txt-BD-ref-promocode');
        var UDrefPromoCode =$('#txt-UD-ref-promocode');
        var primaryRbnText =$('#txt-primary-ribbon');
        var seconaryRbnText=$('#txt-secondary-ribbon');

        var BDRef=data.BDRef;
        var UDRef=data.UDRef;

        if(data.RibbonTextObj.primaryRibbontext!==""){
            $('.displayPrimaryRbn').css('display','block');
            primaryRbnText.val(data.RibbonTextObj.primaryRibbontext);
        } else {  $('.displayPrimaryRbn').css('display','none'); }

        if(data.RibbonTextObj.secRibbontext!==""){
            $('.displaySeconaryRbn').css('display','block');
            seconaryRbnText.val(data.RibbonTextObj.secRibbontext);
        } else {  $('.displaySeconaryRbn').css('display','none'); }

        if(BDRef.length>1 && UDRef.length>1){
           // userMsg='Multiple occurences for References found in BD and UD.';
            var isRefMatchInBDAnUD=false,RefCodeFound='';
            $(BDRef).each(function(BDindex,BDRefvalue){
                        $(UDRef).each(function(UDindex,UDRefvalue){
                            if(BDRefvalue===UDRefvalue){
                                RefCodeFound=BDRefvalue;
                                isRefMatchInBDAnUD=true;
                                return false;
                            }
                        });
                        if(isRefMatchInBDAnUD===true){
                           return false;
                      }
            });

            if(isRefMatchInBDAnUD){
                fileNametxtBox.val(htmlfilename);
                BDrefPromoCode.val(RefCodeFound);
                UDrefPromoCode.val(RefCodeFound);
                fileNametxtBox.prop('disabled', true);
                BDrefPromoCode.prop('disabled', true);
                UDrefPromoCode.prop('disabled', true);
                $('#btnValidate').prop('disabled', true);

            } else {
                fileNametxtBox.val(htmlfilename);
                BDrefPromoCode.val(BDRef[BDRef.length-1]);
                UDrefPromoCode.val(UDRef[UDRef.length-1]);
                fileNametxtBox.prop('disabled', true);
                BDrefPromoCode.prop('disabled', true);
                UDrefPromoCode.prop('disabled', true);
                $('#btnValidate').prop('disabled', true);

            }

           // alert('Note : Multiple occurences for References found in BD and UD.');
                modalDialogBoxMessage="Note : Multiple occurences for References found in BD and UD.";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });


        } else if(BDRef.length===1 && UDRef.length===1){
                fileNametxtBox.val(htmlfilename);
                BDrefPromoCode.val(BDRef[0]);
                UDrefPromoCode.val(UDRef[0]);
                fileNametxtBox.prop('disabled', true);
                BDrefPromoCode.prop('disabled', true);
                UDrefPromoCode.prop('disabled', true);
                $('#btnValidate').prop('disabled', true);

        }else if(BDRef.length>0 && UDRef.length<1){

                if(BDRef.length>1){
                    fileNametxtBox.val(htmlfilename);
                    BDrefPromoCode.val(BDRef[BDRef.length-1]);
                    UDrefPromoCode.val('');
                    fileNametxtBox.prop('disabled', true);
                    BDrefPromoCode.prop('disabled', true);
                    UDrefPromoCode.prop('disabled', false);
                    $('#btnValidate').prop('disabled', false);
                    //alert('Note : Multiple occurences for References found in BD and NO Occurence in UD.');
                     modalDialogBoxMessage="Note : Multiple occurences for References found in BD and NO Occurence in UD.";
                    $("#lblMessageBox").text(modalDialogBoxMessage);
                    $( "#msgDialog" ).dialog({
                     modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                    });

                } else { 
                    fileNametxtBox.val(htmlfilename);
                    BDrefPromoCode.val(BDRef[0]);
                    UDrefPromoCode.val('');
                    fileNametxtBox.prop('disabled', true);
                    BDrefPromoCode.prop('disabled', true);
                    UDrefPromoCode.prop('disabled', false);
                    $('#btnValidate').prop('disabled', false);

                }
               
                

        } else if(BDRef.length<1 && UDRef.length>0){
                //userMsg='Multiple occurences for References found in UD and No Occurence in BD.';
                fileNametxtBox.val(htmlfilename);
                BDrefPromoCode.val('');
                UDrefPromoCode.val(UDRef[UDRef.length-1]);
                fileNametxtBox.prop('disabled', true);
                BDrefPromoCode.prop('disabled', false);
                UDrefPromoCode.prop('disabled', true);
                $('#btnValidate').prop('disabled', false);
                //alert('Note : Multiple occurences for References found in UD and No Occurence in BD.');
                    modalDialogBoxMessage="Note : Multiple occurences for References found in UD and No Occurence in BD.";
                    $("#lblMessageBox").text(modalDialogBoxMessage);
                    $( "#msgDialog" ).dialog({
                     modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                    });

                if(UDRef.length>1){
                    fileNametxtBox.val(htmlfilename);
                    BDrefPromoCode.val('');
                    UDrefPromoCode.val(UDRef[UDRef.length-1]);
                    fileNametxtBox.prop('disabled', true);
                    BDrefPromoCode.prop('disabled', false);
                    UDrefPromoCode.prop('disabled', true);
                    $('#btnValidate').prop('disabled', false);
                   // alert('Note : Multiple occurences for References found in UD and No Occurence in BD.');
                     modalDialogBoxMessage="Note : Multiple occurences for References found in UD and No Occurence in BD.";
                    $("#lblMessageBox").text(modalDialogBoxMessage);
                    $( "#msgDialog" ).dialog({
                     modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                    });

                } else { 
                    fileNametxtBox.val(htmlfilename);
                    BDrefPromoCode.val('');
                    UDrefPromoCode.val(UDRef[0]);
                    fileNametxtBox.prop('disabled', true);
                    BDrefPromoCode.prop('disabled', false);
                    UDrefPromoCode.prop('disabled', true);
                    $('#btnValidate').prop('disabled', false);

                }

        } else {
                fileNametxtBox.val(htmlfilename);
                BDrefPromoCode.val('');
                UDrefPromoCode.val('');
                fileNametxtBox.prop('disabled', false);
                BDrefPromoCode.prop('disabled', false);
                UDrefPromoCode.prop('disabled', false);
                $('#btnValidate').prop('disabled', false);

           // alert('File Reference not found. Please provide promocode.');
                modalDialogBoxMessage="Promo code References not found for HTML file. Please provide promocode reference.";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });
        }

    }

    var crateFileandPromoCodeSuccess=function(data){
        var modalDialogBoxMessage="";
        if(data.response==='FileBDandUDRefAlreadyPresent'){

            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
        	    modalDialogBoxMessage="Sorry..File name,BD and UD ref already present for the HTML file..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        } else if(data.response==='BDUDPresentFileCreated'){
            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
           // alert('HTML file created Successfully..!! Promo Code References already present in BD and UD !!');
                modalDialogBoxMessage="Promo Code References already present in BD and UD, HTML file created Successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        } else if(data.response==='FilePresentBDUDRefCreated'){
            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
            //alert('HTML filename already present in directory ,Promo Code Ref created in BD and UD successfully !!');
                modalDialogBoxMessage="HTML filename already present in directory ,Promo Code Ref created in BD and UD successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        } else if(data.response==='FileUDPresentBDRefCreated'){
           $('#txt-refernce-filename').prop('disabled', false);
           $('#txt-BD-ref-promocode').prop('disabled', false);
           $('#txt-UD-ref-promocode').prop('disabled', false);
           $('#txt-refernce-filename').val('');
           $('#txt-BD-ref-promocode').val('');
           $('#txt-UD-ref-promocode').val('');
          // alert('HTML filename and Reference is already Present in UD ,Promo Code Ref created in BD !!');
                modalDialogBoxMessage="HTML filename and Reference is already Present in UD, Promo Code Ref created in BD successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        } else if(data.response==='FileBDPresentUDRefCreated'){
            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
            //alert('Promo Code Ref created in UD.Promo code Ref present in BD.');
                modalDialogBoxMessage="HTML filename and promocode already pesent in BD, Promo Code Ref created in UD successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        } else if(data.response==='BDRefCreated'){
            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
           // alert('Promo Code Ref created in BD successfully !!');
            modalDialogBoxMessage="HTML filename and promocode already pesent in UD, Promo Code Ref created in BD successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        } else if(data.response==='UDRefCreated'){
            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
          //  alert('Promo Code Ref created in UD successfully !!');
            modalDialogBoxMessage="HTML filename and promocode already pesent in BD, Promo Code Ref created in UD successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        } else if(data.response==='FileBDUDRefCreated'){
            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
           // alert('HTML file and promocode references created successfully !!');
            modalDialogBoxMessage="'HTML file and promocode references created successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        } else if(data.response==='UDPresentFileBDRefCreated'){
            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
           // alert('HTML file and Promo Code Ref created in UD successfully !! Promo code Ref present in BD.');
                modalDialogBoxMessage="Promo code Ref already present in UD, HTML file and Promo Code Ref created in BD successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        }else if(data.response==='BDPresentFileUDRefCreated'){
            $('#txt-refernce-filename').prop('disabled', false);
            $('#txt-BD-ref-promocode').prop('disabled', false);
            $('#txt-UD-ref-promocode').prop('disabled', false);
            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
            // alert('HTML file and Promo Code Ref created in BD successfully !! Promo code Ref present in UD.');
                modalDialogBoxMessage="Promo code Ref already present in BD, HTML file and Promo Code Ref created in UD successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        }else if(data.response==='BDRefCreated'){

            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
            //alert('Promocode reference in BD created successfully !!');
                modalDialogBoxMessage="HTML filename and promocode already present in UD, Promo Code Ref created in BD successfully..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        }else if(data.response==='FileBDRefCreated'){

            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
           // alert('HTML file and promocode ref in BD created successfully !!');
                modalDialogBoxMessage="Promo code Ref already present in UD, HTML file and promocode ref in BD created successfully !!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        }else if(data.response==='FileUDRefCreated'){

            $('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
           // alert('HTML file and promocode ref in UD created successfully !!');
                modalDialogBoxMessage="Promo code Ref already present in BD, HTML file and promocode ref in UD created successfully !!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });

        }else {

        	$('#txt-refernce-filename').val('');
            $('#txt-BD-ref-promocode').val('');
            $('#txt-UD-ref-promocode').val('');
        	//alert('Oops..Something went wrong..!!');
                modalDialogBoxMessage="Oops..Something went wrong..!!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });
        }

    } 

	return {
			OnReadFileSuccess:OnReadFileSuccess,
			ribbonSendSuccess:ribbonSendSuccess,
			onDropCall:onDropCall,
			OnReferenceFoundSuccess:OnReferenceFoundSuccess,
            crateFileandPromoCodeSuccess:crateFileandPromoCodeSuccess,
            OnSaveFileSuccess:OnSaveFileSuccess,
            OnSaveFileFail:OnSaveFileFail,
 
	};
	
});