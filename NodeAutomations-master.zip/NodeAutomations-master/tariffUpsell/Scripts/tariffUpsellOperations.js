define('tariffUpsellOperations',["jquery"],function($){

	function clearSortOrdAndUpfrontCost(inputEle,SelectedEleArr){

		if(inputEle=='clearSortOrdinal'){
				SelectedEleArr.forEach(function(entry) {
				    $(entry).find('.clsSortOrdinal .clsUpfrontCostInput').val('');
				});
			
        } else if(inputEle=='clearPromotionAttachmentId')
		{
				SelectedEleArr.forEach(function(entry) {
				    $(entry).find('.clsPromotionInput').val('')
				});
		}
		$("#chkSelectAll").prop("checked",false);
		$(".chkbox").prop("checked",false);

	}

	function checkcheckboxSelected(){
		var TariffUpsellChildEle=$('#TariffRowContainer').children();
		var isCheckBoxSelected=false;
		var SelectedEleArr=[];
				
		if(TariffUpsellChildEle.length!=0){

							 $.each(TariffUpsellChildEle,function(index,element) {
						  			getElement=$(element).find('.chkbox');
						  			if(getElement.get(0).checked){
						  				    isCheckBoxSelected=true;
						  				    SelectedEleArr.push(element);
						  			}
						  				
						  });	
					}

		var obj={};
		obj.isCheckBoxSelected=isCheckBoxSelected;
		obj.SelectedEleArr=SelectedEleArr;
		return obj;
	}

	function moveContentToTariffRow(planID,upfrontCost){

		var displayData=require('displayData');

		var countChildren=$('#TariffRowContainer').children();
		var countcheckedEle=0;
		var ElemtFound=' ';
		var isPresenet=false;
		if(countChildren.length==0){
			globalSortOrdinalValue=1;
		} else {
				$.each(countChildren,function(index,element) {
					
								if($(element).find('.clsPlanIDinput').val().trim()==planID && $(element).find('#upfrontCostInPense .clsUpfrontCostInput').val().trim()==upfrontCost){
					  				 isPresenet=true;
					  			}
						 
				});
		}

		 
		if(isPresenet){
							//alert('Element is already present !');
		} else {
			var sortOrdinal=globalSortOrdinalValue,promotionAttachmentId='';
			var htmlEle=displayData.createTariffUpsellRows(planID,upfrontCost,sortOrdinal,promotionAttachmentId);
			globalSortOrdinalValue++;
		    $('#TariffRowContainer').append(htmlEle);
		} 
		displayData.colorCloneForSamePlanID();

	}


	



	return {
			clearSortOrdAndUpfrontCost:clearSortOrdAndUpfrontCost,
			checkcheckboxSelected:checkcheckboxSelected,
			moveContentToTariffRow:moveContentToTariffRow,	
	};
});