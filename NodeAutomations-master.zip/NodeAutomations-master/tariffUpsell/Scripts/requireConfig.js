
require.config({
	paths:{
		jquery:'https://ajax.googleapis.com/ajax/libs/jquery/2.1.0/jquery.min',
		jqueryUi:'http://code.jquery.com/ui/1.11.1/jquery-ui'
	}
});

define('app',["jquery","displayData","callBacks","jqueryUi",'tariffUpsellOperations'],function($,displayData,callBacks,$Ui,operations){

	fileContent='';
	selectedCheckBoxArr=[];
	getElement='';
	planID='';
	upfrontCostInPense='';
	sortOrdinal='';
	promotionAttachmentId='';
	globalSortOrdinalValue=1;
 	prodCatalogPath='';
 	modalDialogBoxMessage='';
	
    //Register the events for the DOM elements
	var btnDeviceSearch=function(){
				
								
				//get deviceID which needs to be searched
				searchEle=$('.searchDvcDIVelements[name=txtMainInput]').val();
				//make globalSortOrdinalValue to start with 1 for every fresh device ID 
				globalSortOrdinalValue=1;
				prodCatalogPath=  localStorage.getItem("prodCatalogPath");
				
				   if(searchEle=="" || searchEle==undefined){
					 
					//alert('Please enter Device.');
					} else if(prodCatalogPath==null || prodCatalogPath=='')
					{
						//alert('Please set catalogue path.');
						modalDialogBoxMessage="Please set catalogue path.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
					}
					else {
								$('#loader').show();
								//clear all tariffs already present in the grid
					   			$('#TariffRowContainer').children().remove();

								var inputGuidArr=[];
								inputGuidArr.push(searchEle.trim());
								inputGuidArr.push(prodCatalogPath.trim());

								$.ajax({
									url: '/postDeviceIdReadFileContent',
									type:'POST',
									data: JSON.stringify(inputGuidArr),
									dataType: 'JSON',
									success: callBacks.OnReadFileSuccess
									}).always(function(){
										$('#loader').hide();
									});

	             				 }
	
	}

	var btnCheck = function(){
		
			var primaryRibbon=$("#primaryRibbon").val();
			var secondaryRibbon=$("#secondaryRibbon").val();
			prodCatalogPath=  localStorage.getItem("prodCatalogPath");

			var primRbnmaxLength=calculateMaxLength(primaryRibbon);
			//var secondRbnmaxLength=calculateMaxLength(secondaryRibbon);


			if(primaryRibbon=='' && secondaryRibbon==''){
        	//alert('Please provide either Primary Ribbon or Secondar Ribbon.');
        	modalDialogBoxMessage="Please provide either Primary Ribbon or Secondar Ribbon.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
			}
			else if(prodCatalogPath==null || prodCatalogPath=='')
			{
				//alert('Please set catalogue path.');
				modalDialogBoxMessage="'Please set catalogue path.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dbtbialog('close');}}]
						});
			} else if(primaryRibbon.length>primRbnmaxLength ){

			} else {
					$('#loader').show();

					var ribbonArr=[];
					ribbonArr.push(primaryRibbon.trim());
					ribbonArr.push(secondaryRibbon.trim());
					ribbonArr.push(prodCatalogPath.trim());

					$.ajax({
					url: '/sendRibbonDataGetFileNames',
					type:'POST',
					data: JSON.stringify(ribbonArr),
					dataType: 'JSON',
					success: callBacks.ribbonSendSuccess
					}).always(function(){
						$('#loader').hide();
					});

 			}
	}

	/*var setPath=function(){

		var catalogPath=$('#catalogLocation').val();
		if(catalogPath==null || catalogPath==''){
			alert('Catalogue path can not be empty.');
		}else {
			localStorage.setItem("prodCatalogPath", catalogPath);
			alert('Catalogue path has been set successfully..!');
			//empty textbox of prod catalogue.
			$('#catalogLocation').val("");
		}
	}*/

	var clearSortOrdinal=function(){
		var Obj=operations.checkcheckboxSelected();
		if(Obj.isCheckBoxSelected){
			operations.clearSortOrdAndUpfrontCost('clearSortOrdinal',Obj.SelectedEleArr);
		} else {
			//alert('Please select element/elements.');
			modalDialogBoxMessage="Please select element/elements.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
		}
	}
	
	var clearPromoAttachID=function(){
		var Obj=operations.checkcheckboxSelected();
		if(Obj.isCheckBoxSelected){
			operations.clearSortOrdAndUpfrontCost('clearPromotionAttachmentId',Obj.SelectedEleArr);
		} else {
			//alert('Please select element/elements.');
			modalDialogBoxMessage="Please select element/elements.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
		}
	}

	var chkSelectAll= function(){  //"select all" change 

    			$(".chkbox").prop('checked', $(this).prop("checked"));
    }

    var sortable={
					tolerance: 'touch',
					 axis: 'y',
					stop:callBacks.onDropCall
	};

	var movePlanIDBtnHandler=function(){
			//var childElefromPlanIDRows=$('#PlanIdRowsContent').children();
			var childElefromPlanIDRows;
			var isCheckBoxSelected=false;
		 	var	upfrontCostArr=[],checkbxSelectedEle=[];
		 	var planID='';

		 					$.each($('[name="radioPrice"]'),function(index,entry) {
									if(entry.checked==true){
										isCheckBoxSelected=true;
										checkbxSelectedEle.push($(entry).parent().parent().parent());
									}
							 });

		 	if(checkbxSelectedEle.length>0){
		 					//childElefromPlanIDRows=checkbxSelectedEle;
				 		for(var i=0;i<checkbxSelectedEle.length;i++){
								planID=$(checkbxSelectedEle[i]).find('.clsPlanIDlbl')[0].textContent.trim();
								upfrontCostArr=[];
								$.each($(checkbxSelectedEle[i]).find("[name='radioPrice']:checked"),function(index,value) {
										upfrontCostArr.push($(value).val());
								});

								$.each(upfrontCostArr,function(index,entry) {
										operations.moveContentToTariffRow(planID,entry);
							    });
									
					
					}
					//clear all the check boxes
					$('[name="radioPrice"]').prop('checked',false);
					$('#chkSelectAll').prop('checked',false);
					$('#select-all').css("display","block");
					$('#tariffInfoDiv').css("display","block");

		 	} else {
		 		//alert('Please select prices/prices.');
		 		modalDialogBoxMessage="Please select prices/prices.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});

		 	}
		 	$(".chkbox").unbind( "change" ).bind( "change", function() {
			  		if($('#chkSelectAll').get(0).checked){
			  			$("#chkSelectAll").prop("checked",false);
			  		}	
			});

		 	
	}

	var saveTariffbtnHandler=function(e){
			    var isFormValid=$('#save-form')[0].checkValidity(); 
			 	var isValid=displayData.colorCloneForSamePlanID();

			 	if(isFormValid==true && isValid==true )
			 	{

							var requestArray=[];
							var getAllTarifs=$('#TariffRowContainer').children();
							var getUpdatedTariffs=getAllTarifs.not('.noColor');

							if(getAllTarifs.length<1 && getUpdatedTariffs.length<1){
								//alert('Please add Tariff Upsell Element.');
								modalDialogBoxMessage="Please add Tariff Upsell Element.";
								$("#lblMessageBox").text(modalDialogBoxMessage);
								$( "#msgDialog" ).dialog({
								 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
								});
							}else if(getUpdatedTariffs.length==0){
								//alert('Sorry ,Unassociated plans could not be saved.Please add a associated Tariff Upsell Element.');
								modalDialogBoxMessage="Sorry ,Unassociated plans could not be saved.Please add a associated Tariff Upsell Element.";
								$("#lblMessageBox").text(modalDialogBoxMessage);
								$( "#msgDialog" ).dialog({
								 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
								});
							}
							else {

								modalDialogBoxMessage='Are you sure ,you want to save?';
									if(getAllTarifs.length>getUpdatedTariffs.length){
										modalDialogBoxMessage=modalDialogBoxMessage+"...(Note : Unassociated planIds will not be saved.)";
									}
								$("#lblMessageBox").text(modalDialogBoxMessage);
								$("#msgDialog").dialog({
						    		modal:true,
									  buttons: [{
									      text: "Save",
									      click: function() {
									      	//display loaing image on page
									$('#loader').show();
							
									$.each(getUpdatedTariffs, function(index, element) {
									var obj={};
									var temp
										obj.planId=$(element).find('.clsPlanIDinput').val();
										obj.upfrontCostInPence=$(element).find('#upfrontCostInPense .clsUpfrontCostInput').val();
										obj.sortOrdinal=$(element).find('.clsSortOrdinal .clsUpfrontCostInput').val();
										obj.promotionAttachmentId=$(element).find('.clsPromotionInput').val();
										obj.promotionDetailAttachmentId=$(element).find('.promotionDetailAttachmentId').val();
										//delete object property if it is ''(empty)
										for(var item in obj){
											if(obj[item]=='' ||obj[item]==' '){
												delete obj[item];
											}
											if(obj[item]=='' ||obj[item]=='undefined'){
												delete obj[item];
											}
										}
										//push elements into an array through function
										displayData.myFunc(obj,requestArray);
										
									});
										//Send data to write in our file
										$.ajax({
												url: '/saveIntoFile',
												type:'POST',
												data: JSON.stringify(requestArray),
												dataType: 'JSON',
												success: callBacks.OnSaveFileSuccess,
											    error: callBacks.OnSaveFileFail,
												}).always(function(){
													$('#loader').hide();
												});

									      	$(this).dialog('close');
										  }
									    },{
									      text: "Cancel",
									      click: function() {
									      	$(this).dialog('close');
										  }
									    }]
									});	
									
							}
						 } 
						/* else if(!isFormValid){

						 } else if(!isValid) {
						   alert('Price is not correct in tariff Upsell.');
						 }*/
	}

	var addTariffbtnHandler=function(){
			var element=$('#TariffRowContainer');
			if(element.children().length==0){
				globalSortOrdinalValue=1;
				$('#select-all').css("display","block");
				$('#tariffInfoDiv').css("display","block");
				$("#chkSelectAll").prop("checked",false);

			}
			//prepend the element
			htmlEle=displayData.createTariffUpsellRows(planID,upfrontCostInPense,globalSortOrdinalValue,promotionAttachmentId,promotionDetailAttachmentId)
			//once created a new tariff upsell increment tariff upsell value 
			globalSortOrdinalValue++;
			element.append(htmlEle);

					$(".chkbox").unbind( "change" ).bind( "change", function() {
					  		if($('#chkSelectAll').get(0).checked){
					  			$("#chkSelectAll").prop("checked",false);
					  		}	
					});

					$('.clsPlanIDinput,#upfrontCostInPense .clsUpfrontCostInput').unbind( "change" ).bind( "change", function() {
						displayData.colorCloneForSamePlanID();
					});

	}

	var removeTariffbtnHandler=function(){

			var Obj=operations.checkcheckboxSelected();
			if(Obj.isCheckBoxSelected){
					(Obj.SelectedEleArr).forEach(function(entry) {
					    $(entry).remove();
					});

			} else {
				  // alert('Please select element/elements.');
				   modalDialogBoxMessage="Please select element/elements.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
			}


			if($('#TariffRowContainer').children().length==0){
			  		$('#select-all').css("display","none");
			  		$('#tariffInfoDiv').css("display","none");
			  		$('#chkSelectAll').prop('checked',false);
			  		

			 }else { callBacks.onDropCall(); }
	}

	var calculateMaxLength=function calculateMaxLength(txtInput){
		
		var maxLength=50,countForPoundSign=0;
		countForPoundSign = (txtInput.toUpperCase().match(/&POUND;/g) || []).length;
		maxLength=maxLength+(7*countForPoundSign);
		return maxLength;
    }

    var onBlur=function Validate() {
      
      var flag=true;
      var maxLength=0,txtInput=$(this).val();
      maxLength=calculateMaxLength(txtInput);
      
      if(txtInput.length>=maxLength){
        $(this).next().css('display','inline-block');
        flag=false;
      }else{
        $(this).next().css('display','none');
        flag=false;
      } 
      
      return flag;
    }

  	var onFilSelectdDdl  =function onFilSelectdDdl(){
              var inputArr=new Array();
              var selectedText=$(this).children(':selected').val();
              if (selectedText==='selectFile') {
              	   $('#txt-refernce-filename').prop("disabled", false);
		           $('#txt-BD-ref-promocode').prop("disabled", false);
		           $('#txt-UD-ref-promocode').prop("disabled", false);
		           $('#btnValidate').prop("disabled", false);
				   $('.displayPrimaryRbn').css("display","none");
		           $('.displaySeconaryRbn').css("display","none");
		           $('#txt-refernce-filename').val('');
		           $('#txt-BD-ref-promocode').val('');
		           $('#txt-UD-ref-promocode').val('');
                   //alert('Please select a file.');
                  modalDialogBoxMessage="Please select a file.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
              } else {

              	inputArr.push(selectedText);

             	$.ajax({
                url: '/postFileReadReference',
                type:'POST',
                data: JSON.stringify(inputArr),
                dataType: 'JSON',
                async:false,
                success: callBacks.OnReferenceFoundSuccess,
                });

              }
             
  	}

    var btnValidate=function(){
	
		var htmlfilename=$('#txt-refernce-filename').val();
	    var isBDRefDisabled=$('#txt-BD-ref-promocode').prop('disabled');
	    var isUDRefDisabled=$('#txt-UD-ref-promocode').prop('disabled');
	    var BDrefPromoCode=$('#txt-BD-ref-promocode').val();
	    var UDrefPromoCode=$('#txt-UD-ref-promocode').val();
	    var isFormValid=false;
	    prodCatalogPath=  localStorage.getItem("prodCatalogPath");
	    /*var primaryRibbon=$("#primaryRibbon").val();
		var secondaryRibbon=$("#secondaryRibbon").val();*/

		var primaryRibbon=replaceAll('£','&pound;', $("#primaryRibbon").val());
  		var secondaryRibbon=replaceAll('£','&pound;',$("#secondaryRibbon").val());

	    var fileExtension=htmlfilename.substr(htmlfilename.length-5,htmlfilename.length);

	    //If Ref is already present in textbox and text box is disabled passing the disabled for this field
	    if(isBDRefDisabled){ BDrefPromoCode='disabled' }
	    if(isUDRefDisabled){ UDrefPromoCode='disabled'}

	    if($('#createHtmlFilePromoCodeRef')[0].checkValidity()===false) {
	    		
			
	   	} else if(fileExtension!=='.html' && htmlfilename.length>0){
			//alert('Sorry ,file extension should be .html.');
						modalDialogBoxMessage="Sorry ,file extension should be .html.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
		} else if(prodCatalogPath==null || prodCatalogPath==''){
					    // alert('Please set catalogue path.');
					     modalDialogBoxMessage="Please set catalogue path.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
	    }  else if(primaryRibbon=='' && secondaryRibbon==''){
						modalDialogBoxMessage="Please provide either Primary Ribbon or Secondar Ribbon to write into HTML file.";
						$("#lblMessageBox").text(modalDialogBoxMessage);
						$( "#msgDialog" ).dialog({
						 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
						});
	     
	    } else if($('#createHtmlFilePromoCodeRef')[0].checkValidity()) {

	    	modalDialogBoxMessage='Are you sure,you want to perform this operation?';
	    			$("#lblMessageBox").text(modalDialogBoxMessage);
								$("#msgDialog").dialog({
								modal:true,
									 buttons: [{
									      text: "Ok",
									      click: function() {
									      	 $('#loader').show();

									          var fileNamePromoCodeRefArr=[];
									          fileNamePromoCodeRefArr.push(htmlfilename.trim());
									          fileNamePromoCodeRefArr.push(BDrefPromoCode.trim());
									          fileNamePromoCodeRefArr.push(UDrefPromoCode.trim());
									          fileNamePromoCodeRefArr.push(prodCatalogPath.trim());
									          fileNamePromoCodeRefArr.push(primaryRibbon.trim());
									          fileNamePromoCodeRefArr.push(secondaryRibbon.trim());

									          $.ajax({
									          url: '/postfileNamePromoCodeCreateFilegetRef',
									          type:'POST',
									          data: JSON.stringify(fileNamePromoCodeRefArr),
									          dataType: 'JSON',
									          success: callBacks.crateFileandPromoCodeSuccess
									          }).always(function(){
									  			       $('#loader').hide();
									  		      });

										  	   $(this).dialog('close');
									       }},{
									      text: "Cancel",
									      click: function() {
									      	$(this).dialog('close');
										  }
									   }]
								
					});

	    }

    }

    var setProdCatPath=function setProdCatPath(){
    	$( "#setPathDialog" ).dialog({
    		title:'Prod Catalog Path Set',
    		modal:true,
			  buttons: [
			    {
			      text: "OK",
			      click: function() {
			      
				        var catalogPath=$(this).find('#txtCataloguePath').val();
				        if(catalogPath==null || catalogPath==''){
							alert('Catalogue path can not be empty.');
							/*	modalDialogBoxMessage="Catalogue path can not be empty.";
							$("#lblMessageBox").text(modalDialogBoxMessage);
							$( "#msgDialog" ).dialog({
							 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
							});*/
						}else {
							localStorage.setItem("prodCatalogPath", catalogPath);
							$(this).find('#txtCataloguePath').val('')
							//alert('Catalogue path has been set successfully..!');
							modalDialogBoxMessage="Catalogue path has been set successfully..!!";
							$("#lblMessageBox").text(modalDialogBoxMessage);
							$( "#msgDialog" ).dialog({
							 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
							});
							$(this).dialog('close');
						}
			      }
			    }
			  ]
			});
    }

    var btnClearHandler=function btnClearHandler(){

    	   $('#txt-refernce-filename').prop("disabled", false);
           $('#txt-BD-ref-promocode').prop("disabled", false);
           $('#txt-UD-ref-promocode').prop("disabled", false);
           $('#txt-refernce-filename').val('');
           $('#txt-BD-ref-promocode').val('');
           $('#txt-UD-ref-promocode').val('');
           $('#btnValidate').prop("disabled", false);

    }

  var replaceAll=function replaceAll(find, replace, str) {

  while( str.indexOf(find) > -1)
  {
    str = str.replace(find, replace);
  }
  return str;

}
				
	//Initialization is done here
	function initialize() {
		
		$('#btnDeviceSearch').click(btnDeviceSearch);
		$('#btnCheck').click(btnCheck);
		/*$('#btn-set-catalog-path').click(setPath);*/
		$('#clearSortOrdinal').click(clearSortOrdinal);
		$('#TariffRowContainer').sortable(sortable);
		$("#chkSelectAll").change(chkSelectAll);
		$('#clearPromoAttachID').click(clearPromoAttachID);
		$('#move-planIDs-btn').click(movePlanIDBtnHandler);			
		$('#saveTariffbtn').click(saveTariffbtnHandler);
		$('#addTariffbtn').click(addTariffbtnHandler);
		$('#rmvTariffbtn').click(removeTariffbtnHandler);
	    $('#primaryRibbon').blur(onBlur);
	   // $('#secondaryRibbon').blur(onBlur);
	    $("#ddlFilename").change(onFilSelectdDdl);
	    $("#btnValidate").click(btnValidate);
	    $("#setProdCaLogPath").click(setProdCatPath);
	    $("#btnClear").click(btnClearHandler);


	}	

	return {
		init:initialize
	};

});

require(['app'],function(app) {

   //Initialization is done here
   app.init();
});



