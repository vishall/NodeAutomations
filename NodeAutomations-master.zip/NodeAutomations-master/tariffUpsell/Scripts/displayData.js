define('displayData',["jquery","tariffUpsellOperations"],function($,tariffUpsellOperations){

	var colorArr=['#fcdeba','#bdf1ca','#faf5b5','#deeebf','#bef1ea','#c4bcd4','#feb6b7','#f8efe6','rgb(233, 185, 245)','#c9ddf0','#d5ef8b','#b0f1e5'];
	var colorCodeCount=0;

	//Function to get planIDs from json file corresponding to specific Device ID.
	function getPlanIdFromJSONFileByDevideID(planIDsJsonFileData,fileData){
			colorCodeCount=0;
			var isDataReturned;
			//remove the children if there are any
			$('#PlanIdRowsContent').children().remove();
			
			if(planIDsJsonFileData!=='notResultsFound' && planIDsJsonFileData.length>0){
				isDataReturned=true;
				$('#move-planID-btn-Div').css("display","block");
				planIDsJsonFileData.forEach(function (element, index) {
							var planID=(element.id==undefined) ? "" : element.id;

							var productID=(element.productID==undefined) ? "" : element.productID;
							var monthlyPrice = "";
							var pricesIncremented=element.prices.sort(function (a, b) {  return a - b;  });
							pricesIncremented.forEach(function(entry) {
								   entry= ((Math.round((parseFloat(entry)*100) * 100) )/ 100);
								   monthlyPrice=monthlyPrice+'<input type="checkbox" name="radioPrice" value="'+entry+'">'+entry;
								});
								var colorCode=getColorCode();
							htmlEle=createPlanIDRows(planID,productID,monthlyPrice,colorCode);

							//get element to which we need to append and append the element to it
							$('#PlanIdRowsContent').append(htmlEle);
				});

			} else if(planIDsJsonFileData.length===0){
				isDataReturned=false;
				//$('#move-planID-btn-Div').css("display","none");
			   // alert('Sorry,No data found for given device Id in prod catlog.');
			    modalDialogBoxMessage="Sorry,No data found for given device Id in prod catlog.";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });
			}

			return isDataReturned;
			
	}

	//function to get tariffUpsell values on Our page
	function getTariffRowsByDevideID(fileData){
	

			if(fileData!=='notResultsFound' && fileData.length>0){
			//display select all checkbox 	
			$('#select-all').css("display","block");	
			$('#tariffInfoDiv').css("display","block");

			fileData.forEach(function (element, index) {
				var planID=element.planId==undefined ? "" : element.planId;
				var upfrontCostInPense=parseInt(element.upfrontCostInPence==undefined ? "" : element.upfrontCostInPence);
				//get sort ordinals in incremented order on page
				var sortOrdinal=parseInt((element.sortOrdinal==undefined) ? "" : element.sortOrdinal);
				//var sortOrdinal=globalSortOrdinalValue;
				globalSortOrdinalValue++;
				var included=element.included==undefined ? "" : element.included;
				var promotionDetailAttachmentId=element.promotionDetailAttachmentId==undefined ? "" : element.promotionDetailAttachmentId;
				htmlEle=createTariffUpsellRows(planID,upfrontCostInPense,sortOrdinal,included,promotionDetailAttachmentId)
				//get element to which we need to append and append the element to it
				$('#TariffRowContainer').append(htmlEle);
							//change function for all the checkboxes
							$(".chkbox").unbind( "change" ).bind( "change", function() {
							  		if($('#chkSelectAll').get(0).checked){
							  			$("#chkSelectAll").prop("checked",false);
							  		}	
							});
			
			});
																	
			} else if(fileData.length===0) {
			$('#select-all').css("display","none");
			$('#tariffInfoDiv').css("display","none");
		    // alert('Sorry, no tariffRows found for the Device Id in tariffUpsell.txt.');
		     modalDialogBoxMessage="Sorry, no tariffRows found for the Device Id in tariffUpsell.txt.";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });
		   } else if(fileData==="notResultsFound"){
		   		$('#select-all').css("display","none");
			    $('#tariffInfoDiv').css("display","none");

			    confirmBoxTxt='Sorry, no Device found. Do you want to create new device ID in in tariffUpsell.txt?';
			    var confirmResult = confirm(confirmBoxTxt);

				if (confirmResult) {
			    var inputGUID=$('.searchDvcDIVelements[name=txtMainInput]').val();
			    writeNewDeviceIdInTariffUpsell(inputGUID);
				}

		   } 	

	}

	 //function to get he same color for the same plan IDs
	function colorCloneForSamePlanID(){
				var childrenTariffUpsellContent=$('#TariffRowContainer').children();
				var childrenDeviceJsonContent=$('#PlanIdRowsContent').children();
				var samePlanIdElements=[];
				var colorCode='',priceArr='';
				var isPriceSame=false;
				var isSubmitOk=true;

				if(childrenTariffUpsellContent.length>0){
					childrenTariffUpsellContent.addClass( "noColor" );
					childrenTariffUpsellContent.css('background',colorCode);
				}

				if(childrenDeviceJsonContent.length!=0 && childrenTariffUpsellContent.length!=0 ){
					for(var i=0;i<childrenDeviceJsonContent.length;i++){
						samePlanIdElements=[];
						colorCode=$(childrenDeviceJsonContent[i]).css("background-color");
						priceElements=$(childrenDeviceJsonContent[i]).find("[name='radioPrice']");
						priceArr=[];
							$.each(priceElements, function( index, value ) {
								  priceArr.push(value.value)
							});

						
				   	for(var j=0;j<childrenTariffUpsellContent.length;j++){

				 	var included=$(childrenTariffUpsellContent[j]).find('.clsPromotionInput').val();
				 	var sortOrdinal=$(childrenTariffUpsellContent[j]).find('.clsSortOrdinal .clsUpfrontCostInput').val();
					var promotionDetailAttachmentId=$(childrenTariffUpsellContent[j]).find('.clsPromotionInput').val();

			 		if(included!='' || sortOrdinal!=''){

		 			if($(childrenTariffUpsellContent[j]).hasClass('sortOrdinalAndPromoIdMandatory')){
		 				$(childrenTariffUpsellContent[j]).removeClass('sortOrdinalAndPromoIdMandatory');
		 				$(childrenTariffUpsellContent[j]).find('.star').css('color','red');
		 			}

		 			if($(childrenDeviceJsonContent[i]).find('.clsPlanIDlbl')[0].textContent.trim()==$(childrenTariffUpsellContent[j]).find('.clsPlanIDinput').val()){
						samePlanIdElements.push($(childrenTariffUpsellContent[j]));
						
						if($(childrenTariffUpsellContent[j]).find('#upfrontCostInPense .clsUpfrontCostInput').val()!=''){
							isPriceSame=false;
					for(var k=0;k<priceArr.length;k++){
						 if(priceArr[k]==$(childrenTariffUpsellContent[j]).find('#upfrontCostInPense .clsUpfrontCostInput').val()){
						 	isPriceSame=true;
						 		if(isPriceSame==true){
						 			break;
						 		}
							}
					}
					}
					else {
						isPriceSame=true;
					$(childrenTariffUpsellContent[j]).find('#upfrontCostInPense .clsUpfrontCostInput').css({"border": "","background": ""});
					}

					if(isPriceSame==false)
					{
						isSubmitOk=false;
						$(childrenTariffUpsellContent[j]).find('#upfrontCostInPense .clsUpfrontCostInput').css({"border": "1px solid red","background": "#FFCECE"});
						$(childrenTariffUpsellContent[j]).find('#upfrontCostInPense .clsUpfrontCostInput').addClass('invalidPrice');
					} else {
						$(childrenTariffUpsellContent[j]).find('#upfrontCostInPense .clsUpfrontCostInput').css({"border": "","background": ""});
					}
				
					}	
							
			 		  } else {

			 		  	isSubmitOk=false;
			 		  	$(childrenTariffUpsellContent[j]).addClass("sortOrdinalAndPromoIdMandatory");
			 		  	$(childrenTariffUpsellContent[j]).find('.star').css('color','white')
			 		  }


				   	}
						if(samePlanIdElements.length!=0){
							
							samePlanIdElements.forEach(function(entry) {
							    $(entry).css('background',colorCode);
							    $(entry).removeClass( "noColor" )
							});

							
								//$(childrenTariffUpsellContent[j]).css('background',colorCode);
						}
					}
				}

					$('.clsPlanIDinput,#upfrontCostInPense .clsUpfrontCostInput').unbind( "change" ).bind( "change", function() {
						colorCloneForSamePlanID();
					});

				

				return isSubmitOk;
	
	}

	function getColorCode(){
		var code='';

		if(colorCodeCount<(colorArr.length)){
			code=colorArr[colorCodeCount];
			colorCodeCount++;
		} else {
			code='#'+Math.floor(Math.random()*16777215).toString(16);
		}
		return code;

	}

	//To get getTariffUpsellContent divs 
	function createTariffUpsellRows(planID,upfrontCostInPense,sortOrdinal,included,promotionDetailAttachmentId){
			
			return  "<div class='clsPlanDiv noColor'><div class='chkbxDiv'><input  type='checkbox' class='chkbox' name='chkbx'></div>"
			+"<div> <span>planID<span class='star'>*</span> : </span><input class='clsPlanIDinput' type='text' value='"+planID+"' name='test' required></div><div class='clear'></div>"
			+"<div class='clsupfrontSortContent spaceBetween'>"
			+"<div id='upfrontCostInPense'><span>upfrontCostInPense<span class='star'>*</span> : </span><input class='clsUpfrontCostInput' value='"+upfrontCostInPense+"' type='text' required></div>"
			+"<div class='clsSortOrdinal'> <span>SortOrdinal : </span><input type='text' class='clsUpfrontCostInput' value='"+sortOrdinal+"'> </div></div><div class='clear'></div>"
			+"<div class='spaceBetween'> <span>included : </span><input class='clsPromotionInput'  value='"+included+"' type='text' ></div><div class='clear'></div>"
			+"<div class='spaceBetweenId'> <span>promotionDetailAttachmentId : </span><input class='promotionDetailAttachmentId'  value='"+promotionDetailAttachmentId+"' type='text' ></div></div></div>";

	}

	function createPlanIDRows(planID,plancost,monthlyPrice,color){
		
			return "<div style='background:"+color+"' class='clsPlanDiv'><div> <span>planID : </span><label class='clsPlanIDlbl'>"+planID+"</label></div>"
			+"<div class='clsupfrntcstpenseDJC'> <span>PID : </span><label class='clsPlanIDlbl'>"+plancost+"</label></div>"
			+"<div> <span>upfrontCostInPense : </span><label class='clsPlanIDlbl'>"+monthlyPrice+"</label></div></div>";
		
		
	}
	function myFunc(obj,requestArray){
		requestArray.push(obj);
	};

	var writeNewDeviceIdInTariffUpsell=function writeNewDeviceIdInTariffUpsell(inputGuiD){
		
		$('#loader').show();
		var inputGuidArr=[];
		inputGuidArr.push(inputGuiD.trim());

		$.ajax({
			url: '/writeNewDeviceIdInTariffUpsell',
			type:'POST',
			data: JSON.stringify(inputGuidArr),
			dataType: 'JSON',
			success: OnwriteNewDeviceIdInTariffUpsellSuccess,
			}).always(function(){
				$('#loader').hide();
		});

    }

     var OnwriteNewDeviceIdInTariffUpsellSuccess = function(data){

        if(data.response===true){
           // alert('Device Id created in tariffUpsell.txt file Successfully.'); 
            modalDialogBoxMessage="Device Id created in tariffUpsell.txt file Successfully !!";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });
        } else {
           // alert('Sorry..problem occurred while saving the data !');
            modalDialogBoxMessage="Sorry..problem occurred while saving the data !";
                $("#lblMessageBox").text(modalDialogBoxMessage);
                $( "#msgDialog" ).dialog({
                 modal:true,buttons: [{text: "OK",click: function() { $(this).dialog('close');}}]
                });
        }
            
    }


	return {
			getPlanIdFromJSONFileByDevideID:getPlanIdFromJSONFileByDevideID,
			getTariffRowsByDevideID:getTariffRowsByDevideID,
			colorCloneForSamePlanID:colorCloneForSamePlanID,
			createTariffUpsellRows:createTariffUpsellRows,
			myFunc:myFunc,
		
		};

});