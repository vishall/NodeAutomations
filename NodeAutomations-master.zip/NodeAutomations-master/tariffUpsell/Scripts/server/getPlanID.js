
var fs = require('graceful-fs');
var Q = require('q');
var glob = require('glob');
var relationships=[];
var pathRegExp = /\$\{(.*?)\}/g;
var regExp = /"id"(((\s*)(:|=)(\s*)))(((.|\n)[^,\r](?!((.+?)(:|=))))+)/;
var newPathsContainer = [];

var getPlanIdsByDeviceId=function(inputGUID,prodCatalogLoc) {
    var deferred = Q.defer();
    var relationships=[];

    require.extensions['.json'] = function(module, filename) {
     module.exports = fs.readFileSync(filename, 'utf8');
    };

    glob(prodCatalogLoc+"/device/**/*.json", function(err, files) {
   
    var JsonFiles = files.filter(function(file) {
      return file.substr(-5) === '.json';
    });
    
    for (var i = 0; i < JsonFiles.length; i++) {
      
      var file=JsonFiles[i];
      checkStandard(file);
      deviceJson = json;

      if (deviceJson["id"] == inputGUID) {

        if (deviceJson["relationships"]) {
          for (var plan = 0; plan < deviceJson["relationships"].length; plan++) {
            if (deviceJson["relationships"][plan]["prices"]) {

              var priceLength = deviceJson["relationships"][plan]["prices"].length;

              if ( priceLength > 1) {
              if (deviceJson["relationships"][plan]["id"].indexOf("-shared-") === -1) {

                //get Path for plan files for PID
                var arr = deviceJson["relationships"][plan]["id"].toString().split("\'");
                file = prodCatalogLoc + arr[1].trim();

                var oneOffPriceArr=[];
                //push all oneOff values into an array
                for(var index in deviceJson["relationships"][plan]["prices"]) {
                  var currentVal=deviceJson["relationships"][plan]["prices"][index];
                  oneOffPriceArr.push(currentVal.oneOff);   
                };

                //sort array price and push values into object
                deviceJson["relationships"][plan]["prices"]=oneOffPriceArr.sort();
                checkStandard(file);
                deviceJson["relationships"][plan]["id"] = ""+json["id"];                                                
                deviceJson["relationships"][plan]["productID"] = json["productID"]; 
                //push elements into relationship array
                addElement(deviceJson["relationships"][plan] ,relationships);

                }
              }
            }
          }
        }

        break;
      }

    }
    deferred.resolve(relationships);
    });  

    return deferred.promise;
 
 } 

module.exports = {
               getPlanIdsByDeviceId: getPlanIdsByDeviceId
          };

function checkStandard(file) {

  var content = require(file);
  delete require.cache[file];
  var newContent = content;
  var newSearch = newContent.match(pathRegExp);
  
  if (newSearch != null) {

  var uniqueArray = newSearch.filter(function(elem, pos) {
  return newSearch.indexOf(elem) == pos;
  });

  for (var i = 0; i < uniqueArray.length; i++) {
    var planPathValue = '"' + uniqueArray[i] + '"';
    var regExpCheck = new RegExp(escapeRegExp(uniqueArray[i]), "g");
    newPathsContainer.push(uniqueArray[i]);
    newContent = newContent.replace(regExpCheck, planPathValue);
    var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
  }

  json = JSON.parse(newContent);
  } else {

  json = JSON.parse(newContent);
  }
  return json;

}


function escapeRegExp(str) {
  return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function addElement(test,relationships){
        relationships.push(test);
}

