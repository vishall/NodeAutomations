var fs = require('graceful-fs');
var Q = require('q');
var beautify = require('js-beautify');
var postFileNameGetPromoCode = require("./postFileNameGetPromoCode.js");
var pathRegExp = /\$\{(.*?)\}/g;
var regExp = /"id"(((\s*)(:|=)(\s*)))(((.|\n)[^,\r](?!((.+?)(:|=))))+)/;

var checkIfFileNamePresentInDropDownList=function checkIfFileNamePresentInDropDownList(htmlFileName,filenamesArr){

  var isFilePresentInDdl=false;
  if(filenamesArr.length>0){

          isFilePresentInDdl=false;

          filenamesArr.forEach(function(entry) {

             if(entry==htmlFileName){
              isFilePresentInDdl=true;
              }
          });
    }
    return isFilePresentInDdl;
}

var insertPromoCodeRefInBDAndUD=function insertPromoCodeRefInBDAndUD(htmlFileName,refPromoCode,path){

  var deferred = Q.defer();

    require.extensions['.json'] = function(module, filename) {
       module.exports = fs.readFileSync(filename, 'utf8');
    };

      var fileContent = require(path);
      delete require.cache[path];  
      var newSearch = fileContent.match(pathRegExp);
      //Regex to find array pattern in content of the file
      var matchFound = fileContent.match("\\[[^\\]]*]");

      if (newSearch != null) {

      var nonStandardPathRegExpElemArray = newSearch.filter(function(elem, pos) {
        return newSearch.indexOf(elem)==pos;
      });


      RefElementToAddInBD="${attachment('attachments/browsingDesktop/"+htmlFileName+"', '"+refPromoCode+"', 'text/html')}";
      nonStandardPathRegExpElemArray.push(RefElementToAddInBD);

     if(matchFound!='' || matchFound!=null){
        fileContent = fileContent.replace(matchFound, "["+'\n\t'+nonStandardPathRegExpElemArray.join(","+'\n\t')+'\n\t'+"]")
     }
   }

   
    var isPromoRefCreated=false;
    fs.writeFile(path,fileContent, function(err) {
      if (err) {
       console.log('Something went wrong YES');
       isPromoRefCreated=false;
        deferred.resolve(isPromoRefCreated);
      }
      else {
       isPromoRefCreated=true;
       deferred.resolve(isPromoRefCreated);
       
      }

    });

  return deferred.promise;

}

var checkIfRefAlreadyPresent=function checkIfRefAlreadyPresent(refPromoCode,path){

  var isRefPresentInWholeFile=false;
  require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
  };  

  var fileContent = require(path);
  delete require.cache[path];
  var newSearch = fileContent.match(pathRegExp);

  //var upgradeDsktpRefFoundArr=[];

  if (newSearch != null) {
    var nonStandardPathRegExpElemArray = newSearch.filter(function(elem, pos) {
    return newSearch.indexOf(elem)==pos;
    });

      for(var i=0;i<nonStandardPathRegExpElemArray.length;i++){
       
        var splitArr=nonStandardPathRegExpElemArray[i].split(',');
        if(splitArr[1].substring(2,splitArr[1].length-1)==refPromoCode){
          isRefPresentInWholeFile=true;
            break;
        }
      }
   }

  return isRefPresentInWholeFile;

}


var isPromoRefPresentForHtmlFile=function isPromoRefPresentForHtmlFile(htmlFileName,path){

    var promoCodeBDRefArr=[],isPromoRefPresent=false,arrOfRef=[];
    var BDfilePath=browsingDesktopFilePath+"\\media\\browsingDesktop.json";
    var UDfilePath=upgradeDesktopFilePath+"\\media\\upgradeDesktop.json";

    if(path===BDfilePath){
          arrOfRef=postFileNameGetPromoCode.checkRefereinBrowseDesktop(htmlFileName,browsingDesktopFilePath);
    } else {
          arrOfRef=postFileNameGetPromoCode.checkRefereinUpgradeDesktop(htmlFileName,upgradeDesktopFilePath);
    }
    
    promoCodeBDRefArr=postFileNameGetPromoCode.getPromoCodeRefArr(arrOfRef);

    
      if(promoCodeBDRefArr.length===0){
        isPromoRefPresent=false;
       
      } else {

        isPromoRefPresent=true;
      }
    return isPromoRefPresent;
}

module.exports = {
  checkIfFileNamePresentInDropDownList:checkIfFileNamePresentInDropDownList,
  insertPromoCodeRefInBDAndUD:insertPromoCodeRefInBDAndUD,
  checkIfRefAlreadyPresent:checkIfRefAlreadyPresent,
  isPromoRefPresentForHtmlFile:isPromoRefPresentForHtmlFile
 
};

 