
var fs = require('graceful-fs');
var Q = require('q');

var postRibbonsGetFileName = require("./postRibbonsGetFileName.js");
var pathRegExp = /\$\{(.*?)\}/g;
var regExp = /"id"(((\s*)(:|=)(\s*)))(((.|\n)[^,\r](?!((.+?)(:|=))))+)/;

var getPromoCodeRefArr=function getPromoCodeRefArr(browsingDRefFoundArr){
 //var ob = new Object();
  var referenceArr=new Array();

    if(browsingDRefFoundArr.length>0){
      browsingDRefFoundArr.forEach(function(element,index) {
        var splitArr=element.split(',');
        referenceArr.push(splitArr[1].substring(2,splitArr[1].length-1));
      });
    }
  return referenceArr;

} 

var createHTMLFile=function createHTMLFile(htmlFileName,primaryRibbon,secondaryRibbon,prodCatalogLoc){
    var deferred = Q.defer();
    var html = require("html");
    var isFileCreated=false,contentToWrite='';

    if(primaryRibbon!='' && secondaryRibbon !=''){

      contentToWrite ="<div class=offer-wrapper><div class=offer data-qa-promotion>"
      +"<p>"+primaryRibbon+"</p></div></div>"
      +"<div class=promo-banner data-qa-additional-promo><p>"+secondaryRibbon+"</p></div>";
      

    } else if(primaryRibbon!=''){
   
        contentToWrite ="<div class=offer-wrapper><div class=offer data-qa-promotion>"
      +"<p>"+primaryRibbon+"</p></div></div>"
      +"<div class=promo-banner data-qa-additional-promo></div>";

    } else if( secondaryRibbon !=''){
     
      contentToWrite ="<div class=offer-wrapper><div class=offer data-qa-promotion>"
      +"<p></p></div></div>"
      +"<div class=promo-banner data-qa-additional-promo><p>"+secondaryRibbon+"</p></div>";
      
    }

   

    fs.writeFile(prodCatalogLoc+'/media/attachments/browsingDesktop/'+htmlFileName,html.prettyPrint(contentToWrite, { indent_size: 2 }), function(err) {
    if (err) {

      isFileCreated=false;
      deferred.resolve(isFileCreated);
    
    }
    else {
       isFileCreated=true;
       deferred.resolve(isFileCreated);
    }
   });

    return deferred.promise;

}

var checkHtmlFilePresent=function checkHtmlFilePresent(htmlFileName,prodCatalogLoc){
  var recursiveReadSync = require('recursive-readdir-sync');
  var isFilePresent=false;

  try {
    files = recursiveReadSync(prodCatalogLoc+"/media/attachments/browsingDesktop/");
    
    for(var i=0;i<files.length;i++){
      
      var filename=files[i].split('\\')[files[i].split('\\').length-1];
      if(htmlFileName.trim()==filename.trim()){
          isFilePresent=true;
            break;
      }
    }
  } catch(err){
    if(err.errno === 34){
      console.log('Path does not exist');
    } else {
    //something unrelated went wrong, rethrow 
      throw err;
    }
  }
  return isFilePresent;

}

var checkRefereinBrowseDesktop=function checkRefereinBrowseDesktop(filename,browsingDesktopFilePath){


  require.extensions['.json'] = function(module, filename) {
   module.exports = fs.readFileSync(filename, 'utf8');
  };

  var fileContent = require(browsingDesktopFilePath+"\\media\\browsingDesktop.json");
  delete require.cache[browsingDesktopFilePath+"\\media\\browsingDesktop.json"]; 
  var newSearch = fileContent.match(pathRegExp);
  var browsDsktpRefFoundArr=[];

  if (newSearch != null) {
    var nonStandardPathRegExpElemArray = newSearch.filter(function(elem, pos) {
    return newSearch.indexOf(elem)==pos;
  });
 
  browsDsktpRefFoundArr=[];
  for (var i = 0; i < nonStandardPathRegExpElemArray.length; i++) {
      if(nonStandardPathRegExpElemArray[i].indexOf("attachments/browsingDesktop/"+filename)>-1){
        browsDsktpRefFoundArr.push(nonStandardPathRegExpElemArray[i]);
      }
    }
  } 

  return browsDsktpRefFoundArr;

}

var checkRefereinUpgradeDesktop=function checkRefereinUpgradeDesktop(filename,upgradeDesktopFilePath){

  require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
  };  

  var fileContent = require(upgradeDesktopFilePath+"\\media\\upgradeDesktop.json");
  delete require.cache[upgradeDesktopFilePath+"\\media\\upgradeDesktop.json"];
  var newSearch = fileContent.match(pathRegExp);

  var upgradeDsktpRefFoundArr=[];
  if (newSearch != null) {
    var nonStandardPathRegExpElemArray = newSearch.filter(function(elem, pos) {
    return newSearch.indexOf(elem)==pos;
    });

    browsDsktpRefFoundArr=[];
      for (var i = 0; i < nonStandardPathRegExpElemArray.length; i++) {
        if(nonStandardPathRegExpElemArray[i].indexOf(filename)>-1){
        upgradeDsktpRefFoundArr.push(nonStandardPathRegExpElemArray[i]);
      }
    }
  } 
  return upgradeDsktpRefFoundArr;

}
  
module.exports = {
  getPromoCodeRefArr:getPromoCodeRefArr,
  checkHtmlFilePresent:checkHtmlFilePresent,
  createHTMLFile:createHTMLFile,
  checkRefereinBrowseDesktop:checkRefereinBrowseDesktop,
  checkRefereinUpgradeDesktop:checkRefereinUpgradeDesktop
 
};





