
var fs = require('graceful-fs');
var Q = require('q');
var glob = require('glob');

var getDatafromDirectoryForRibbon=function getDatafromDirectoryForRibbon(file,primaryRibbon,secondaryRibbon){
 
  var filename='',primaryRbnfromFile='',secondaryRbnfromFile='';
  var content = require(file);
  delete require.cache[file];
  var isPrimaryRbnPresnt=false;
  var isSecondaryRbnPresent=false;

  var htmlparser = require("htmlparser2");
  var handler = new htmlparser.DomHandler(function (error, dom) {
       
        for(var i=0;i<dom.length;i++){

              if(((dom[i].attribs!==undefined)?dom[i].attribs.class==='offer-wrapper':false)  && (dom[i].children[1]!==undefined?dom[i].children[1].children[1]!==undefined:false)){

                    if(dom[i].children[1].children[1]!==undefined?(dom[i].children[1].children[1].name!==undefined?(dom[i].children[1].children[1].name==='p' && dom[i].children[1].children[1].children[0]!==undefined?dom[i].children[1].children[1].children[0].data!==undefined:false):false):false){
                              isPrimaryRbnPresnt=true;
                              primaryRbnfromFile=dom[i].children[1].children[1].children[0].data.trim();
                       } 
               
              }

          if((dom[i].attribs!==undefined?dom[i].attribs.class==='promo-banner':false) && (dom[i].children[1]!==undefined?((dom[i].children[1].name!==undefined && dom[i].children[1].children[0]!==undefined)?(dom[i].children[1].name==='p' && dom[i].children[1].children[0].data!==undefined):false):false)){
               
                isSecondaryRbnPresent=true;
                secondaryRbnfromFile=dom[i].children[1].children[0].data.trim();

           }
          
      }
  });
  var parser = new htmlparser.Parser(handler);
  parser.write(content);
  parser.done();

  //Replace the £ with &POUND; for comparison
  var primRbnfromFile=replaceAll('£','&POUND;', primaryRbnfromFile.toUpperCase());
  var secRbnfromFile=replaceAll('£','&POUND;', secondaryRbnfromFile.toUpperCase());

  var primRbnInput=replaceAll('£','&POUND;', primaryRibbon.toUpperCase());
  var secRbnInput=replaceAll('£','&POUND;', secondaryRibbon.toUpperCase());


  if(primaryRibbon!=='' && secondaryRibbon!==''){ 
    if(isPrimaryRbnPresnt===true && isSecondaryRbnPresent===true ){  
      if(primRbnfromFile.indexOf(primRbnInput)>-1 && secRbnfromFile.indexOf(secRbnInput)>-1){
        filename=file.split('/')[file.split('/').length-1]; 
      }
    }
  } else if(primaryRibbon!=='' && secondaryRibbon===''){ 
    if(isPrimaryRbnPresnt===true && isSecondaryRbnPresent===false){ 
      if(primRbnfromFile.indexOf(primRbnInput)>-1){ 
        filename=file.split('/')[file.split('/').length-1]; 
      }
    }
  } else if(primaryRibbon==='' && secondaryRibbon!==''){ 
      if(isPrimaryRbnPresnt===false && isSecondaryRbnPresent===true){  
        if(secRbnfromFile.indexOf(secRbnInput)>-1){  
          filename=file.split('/')[file.split('/').length-1]; 
        }
      }
    }
  return filename;

}

/*var getDatafromDirectoryForRibbon=function getDatafromDirectoryForRibbon(file,primaryRibbon,secondaryRibbon){
  debugger;
  var filename='',primaryRbnfromFile='',secondaryRbnfromFile='';
  var content = require(file);
  delete require.cache[file];
  var isPrimaryRbnPresnt=false;
  var isSecondaryRbnPresent=false;

  var htmlparser = require("htmlparser2");
  var handler = new htmlparser.DomHandler(function (error, dom) {
       
        for(var i=0;i<dom.length;i++){

              if(((dom[i].attribs!==undefined)?dom[i].attribs.class==='offer-wrapper':false)  && (dom[i].children[1]!==undefined?dom[i].children[1].children[1]!==undefined:false)){

                    if(dom[i].children[1].children[1]!==undefined?(dom[i].children[1].children[1].name!==undefined?(dom[i].children[1].children[1].name==='p' && dom[i].children[1].children[1].children[0]!==undefined?dom[i].children[1].children[1].children[0].data!==undefined:false):false):false){
                              isPrimaryRbnPresnt=true;
                              primaryRbnfromFile=dom[i].children[1].children[1].children[0].data.trim();
                       } 
               
              }

          if((dom[i].attribs!==undefined?dom[i].attribs.class==='promo-banner':false) && (dom[i].children[1]!==undefined?((dom[i].children[1].name!==undefined && dom[i].children[1].children[0]!==undefined)?(dom[i].children[1].name==='p' && dom[i].children[1].children[0].data!==undefined):false):false)){
                
                isSecondaryRbnPresent=true;
                secondaryRbnfromFile=dom[i].children[1].children[0].data.trim();

           }
          
      }
  });
  var parser = new htmlparser.Parser(handler);
  parser.write(content);
  parser.done();

  //Replace the £ with &POUND; for comparison
  var primRbnfromFile=replaceAll('£','&POUND;', primaryRbnfromFile.toUpperCase());
  var secRbnfromFile=replaceAll('£','&POUND;', secondaryRbnfromFile.toUpperCase());

  var primRbnInput=replaceAll('£','&POUND;', primaryRibbon.toUpperCase());
  var secRbnInput=replaceAll('£','&POUND;', secondaryRibbon.toUpperCase());


  if(primaryRibbon!=='' && secondaryRibbon!==''){ 
    if(isPrimaryRbnPresnt===true && isSecondaryRbnPresent===true ){  
      if((primRbnfromFile===primRbnInput) && (secRbnfromFile===secRbnInput)){
        filename=file.split('/')[file.split('/').length-1]; 
      }
    }
  } else if(primaryRibbon!=='' && secondaryRibbon===''){ 
    if(isPrimaryRbnPresnt===true && isSecondaryRbnPresent===false){ 
      if(primRbnfromFile===primRbnInput){ 
        filename=file.split('/')[file.split('/').length-1]; 
      }
    }
  } else if(primaryRibbon==='' && secondaryRibbon!==''){ 
      if(isPrimaryRbnPresnt===false && isSecondaryRbnPresent===true){  
        if(secRbnfromFile===secRbnInput){  
          filename=file.split('/')[file.split('/').length-1]; 
        }
      }
    }
  return filename;

}*/

var checkRibbonsPresent=function(primaryRibbon,secondaryRibbon,prodCatalogLoc) {
  

  filenamesArr=[];
  var filename='';
  var deferred = Q.defer();

  require.extensions['.html'] = function(module, filename) {
   module.exports = fs.readFileSync(filename, 'utf8');
  };

  glob(prodCatalogLoc+"/media/attachments/browsingDesktop/**/*.html",{"ignore":['txt']}, function(err, files) {
   
    var HtmlFiles = files.filter(function(file) {
      return file.substr(-5) === '.html';
    });
  
    for(var i=0;i<HtmlFiles.length;i++){
      
      filename=getDatafromDirectoryForRibbon(HtmlFiles[i],primaryRibbon,secondaryRibbon);
      if(filename!=''){
        //Get the filename from whole directry path of the file
        var pathNameArr=filename.split('/');
        filenamesArr.push(pathNameArr[pathNameArr.length-1]);
      }
    }

    deferred.resolve(filenamesArr);
  }); 
  return deferred.promise;

}

var getRibbonsFromTheFile=function getRibbonsFromTheFile(filename,browsingDesktopFilePath){

  var fileLoc=browsingDesktopFilePath+"\\media\\attachments\\browsingDesktop\\"+filename;
 
  var primaryRibbontext='',secRibbontext='';
  var content = require(fileLoc);
  delete require.cache[fileLoc];

  var htmlparser = require("htmlparser2");
  var handler = new htmlparser.DomHandler(function (error, dom) {

        for(var i=0;i<dom.length;i++){

           if(((dom[i].attribs!==undefined)?dom[i].attribs.class==='offer-wrapper':false)  && (dom[i].children[1]!==undefined?dom[i].children[1].children[1]!==undefined:false)){

                    if(dom[i].children[1].children[1]!==undefined?(dom[i].children[1].children[1].name!==undefined?(dom[i].children[1].children[1].name==='p' && dom[i].children[1].children[1].children[0]!==undefined?dom[i].children[1].children[1].children[0].data!==undefined:false):false):false){
                             
                              primaryRibbontext=dom[i].children[1].children[1].children[0].data.trim();
                       } 
               
              }

               if((dom[i].attribs!==undefined?dom[i].attribs.class==='promo-banner':false) && (dom[i].children[1]!==undefined?((dom[i].children[1].name!==undefined && dom[i].children[1].children[0]!==undefined)?(dom[i].children[1].name==='p' && dom[i].children[1].children[0].data!==undefined):false):false)){
                
                secRibbontext=dom[i].children[1].children[0].data.trim();

           }


      }
  });
  var parser = new htmlparser.Parser(handler);
  parser.write(content);
  parser.done();

  var obj={};
  obj.primaryRibbontext=primaryRibbontext.trim();
  obj.secRibbontext=secRibbontext.trim();
  return obj;

}

module.exports = {
	checkRibbonsPresent:checkRibbonsPresent,
  getDatafromDirectoryForRibbon:getDatafromDirectoryForRibbon,
  getRibbonsFromTheFile:getRibbonsFromTheFile

};

function replaceAll(find, replace, str) {

  while( str.indexOf(find) > -1)
  {
    str = str.replace(find, replace);
  }
  return str;

}

