var beautify = require('js-beautify');
var fs = require('graceful-fs');
//var prettyjson = require('prettyjson');


require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');
recursive('C:/vagrant/content/shop/homepage/images/shop15/', function(err, files) {
    var filecount = 0;
    var foundArray = [],
        notFoundArray = [];
    var freddoFile1 = files.filter(function(file) {
        filecount++;
        if (file.substr(-4) === '.jpg')
            return file;
        else if (file.substr(-4) === '.png')
            return file;
    });
    //console.log(freddoFile1)

    var fImgArray = freddoFile1.toString();
    fImgArray = fImgArray.split(",");
    for (var val in fImgArray) {
        fImgArray[val] = fImgArray[val].replace(/\\/g, '/');
        fImgArray[val] = fImgArray[val].substr((fImgArray[val].indexOf("content")) + 7);
        //console.log(fImgArray[val])
    }
    fImgArray = fImgArray.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })
    for (var val in fImgArray) {
        fs.appendFile("ExcelOutput/fAll.txt", fImgArray[val] + "\r\n", function(err) {
            if (err) {
                return console.log(err);
            }
        })
    }
    console.log(fImgArray.length)
    var checkArray = ["D:/kanban_new/productCatalogueData_Master/catalogueData/media/", "D:/kanban_new/productCatalogueData_Master/catalogueData/accessories/", "D:/kanban_new/productCatalogueData_Master/catalogueData/device/", "D:/kanban_new/productCatalogueData_Master/catalogueData/gifts/", "D:/kanban_new/productCatalogueData_Master/catalogueData/merchandisedPromos/"];
    var checkA = checkArray.toString();
    for (var check = 0; check = checkArray.length; check++) {
        recursive(checkA[check], function(err, files) {
            var jsonFilesCount = 0;
            var proCatLogFile1 = files.filter(function(file) {
                jsonFilesCount++;
                // if (file.substr(-5) === '.json')
                // return file;
                // else if (file.substr(-5) === '.html')
                // return file;
                if (file.substr(-4) === '.txt')
                    return file;
            });
            //console.log(proCatLogFile1.length);
            for (var key in fImgArray) {
                flag = false
                for (var key1 in proCatLogFile1) {
                    process(fImgArray[key], proCatLogFile1[key1]);
                }
            }
            // fImgArray = fImgArray.filter(function(x) { return foundArray.indexOf(x) < 0 })
        });
    }
});

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function process(img, file) {
    //console.log(img)
    //console.log(file);
    fs.readFile(file, 'utf8', function(err, data) {
        if (err) {
            return console.log(err);
        }
        if (data.indexOf(img) >= 0) {
            fs.appendFile("ExcelOutput/fFound.txt", img + "\r\n", function(err) {
                if (err) {
                    return console.log(err);
                }
            })
        }
    });
}