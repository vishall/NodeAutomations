var beautify = require('js-beautify');
var fs = require('fs');
var prettyjson = require('prettyjson');
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

recursive('C:/Idea/productCatalogueData_Master/catalogueData/device', function(err, files) {
    var jsonFileCount = 0,
        jsonFilesIndex = 0;
    var json;
    console.log(files.length);
    var jsonFiles = files.filter(function(file) {
        jsonFileCount++;
        return file.substr(-5) === '.json';
    });
    deviceDetailsCol = [];
    jsonFiles.forEach(function(file) {
        var content = require(file);
        //console.log(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if (newSearch != null) {
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            });
            for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
                var newPathValue = '"' + uniqueArray[jCount] + '"';
                var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
                newPathsContainer.push(uniqueArray[jCount]);
                newContent = newContent.replace(regExpCheck, newPathValue);
                var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
            }
            json = JSON.parse(newContent);
        } else {
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        //if(json["id"] == "8281864e-faf7-4d28-86d1-5346b64f1c7cdvsd")
        checkFullfilmentData(json, file, newPathsContainer);

    });
});

function checkFullfilmentData(json, file, newPathsContainer) {
    var guid = json["id"];
    var leadGuid = json["leadModelInFamily"];
    var subtype = json["subType"];
    if (guid == leadGuid) {
        if (json["technicalSpecification"]) {
            // if (json["technicalSpecification"]["featuredSpecifications"])
            // for (var i = 0; i < json["technicalSpecification"]["featuredSpecifications"].length; i++) {
            // if (json["technicalSpecification"]["featuredSpecifications"][i]["name"] == "Camera") {
            // if (!json["cameraResolution"]) {
            // var cameraResolution = json["technicalSpecification"]["featuredSpecifications"][i]["description"];
            // if (cameraResolution != "N/A")
            // if (cameraResolution != "No") {
            // var a1 = cameraResolution.indexOf('M');
            // var a2 = cameraResolution.indexOf('m')
            // if (a1 >= 0)
            // cameraResolution = cameraResolution.substring(0, a1).trim();
            // else
            // cameraResolution = cameraResolution.substring(0, a2).trim();
            // json["cameraResolution"] = {
            // "unit": "Megapixels",
            // "value": cameraResolution,
            // "display": cameraResolution + " megapixel"
            // }
            // }
            // }
            // } else if (json["technicalSpecification"]["featuredSpecifications"][i]["name"] == "Battery life") {
            // if (!json["batteryLife"]) {
            // var batteryLife = json["technicalSpecification"]["featuredSpecifications"][i]["description"].toString();
            // //console.log(batteryLife);
            // if (batteryLife.indexOf('min') >= 0) {
            // batteryLife = batteryLife.match(/\d+/g);
            // json["batteryLife"] = {
            // "unit": "Hours",
            // "value": batteryLife[0],
            // "display": batteryLife[0] + " hours " + batteryLife[1] + " min"
            // }
            // } else if (batteryLife.indexOf('day') >= 0 || batteryLife.indexOf('days') >= 0) {
            // if (batteryLife.indexOf('~') >= 0) {
            // batteryLife = batteryLife.match(/\d+/g);
            // var hour = batteryLife[0] * 24 / batteryLife[1];
            // hour = hour.toString();
            // json["batteryLife"] = {
            // "unit": "Hours",
            // "value": hour,
            // "display": batteryLife[0] + "~" + batteryLife[1] + " day"
            // }
            // } else {
            // var hour = batteryLife[0] * 24;
            // hour = hour.toString();
            // json["batteryLife"] = {
            // "unit": "Hours",
            // "value": hour,
            // "display": batteryLife[0] + " day"
            // }
            // }
            // } else {
            // batteryLife = batteryLife.match(/\d+/g);
            // json["batteryLife"] = {
            // "unit": "Hours",
            // "value": batteryLife[0],
            // "display": batteryLife[0] + " hours"
            // }
            // }
            // }
            // } else if (json["technicalSpecification"]["featuredSpecifications"][i]["name"] == "Weight") {
            // if (!json["weight"]) {
            // var weight = json["technicalSpecification"]["featuredSpecifications"][i]["description"].toString();
            // if (weight.indexOf('g') >= 0)
            // weight = weight.substring(0, weight.length - 1).trim();
            // if (weight.indexOf('k') >= 0) {
            // weight = weight.substring(0, weight.length - 1).trim();
            // weight = weight * 1000;
            // weight = weight.toString();
            // }
            // json["weight"] = {
            // "unit": "Grammes",
            // "value": weight,
            // "display": weight + "g"
            // }
            // }
            // } else if (json["technicalSpecification"]["featuredSpecifications"][i]["name"] == "Screen size") {
            // if (subtype != "FitnessBandNonSim")
            // if (!json["screenSize"]) {
            // //console.log(json["sku"]);
            // var sentence = json["technicalSpecification"]["featuredSpecifications"][i]["description"].toString();
            // if (sentence.indexOf(' ') >= 0)
            // sentence = sentence.substr(0, sentence.indexOf(' '));
            // if (sentence.indexOf('-') >= 0)
            // sentence = sentence.substr(0, sentence.indexOf('-'));
            // if (sentence != "NA") {
            // //console.log(sentence);
            // json["screenSize"] = {
            // "unit": "Inches",
            // "value": sentence,
            // "display": sentence + " inch"
            // }
            // }
            // }
            // }
            // }
        }
        if (subtype != "FitnessBandNonSim")
            if (!json["screenSize"]) {
                if (json["technicalSpecification"])
                    if (json["technicalSpecification"]["techSpec"])
                        for (var i = 0; i < json["technicalSpecification"]["techSpec"].length; i++) {
                            for (var j = 0; j < json["technicalSpecification"]["techSpec"][i]["data"].length; j++) {
                                if (json["technicalSpecification"]["techSpec"][i]["data"][j]["comparisonLabel"] == "Screen Size") {
                                    //console.log(json["sku"]);
                                    var sentence = json["technicalSpecification"]["techSpec"][i]["data"][j]["displayValue"].toString();
                                    if (sentence.indexOf(' ') >= 0)
                                        sentence = sentence.substr(0, sentence.indexOf(' '));
                                    if (sentence.indexOf('-') >= 0)
                                        sentence = sentence.substr(0, sentence.indexOf('-'));
                                    if (sentence != "NA") {
                                        //console.log(sentence);
                                        json["screenSize"] = {
                                            "unit": "Inches",
                                            "value": sentence,
                                            "display": sentence + " inch"
                                        }
                                    }
                                    break;
                                }
                            }
                        }
            }
        if (!json["weight"]) {
            if (json["technicalSpecification"])
                if (json["technicalSpecification"]["techSpec"])
                    for (var i = 0; i < json["technicalSpecification"]["techSpec"].length; i++) {
                        for (var j = 0; j < json["technicalSpecification"]["techSpec"][i]["data"].length; j++) {
                            if (json["technicalSpecification"]["techSpec"][i]["data"][j]["comparisonLabel"] == "Weight") {
                                var weight = json["technicalSpecification"]["techSpec"][i]["data"][j]["displayValue"].toString();
                                if (weight.indexOf('g') >= 0)
                                    weight = weight.substring(0, weight.length - 1).trim();
                                if (weight.indexOf('k') >= 0) {
                                    weight = weight.substring(0, weight.length - 1).trim();
                                    weight = weight * 1000;
                                    weight = weight.toString();
                                }
                                json["weight"] = {
                                        "unit": "Grammes",
                                        "value": weight,
                                        "display": weight + "g"
                                    }
                                    //console.log(weight);
                                break;
                            }

                        }
                    }
        }
        if (!json["batteryLife"]) {
            if (json["technicalSpecification"])
                if (json["technicalSpecification"]["techSpec"])
                    for (var i = 0; i < json["technicalSpecification"]["techSpec"].length; i++) {
                        for (var j = 0; j < json["technicalSpecification"]["techSpec"][i]["data"].length; j++) {
                            if (json["technicalSpecification"]["techSpec"][i]["data"][j]["comparisonLabel"] == "Talk Time") {
                                var batteryLife = json["technicalSpecification"]["techSpec"][i]["data"][j]["displayValue"].toString();
                                //console.log(batteryLife);
                                if (batteryLife.indexOf('min') >= 0) {
                                    batteryLife = batteryLife.match(/\d+/g);
                                    json["batteryLife"] = {
                                        "unit": "Hours",
                                        "value": batteryLife[0],
                                        "display": batteryLife[0] + " hours " + batteryLife[1] + " min"
                                    }
                                } else if (batteryLife.indexOf('day') >= 0) {
                                    if (batteryLife.indexOf('~') >= 0) {
                                        batteryLife = batteryLife.match(/\d+/g);
                                        var hour = batteryLife[0] * 24 / batteryLife[1];
                                        hour = hour.toString();
                                        json["batteryLife"] = {
                                            "unit": "Hours",
                                            "value": hour,
                                            "display": batteryLife[0] + "~" + batteryLife[1] + " day"
                                        }
                                    } else {
                                        var hour = batteryLife[0] * 24;
                                        hour = hour.toString();
                                        json["batteryLife"] = {
                                            "unit": "Hours",
                                            "value": hour,
                                            "display": batteryLife[0] + " day"
                                        }
                                    }
                                } else {
                                    batteryLife = batteryLife.match(/\d+/g);
                                    json["batteryLife"] = {
                                        "unit": "Hours",
                                        "value": batteryLife[0],
                                        "display": batteryLife[0] + " hours"
                                    }
                                }
                                break;
                            }

                        }
                    }
        }
        if (!json["cameraResolution"]) {
            if (json["technicalSpecification"])
                if (json["technicalSpecification"]["techSpec"])
                    for (var i = 0; i < json["technicalSpecification"]["techSpec"].length; i++) {
                        for (var j = 0; j < json["technicalSpecification"]["techSpec"][i]["data"].length; j++) {
                            if (json["technicalSpecification"]["techSpec"][i]["data"][j]["canonicalKey"] == "back-camera") {
                                var cameraResolution = json["technicalSpecification"]["techSpec"][i]["data"][j]["displayValue"].toString();
                                if (cameraResolution != "N/A")
                                    if (cameraResolution != "No") {
                                        var a1 = cameraResolution.indexOf('M');
                                        var a2 = cameraResolution.indexOf('m')
                                        if (a1 >= 0)
                                            cameraResolution = cameraResolution.substring(0, a1).trim();
                                        else
                                            cameraResolution = cameraResolution.substring(0, a2).trim();
                                        json["cameraResolution"] = {
                                            "unit": "Megapixels",
                                            "value": cameraResolution,
                                            "display": cameraResolution + " megapixel"
                                        }
                                    }
                                break;
                            }
                        }
                    }
        }
    }
    //console.log(file);
    var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent, file, newPathsContainer);

}

function convertBacktoOriginalState(newContent, file, newPathsContainer) {
    var originalState;

    newContent = beautify(newContent, {
        indent_size: 2
    });
    for (var jCount = 0; jCount < newPathsContainer.length; jCount++) {
        var oldPathValue = '"' + newPathsContainer[jCount] + '"';
        var regExpCheck = new RegExp(escapeRegExp(oldPathValue), "g");
        newContent = newContent.replace(regExpCheck, newPathsContainer[jCount]);
    }
    fs.writeFile("ExcelOutput/log.txt", "", function(err) {
        if (err) {
            return console.log(err);
        }
    });
    writeToFile(file, newContent);

}

function writeToFile(file, content) {
    fs.writeFile(file, content, function(err) {
        if (err) {
            console.log(err);
        } else {
            //modifiedFileCount++;

            //console.log("Modified Files"+modifiedFileCount);
            fs.appendFile("ExcelOutput/log.txt", file + "\r\n", function(err) {
                if (err) {
                    return console.log(err);
                } else {}
            });
        }
    });

}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}