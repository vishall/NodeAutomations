var fs = require('fs'),
    XLSX = require('xlsx'),
    excelbuilder = require('excel4node'),
	beautify = require('js-beautify'),
    recursive = require('recursive-readdir');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};
var recursive = require('recursive-readdir');

var prodCatURL = 'C:/Kanban/productCatalogueData_Master/catalogueData/device/',
    filePath = 'ExcelOutput/leadSKU.xlsx', // input is in xlsx format
    pathOfFile = 'A',
    leadSKUContainer = [],
    leadSKUContainerLength;

function loadFilePath() {
    try {
        var workbook = XLSX.readFile(filePath);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading path Comp Sheet...");
        sheet_name_list.forEach(function(sheetName) {
            if (sheetName === "Sheet1") {
                var worksheet = workbook.Sheets[sheetName];
                for (currentSheet in worksheet) {
                    if (currentSheet[0] === '!') continue;
                    if (currentSheet[0] === 'A') {
                        var leadSKUMatrix = {
                            "leadSKUCell": worksheet[currentSheet].v
                        }
                        leadSKUContainer.push(leadSKUMatrix);
                    }
                }
            }
        });
    } catch (e) {
        console.log("Oops.......");
        console.log("Something is wrong with merch sheet");
        console.log(e);
    }
}
var refurbJsonList = [];
var newPathsContainer = [],
    temp, json;
var newSlice = {
    "featureType": "video",
    "mediaData": {
        "url": "https://www.youtube.com/embed/lvhPac_Vidg?showinfo=0&modestbranding=1&wmode=transparent",
        "alignment": "right",
        "mediaService": "youtube",
        "text": {
            "heading": "Perfectly Fine",
            "content": "Perfectly Fine phones have been a bit more loved, but are still working well. They might have superficial scratches on the back, sides and screen but there will be no more than five deep scratches or chips up to 2mm in length. And you'll get a 12 month warranty to put your mind at ease."
        }
    }
};

function loadProdCatFiles() {
    try {
        recursive(prodCatURL, function(err, files) {
            var allJsonFiles = files.filter(function(file) {
                return file.substr(-5) === '.json';
            });
            allJsonFiles.forEach(function(file) {
                checkStandard(file);
                addoverviewSliceToDevice(json, file);
            });
        });
    } catch (e) {
        console.log("Oops.......");
        console.log("Something is wrong with ProdCat URL");
    }
}

function addoverviewSliceToDevice(json, file) {
    leadSKUContainerLength = leadSKUContainer.length;
    //console.log(leadSKUContainerLength);
    for (var i = 0; i < leadSKUContainerLength; i++) {
        if (leadSKUContainer[i]["leadSKUCell"] === json["sku"]["code"]) {
            if (json["id"] == json["leadModelInFamily"]) {
                if (json["features"]) {
                    if (json["features"]["overwriteWith"] || json["overwrites"])
                        console.log("Please check for the river page of " + json["model"]);
                    if (json["features"]["featuredItems"]) {
                        var totalSlice = json["features"]["featuredItems"];
                        var slice = totalSlice.length;

                        totalSlice.unshift(newSlice);
                    } else {
                        json["features"]["featuredItems"] = [{
                            "featureType": "video",
                            "mediaData": {
                                "url": "https://www.youtube.com/embed/DcKRr0hFiyA?showinfo=0&modestbranding=1&wmode=transparent",
                                "alignment": "right",
                                "mediaService": "youtube",
                                "text": {
                                    "heading": "<span class='refurb-detail-row'>Like New</sapn>",
                                    "content": "A great range of phones, for less. That’s what you get with Like New. Our second hand phones are checked over and securely wiped, so you get a clean slate. If you change your mind, you’ll get 14 days to return it just like a new phone."
                                }
                            }
                        }]
                    }
                } else {
                    json["features"] = {
					"featuredItems" : [{
         "featureType": "video",
         "mediaData": {
            "url": "https://www.youtube.com/embed/dHK2gvsGkiw?showinfo=0&modestbranding=1&wmode=transparent",
            "alignment": "right",
            "mediaService": "youtube",
            "text": {
               "heading": "Almost perfect",
               "content": "These phones are nearly new.<br>They can have up to five blemishes (small scratches, or chips up to 2mm long) but no scratches on the screen. They’re security wiped and have the latest operating system."
            }
         }
      }]
				}
                    }
                    if (json["features"])
                        if (json["features"]["featuredItems"])
                            var n = json["features"]["featuredItems"].length;
                    if (n != 0)
                        for (var k = 0; k < n; k++) {
                            if (json["features"]["featuredItems"][k]["mediaData"]) {
                                if (k % 2 == 0)
                                    json["features"]["featuredItems"][k]["mediaData"]["alignment"] = "right";
                                else
                                    json["features"]["featuredItems"][k]["mediaData"]["alignment"] = "left";
                            }
                        }
						var fileNewContent = JSON.stringify(json);
                convertBacktoOriginalState(fileNewContent, file, newPathsContainer);
                } else
                    console.log("Please check" + json["model"] + "SKU" + json["sku"]["code"] + "in given excel. It ie not a lead model");
            }
        }
    }

    function checkStandard(file) {
        var content = require(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        if (newSearch != null) {
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            });
            for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
                var planPathValue = '"' + uniqueArray[jCount] + '"';
                var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
                newPathsContainer.push(uniqueArray[jCount]);
                newContent = newContent.replace(regExpCheck, planPathValue);
                var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
            }
            json = JSON.parse(newContent);
        } else {
            json = JSON.parse(newContent);
        }
        return json;
    }

    function writeToFile(file, content) {
        fs.writeFile(file, content, function(err) {
            if (err) {
                console.log(err);
            }
        });
    }

    function convertBacktoOriginalState(newContent, file, newPathsContainer) {
        var originalState;
        newContent = beautify(newContent, {
            indent_size: 3,
            "preserve_newlines": false,
            "keep_array_indentation": true
        });
        for (var jCount = 0; jCount < newPathsContainer.length; jCount++) {
            var oldPathValue = '"' + newPathsContainer[jCount] + '"';
            var regExpCheck = new RegExp(escapeRegExp(oldPathValue), "g");
            newContent = newContent.replace(regExpCheck, newPathsContainer[jCount]);
        }
        writeToFile(file, newContent);
    }

    function escapeRegExp(str) {
        return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
    }

    (function() {
        console.log("Application has started");
        loadFilePath();
        loadProdCatFiles();
    })();