/* This Script will set sash and ribbon fields for prepay and postpay devices */
/* Please fill the below information before running the script */

var prodCatURL = '/home/user/IdeaProjects/productCatalogueData_Master/catalogueData/',
    inputSheetUrl = '/home/user/IdeaProjects/NodeAutomations/ExcelOutput/Sash_Ribbon_Input.xlsx';

/* Do not modify the below script if you are not sure about the changes*/


var XLSX = require('xlsx'),excelbuilder = require('excel4node'),
         recursive = require('recursive-readdir');

var beautify = require('js-beautify');
var fs = require('fs');
var prettyjson = require('prettyjson');
var options = {
  noColor: true
};
var modifiedFileCount =0;
var deviceSashRibbons = {};


require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

function loadSashRibbons(){
    var deviceSashRibbon;
    try{
        var workbook = XLSX.readFile(inputSheetUrl);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading Sash Ribbon Sheet...");
        sheet_name_list.forEach(function(sheetName) {
          if( sheetName === "Sheet1"){
              var worksheet = workbook.Sheets[sheetName];
              for (currentCell in worksheet) {
                  if(currentCell[0] === '!') continue;
                  var field;
                 // console.log(currentCell);
                  switch(currentCell[0]){
                        case "A" :
                            field = "sku";
                            deviceSashRibbon = {};
                            break;
                        case "B" :
                            field = "sashPrepay";
                            break;
                        case "C" :
                            field = "sashPostpay";
                            break;
                        case "D" :
                            field = "ribbonPrepay";
                            break;
                        case "E" :
                            field = "ribbonPostpay";
                            break;
                  }
                  deviceSashRibbon[field] = worksheet[currentCell].v
                  if(currentCell[0] == 'E'){
                    deviceSashRibbons[deviceSashRibbon.sku] = deviceSashRibbon;
                  }
              }
          }
       });
  }
  catch(e){
        console.log("Oops.......");
        console.log("Something is wrong with Sash Ribbon sheet");
        console.log(e);
  }
}

function writeJson(deviceSashRibbons){
    var pathRegExp = /\$\{(.*?)\}/g;
    var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

    var deviceDetailsCol = [], modifiedFileCount =0;

    recursive('/home/user/IdeaProjects/productCatalogueData_Master/catalogueData/device', function (err, files) {

        var jsonFileCount = 0, jsonFilesIndex = 0;
        var json;
        var jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
        deviceDetailsCol =[];
        jsonFiles.forEach(function(file) {
            var content =  require(file);
            var newContent = content;
            var newSearch = newContent.match(pathRegExp);
            var newPathsContainer = [];
            if(newSearch != null){
                var uniqueArray = newSearch.filter(function(elem, pos) {
                    return newSearch.indexOf(elem) == pos;
                });
                for(var jCount =0;jCount<uniqueArray.length;jCount++){
                   var newPathValue = '"'+uniqueArray[jCount]+'"';
                   var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
                   newPathsContainer.push(uniqueArray[jCount]);
                   newContent = newContent.replace(regExpCheck,newPathValue);
                   var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
                }
                json = JSON.parse(newContent);
            }
            else{
                json = JSON.parse(newContent);
            }
            jsonFilesIndex++;
            addSashRibbon(json,file,newPathsContainer, deviceSashRibbons[json.sku.code]);

        });
    });
}

function addSashRibbon(json,file,newPathsContainer, deviceSashRibbon){
    if(!deviceSashRibbon) {
        return;
    }
   // if(deviceSashRibbon) console.log(deviceSashRibbon);
    if(!json["promotion"]){
        json["promotion"] = {};
    }

    var noPrepay = (deviceSashRibbon.sashPrepay.toLowerCase() == 'remove' && deviceSashRibbon.ribbonPrepay.toLowerCase() == 'remove');
    if(noPrepay){
        delete json["promotion"]["prepay"];
    }else{
        var sashPrepaySame = (deviceSashRibbon.sashPrepay.toLowerCase() == 'same');
        var ribbonPrepaySame = (deviceSashRibbon.ribbonPrepay.toLowerCase() == 'same');

        if(!json["promotion"]["prepay"] && (!sashPrepaySame || !ribbonPrepaySame)){
            json["promotion"]["prepay"] = {};
        }
        if(deviceSashRibbon.sashPrepay.toLowerCase() == 'remove'){
            delete json.promotion.prepay.sash;

        }else if(!sashPrepaySame){
            json.promotion.prepay.sash = deviceSashRibbon.sashPrepay;
        }

        if(deviceSashRibbon.ribbonPrepay.toLowerCase() == 'remove'){
            delete json.promotion.prepay.ribbon;

        }else if(!ribbonPrepaySame){
            json.promotion.prepay.ribbon = deviceSashRibbon.ribbonPrepay;
        }
    }


    var noPostpay = (deviceSashRibbon.sashPostpay.toLowerCase() == 'remove' && deviceSashRibbon.ribbonPostpay.toLowerCase() == 'remove');
    if(noPostpay){
        delete json["promotion"]["postpay"];
    }else{
        var sashPostpaySame = (deviceSashRibbon.sashPostpay.toLowerCase() == 'same');
        var ribbonPostpaySame = (deviceSashRibbon.ribbonPostpay.toLowerCase() == 'same');

        if(!json["promotion"]["postpay"] && (!sashPostpaySame || !ribbonPostpaySame)){
            json["promotion"]["postpay"] = {};
        }
        if(deviceSashRibbon.sashPostpay.toLowerCase() == 'remove'){
            delete json.promotion.postpay.sash;

        }else if(!sashPostpaySame){
            json.promotion.postpay.sash = deviceSashRibbon.sashPostpay;
        }

        if(deviceSashRibbon.ribbonPostpay.toLowerCase() == 'remove'){
            delete json.promotion.postpay.ribbon;

        }else if(!ribbonPostpaySame){
            json.promotion.postpay.ribbon = deviceSashRibbon.ribbonPostpay;
        }
    }
    if(noPrepay && noPostpay){
        delete json["promotion"];
    }

    var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent,file,newPathsContainer);
}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
        modifiedFileCount++;
       // console.log("Modified Files"+modifiedFileCount);

    }
  });
}

function convertBacktoOriginalState(newContent,file,newPathsContainer){
    var originalState;

    newContent = beautify(newContent, { indent_size: 2 });
    for(var jCount =0;jCount<newPathsContainer.length;jCount++){
               var oldPathValue = '"'+newPathsContainer[jCount]+'"';
               var regExpCheck = new RegExp(escapeRegExp(oldPathValue),"g");
               newContent = newContent.replace(regExpCheck,newPathsContainer[jCount]);
    }
  //  fs.writeFile("ExcelOutput/log.txt","",function(err) {
    //    if(err) {return console.log(err);}
  //  });
    writeToFile(file,newContent);

}

// Main Function for the Application
(function(){
    console.log("Application has started");
    loadSashRibbons();
    //console.log(deviceSashRibbons, "\n..................................\n");
    writeJson(deviceSashRibbons);
    console.log("Done");
})();

