// To delete the file
var prodCatURL = 'D:/kanban_new/productCatalogueData_Master/catalogueData',
    filePath = 'ExcelOutput/deleteFile.xlsx', // input is in xlsx format
    pathOfFile = 'A',
    filePathContainer = [],
    filePathContainerLength;

/* Do not modify the below script if you are not sure about the changes*/

var fs = require('fs'),
    XLSX = require('xlsx'),
    excelbuilder = require('excel4node'),
    recursive = require('recursive-readdir');

//To read input 
function loadFilePath() {
    try {
        var workbook = XLSX.readFile(filePath);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading path Comp Sheet...");
        sheet_name_list.forEach(function(sheetName) {
            if (sheetName === "Sheet1") {
                var worksheet = workbook.Sheets[sheetName];
                for (currentSheet in worksheet) {
                    if (currentSheet[0] === '!') continue;
                    if (currentSheet[0] === 'A') {
                        var filePathMatrix = {
                            "filePathCell": worksheet[currentSheet].v
                        }
                        filePathContainer.push(filePathMatrix);
                    }
                }
            }
        });
    } catch (e) {
        console.log("Oops.......");
        console.log("Something is wrong with path sheet");
        console.log(e);
    }
}

function loadProdCatFiles() {
    try {
        //Remove duplicate if any
        filePathContainer = filePathContainer.filter(function(elem, index, self) {
            return index == self.indexOf(elem);
        })
        filePathContainerLength = filePathContainer.length;
        recursive(prodCatURL, function(err, files) {
            for (z = 0; z < filePathContainerLength; z++) {
                var prodCatDeviceURL = prodCatURL + filePathContainer[z]["filePathCell"]
                    // Logic to delete file
                fs.unlink(prodCatDeviceURL, function(err) {
                    if (err) {
                        return console.error(err);
                    }
                    //console.log(z + " file deleted");
                });

            }
        });
    } catch (e) {
        console.log("Oops.......");
        console.log("Something is wrong with ProdCat URL");
    }
}

// Main Function for the Application
(function() {
    console.log("Application has started");
    loadFilePath();
    loadProdCatFiles();
})();