var beautify = require('js-beautify');
var fs = require('fs');
var prettyjson = require('prettyjson');
var options = {
  noColor: true
};
//recommendedSheetURL = 'C:/NodeAutomations/ExcelOutput/recommendedDevices.xlsx',
//deviceSkuCell=A;
var devices=[];

require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

var deviceDetailsCol = [], modifiedFileCount =0,i=0;
var deviceDetailsCol = [],leadModelGUIDCol= [], deviceJSONCol = [],jsonFiles;

recursive('C:/Idea/productCatalogueData_Master/catalogueData/device', function (err, files) {
    var jsonFileCount = 0,jsonFilesIndex = 0;
    var json;
    console.log("Reading JSON files.....");
    jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
    jsonFiles.forEach(function(file) {
        var content =  require(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        deviceJSONCol.push(json);
        readLeadModels(json);
        if(jsonFiles.length === jsonFilesIndex){
            //console.log(jsonFiles.length);
            //console.log(leadModelGUIDCol.length);
            loadDevicesAgain();
        }
    });
    
    function loadDevicesAgain(){
        //console.log(deviceJSONCol.length);
        var devicesLength = deviceJSONCol.length;
        for(var leadModelJSONCount =0;leadModelJSONCount<leadModelGUIDCol.length;leadModelJSONCount++){
            for(var jsonDCount=0;jsonDCount<devicesLength; jsonDCount++ ){
                  if(deviceJSONCol[jsonDCount]["id"] == leadModelGUIDCol[leadModelJSONCount]["guid"]){
                      readdeviceDetails(deviceJSONCol[jsonDCount]);
                      break;
                  }
            }
        }
    }
	    jsonFiles.forEach(function(file) {
			generateLeadModelpath(file,json);
		});
});
function readLeadModels(deviceJSON){
    
    var leadModelObj = {
                   "guid":deviceJSON["leadModelInFamily"]
    };
    if(deviceJSON["leadModelInFamily"]){
        if(! leadModelGUIDCol.length) leadModelGUIDCol.push(leadModelObj);
        for(var leadDataCount = 0; leadDataCount < leadModelGUIDCol.length;leadDataCount++){
              if(leadModelGUIDCol[leadDataCount]["guid"] == deviceJSON["leadModelInFamily"]) break;
              else if(leadDataCount == (leadModelGUIDCol.length-1) ) leadModelGUIDCol.push(leadModelObj);
			  //console.log(leadModelGUIDCol);
        }
    }
    
}

// Find lead model SKU
function readdeviceDetails(deviceJSON){
    if((deviceJSON["lifecycle"]["status"]=="Active" || deviceJSON["lifecycle"]["status"]=="ComingSoon")&&(deviceJSON["subType"]=="SmartPhone" || deviceJSON["subType"]=="iPhone" ||  deviceJSON["subType"]=="SimTablet")){
    var deviceObj = {
                   "sku": deviceJSON["sku"]["code"],
				   "brand":deviceJSON["brand"]
    };
    deviceDetailsCol.push(deviceObj);
	//console.log(deviceDetailsCol.length);
	}
}
// Genarate lead model path
function generateLeadModelpath(fileName,json){
	//console.log(json["sku"]["code"]);
	                            // fs.appendFile("ExcelOutput/ProSKU.txt",json["sku"]["code"]+ "\r\n", function(err) {
                            // if(err) {
                                // return console.log(err);
                            // }});
	//console.log("hi");
	         for(var leadCount = 0; leadCount<deviceDetailsCol.length;leadCount++){
				 //console.log("bye");
                        // var deviceSKUObject = deviceDetailsCol[leadCount]["sku"],deviceSKUObjectLength = deviceDetailsCol[leadCount]["sku"].length;
														  //console.log(deviceDetailsCol[leadCount]["sku"]);
														  console.log(json["sku"]["code"]);
	                      if(deviceDetailsCol[leadCount]["sku"] == json["sku"]["code"]){
                                 console.log(json["sku"]["code"]);
                               var deviceFileName = fileName.substr((fileName.indexOf("catalogueData"))+13); 
                               deviceFileName = deviceFileName.replace(/\\/g,'/','g');
                               deviceSKUObject[deviceSKUObjectCount]["url"] = deviceFileName;
							   console.log("\\"+deviceFileName);
                             } 
						 						 
         }
	
}

recursive('C:/Idea/productCatalogueData_Master/catalogueData/recommendedDevices', function (err, files) {
    
    var jsonFileCount = 0, jsonFilesIndex = 0;
    var json;
    console.log("No of files change: "+files.length);
    var jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
    deviceDetailsCol =[];
    jsonFiles.forEach(function(file) {
        var content =  require(file);
        //console.log(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        //if(json["id"] == "8281864e-faf7-4d28-86d1-5346b64f1c7cdvsd")
        addCnCFlag(json,file,newPathsContainer);
        
    });
});

function addCnCFlag(json,file,newPathsContainer){
    var phones = json["byFamily"];
	console.log("Total lines change: "+phones.length)

			
			var jsonArray= [
			{"path":"${idOf('device/apple/iphone6_plus_16gb_space_grey/iphone6_plus_16gb_space_grey1.json')}"},
			{"path":"${idOf('device/apple/iphone6_plus_16gb_space_grey/iphone6_plus_16gb_space_grey2.json')}"},
			{"path":"${idOf('device/apple/iphone6_plus_16gb_space_grey/iphone6_plus_16gb_space_grey3.json')}"},
			{"path":"${idOf('device/apple/iphone6_plus_16gb_space_grey/iphone6_plus_16gb_space_grey4.json')}"},
			{"path":"${idOf('device/apple/iphone6_plus_16gb_space_grey/iphone6_plus_16gb_space_grey5.json')}"}
			];
            for(count=0;count<phones.length;count++){
				jsonArray1=json["byFamily"][count]["phones"]=[];
				for(count1=0;count1<5;count1++){
					jsonArray1.push(jsonArray[count1].path);
				}
				;
				json["byFamily"][count]["phones"]=jsonArray1;
			}
            var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent,file,newPathsContainer);  
 

}


function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
        modifiedFileCount++;
        
        //console.log("Modified Files"+modifiedFileCount);
        fs.appendFile("ExcelOutput/log.txt",file+ "\r\n", function(err) {
                if(err) {
                    return console.log(err);
                }
				else{
					
				}
            }); 
    }
	
});
     
}


function convertBacktoOriginalState(newContent,file,newPathsContainer){
    var originalState;
    
    newContent = beautify(newContent, { indent_size: 2 });
    for(var jCount =0;jCount<newPathsContainer.length;jCount++){
               var oldPathValue = '"'+newPathsContainer[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(oldPathValue),"g");
               newContent = newContent.replace(regExpCheck,newPathsContainer[jCount]);
    }
	fs.writeFile("ExcelOutput/log.txt","",function(err) {
		if(err) {return console.log(err);}
	});
    writeToFile(file,newContent);  
    
}