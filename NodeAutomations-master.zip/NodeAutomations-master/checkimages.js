//To check unused images in prodcatlog
var fs = require('graceful-fs');

var recursive = require('recursive-readdir');
// get all json files path into array
recursive('D:/kanban_new/productCatalogueData_Master/catalogueData/', function(err, files) {
    var jsonFiles1 = files.filter(function(file) {
        return file.substr(-5) === '.json';
    });
    var jsonArray = jsonFiles1.toString();
    jsonArray = jsonArray.split(",");
    for (var val in jsonArray) {
        jsonArray[val] = jsonArray[val].substr(0, jsonArray[val].lastIndexOf("\\"));
        jsonArray[val] = jsonArray[val].replace(/\\/g, '/');
    }
    // remove duplicate value in array if any
    jsonArray = jsonArray.filter(function(elem, index, self) {
        return index == self.indexOf(elem);
    })

    for (var z = 0; z < jsonArray.length; z++) {
        recursive(jsonArray[z], function(err, files) {
            var jsonFiles = files.filter(function(file) {
                return file.substr(-5) === '.json';
            });
            var imgFiles = files.filter(function(file) {
                if (file.substr(-4) === '.png'|| file.substr(-4) === '.jpg') return file;
            });

            var imgArray = imgFiles
                .toString();
            var imgArray = imgArray.split(",");
            // remove duplicate value in array if any
            imgArray = imgArray.filter(function(elem, index, self) {
                return index == self.indexOf(elem);
            });
            jsonFiles.forEach(function(file) {
                fs.readFile(file, 'utf8', function(err, data) {
                    if (err) {
                        return console.log(err);
                    }
                    for (var key in imgArray) {
                        var deviceFilePath = file.substr((file.indexOf("catalogueData")) + 13);
                        deviceFilePath = deviceFilePath.substr(0, deviceFilePath.lastIndexOf("\\"));

                        var imgFilepath = imgArray[key].substr((imgArray[key].indexOf("catalogueData")) + 13);
                        imgFilepath = imgFilepath.substr(0, imgFilepath.lastIndexOf("\\"));
                        imgArray[key] = imgArray[key].substring(imgArray[key].lastIndexOf("\\")).replace("\\", "");
                        // if image & json is in same folder
                        if (imgFilepath === deviceFilePath) {
                            // if image not found in respective json file
                            if (data.indexOf(imgArray[key]) < 0) {
                                fs.appendFile("ExcelOutput/imgNotFound.txt", deviceFilePath + "\\" + imgArray[key] + "\r\n", function(err) {
                                    if (err) {
                                        return console.log(err);
                                    }
                                })
                            } else {
                                fs.appendFile("ExcelOutput/imgFound.txt", deviceFilePath + "\\" + imgArray[key] + "\r\n", function(err) {
                                    if (err) {
                                        return console.log(err);
                                    }
                                })
                            }
                        }
                    }
                });
            });
        });
    }
});