//THis Script builds tariff JOSN files based on the TRS Provided
//*for generating guid use this dependency*/ npm install --save-dev guid 

//Global Modules declaration
var beautify = require('js-beautify'), XLSX = require('xlsx'), Guid = require('guid'),
    excelbuilder = require('excel4node'),fs = require('fs'),
    prettyjson = require('prettyjson'),recursive = require('recursive-readdir'),
    mkdirp = require('mkdirp'),filePath = "D:/IdeaProjects/productCatalogueData_Master2/catalogueData/device",
    excelPath = "D:/NodeAutomations-master/NodeAutomations-master/ExcelInput/deviceBuild.xlsx";


//JSON Parsing Parser functions
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

if (!String.prototype.format) {
  String.prototype.format = function() {
    var args = arguments;
    return this.replace(/{(\d+)}/g, function(match, number) {
      return typeof args[number] != 'undefined'
        ? args[number]
        : match
      ;
    });
  };
}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

//Writing JSON Data to File
var modifiedFileCount = 0;
function writeToFile(file,content){
  try{
      fs.writeFile(file, content, function(err) {
        if(err) {
            console.log(err);
        } else {
            
            modifiedFileCount++;
        }
      });
  }
  catch(e){
      console.log(".......Error in writeToFile block......");
      console.log(".......Error is....");
      console.log(e);
    }
}

// Reading JSON files from ProdCat
require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

// Read the TRS Information
var deviceDetails = [],deviceModelData=[],accModelData=[];
function readDeviceInformation(){
    try{

        var workbook = XLSX.readFile(excelPath);
        var tariffRows_Min_Count = 2,tariffRows_Max_Count = 4,tariffRows_Min_A_Count = 2,tariffRows_Max_A_Count = 4;
        var sheet_name_list = workbook.SheetNames;
        sheet_name_list.forEach(function(y) {
            //console.log(y);
          if( y === "Sheet1"){
              
              var worksheet = workbook.Sheets[y];
              for (z in worksheet) {
                  
                  if(tariffRows_Min_Count <= tariffRows_Max_Count){
					  
                        if(z[0] === '!') continue;
                         var altPID = null;
						 var guid = Guid.create();
                           deviceModelData.push( {
                             
                              "status" : worksheet['A'+tariffRows_Min_Count].v,
                               "brand" : worksheet['B'+tariffRows_Min_Count].v,
                               "name" : worksheet['C'+tariffRows_Min_Count].v,
                              "SKU" : worksheet['D'+tariffRows_Min_Count].v,
                              "sizes" : worksheet['E'+tariffRows_Min_Count].v,
                              "colors" : worksheet['F'+tariffRows_Min_Count].v,
                              "bluetooth" : worksheet['G'+tariffRows_Min_Count].v,
                              "removablebattery" : worksheet['H'+tariffRows_Min_Count].v,
                              "hdcamera" : worksheet['I'+tariffRows_Min_Count].v,
                              "splashproof" : worksheet['J'+tariffRows_Min_Count].v,
                              "nfc" : worksheet['K'+tariffRows_Min_Count].v,
                              "camera" : worksheet['L'+tariffRows_Min_Count].v,
                              "screen" : worksheet['M'+tariffRows_Min_Count].v,
                              "batterylife" : worksheet['N'+tariffRows_Min_Count].v,
                              "weight" : worksheet['O'+tariffRows_Min_Count].v,
                              "standbytime" : worksheet['P'+tariffRows_Min_Count].v,
                              "dimensions" : worksheet['Q'+tariffRows_Min_Count].v,
                              "frontcamera" : worksheet['R'+tariffRows_Min_Count].v,
                               "guid" : guid.value,
                               "featuretype" : worksheet['T'+tariffRows_Min_Count].v,
                               "hex" : worksheet['U'+tariffRows_Min_Count].v,
                               "snippet" : worksheet['V'+tariffRows_Min_Count].v,
                               "colorgroup" : worksheet['W'+tariffRows_Min_Count].v,
                               "wifi" : worksheet['X'+tariffRows_Min_Count].v,
                               "bandtype" : worksheet['Y'+tariffRows_Min_Count].v,
                               "dataconnection" : worksheet['Z'+tariffRows_Min_Count].v
                          });
                          tariffRows_Min_Count++;
                      // console.log(tariffRows_Min_Count);
                      }
              }
          }
		if( y === "Sheet2"){
              
              var worksheet = workbook.Sheets[y];
              for (z in worksheet) {
                  
                  if(tariffRows_Min_A_Count <= tariffRows_Max_A_Count){
					  
                        if(z[0] === '!') continue;
                         var altPID = null;
						 var guid = Guid.create();
                           accModelData.push( {
                             
                              "status" : worksheet['A'+tariffRows_Min_A_Count].v,
                               "brand" : worksheet['B'+tariffRows_Min_A_Count].v,
                               "name" : worksheet['C'+tariffRows_Min_A_Count].v,
                              "SKU" : worksheet['D'+tariffRows_Min_A_Count].v,
                              "price" : worksheet['E'+tariffRows_Min_A_Count].v,
                              "type" : worksheet['F'+tariffRows_Min_A_Count].v,
                              "sizes" : worksheet['G'+tariffRows_Min_A_Count].v,
                              "colors" : worksheet['H'+tariffRows_Min_A_Count].v,
							  "colorgroup" : worksheet['I'+tariffRows_Min_A_Count].v,
							   "snippet" : worksheet['J'+tariffRows_Min_A_Count].v,
							   "sellpoint" : (worksheet['K'+tariffRows_Min_A_Count].v).split('||'),
							   "compatible" : (worksheet['L'+tariffRows_Min_A_Count].v).split('||'),
							   "hex" : worksheet['M'+tariffRows_Min_A_Count].v,
                              "guid" : guid.value                    
                          });
                          tariffRows_Min_A_Count++;
                      //console.log(tariffRows_Min_Count);
                      }
              }
          }
        });
        console.log("device information has been loaded");
        console.log(accModelData);
            
    }
    catch(e){
       console.log(".......Error in readDeviceInformation block......"+tariffRows_Min_Count);
       console.log(".......Error is....");
       console.log(e);
    }
}

function getObjectKeyIndex(obj, keyToFind) {
    var i = 0, key;

    for (key in obj) {
        if (key == keyToFind) {
            return i;
        }

        i++;
    }

    return null;
}

function merge_options(obj1,obj2){
    var obj3 = {};
    for (var attrname in obj1) { obj3[attrname] = obj1[attrname]; }
    for (var attrname in obj2) { obj3[attrname] = obj2[attrname]; }
    return obj3;
}

String.prototype.replaceAll = function(search, replacement) {
    var target = this;
    return target.split(search).join(replacement);
};

var accessoryJsonStructure = 
{
  "id" : "",
  "brand" : "",
  "model" : "",
  "sortOrdinal" : Math.floor((Math.random() * 99) + 1),
  "recommended" : false,
  "price" : "",
  "type" : "",
  "sku" : {
    "code" : ""
  },
  "recommendedForPhones" : [ ],
  "images" : {
    "orientation" : "Portrait",
    "standard" : {
      "listSingle" : "",
      "details" : "",
      "basket" : "",
      "listDouble" : "",
      "listHalf" : ""
    }
  },
  "snippet" : "",
  "sellingPoints" : [],
  "fulfillmentData" : {
    "productType" : "ACC",
    "productName" : "",
    "risk" : "1"
  },
  "channelPermissions" : {
    "ConsumerNew" : "Buyable",
    "ConsumerUpgrade" : "Buyable",
    "VoiceNew" : "Buyable",
    "VoiceUpgrade" : "Buyable"
  },
  "disableClickAndCollectNow" : false,
  "modelFamily" : "",
  "leadModelInFamily" : "",
  "condition" : "New",
  "lifecycle" : {
    "status" : "Active"
  },
  "features" : {
    "banner" : [
      {
        "heading" : ""
      },
      {
        "heading" : ""
      },
      {
        "heading" : ""
      },
      {
        "heading" : ""
      }
    ]
  },
  "classification" : {
    "colour" : {
      "display" : "",
      "primary" : ""
    }
  },
  "colourGroup" : "",
  "compatibilityList" : [],
  "costToO2" : "",
  "stockInfo" : {
    "stock" : "InStock"
  }
};


var deviceJSONStructure =
{
  "id": "",
  "subType": "iPhone",
  "brand": "",
  "operatingSystem": "Apple iOS",
  "model": "",
  "sortOrdinal": Math.floor((Math.random() * 99) + 1),
  "sku": {
    "code": ""
  },
  "stockLimited": false,
  "includeSimInUpgradeOrder": true,
  "channelPermissions": {
    "ConsumerNew": "Buyable",
    "ConsumerUpgrade": "Buyable",
    "VoiceNew": "Buyable",
    "VoiceUpgrade": "Buyable"
  },
  "leadModelInFamily": "",
  "modelFamily": "",
  "stockInfo": {
    "stock": "InStock"
  },
  "disableClickAndCollect": true,
  "4gSupportedOnLaunch": true,
  "4gCapable": true,
  "4gEnabledBuildVersions": [],
  "tac": [],
  "sellingPoints": [],
  "longDescription": "",
  "images": {
    "orientation": "Portrait",
    "standard": {
      "listSingle": "",
      "details": "",
      "basket": "",
      "tariff": ""
    }
  },
  "keyFeatures": [],
  "techSpec": [],
  "replacementCost": "999.00",
  "costToO2": "999.99",
  "cashPrice": "999.99",
  "rrp": "999.00",
  "ccaDefaultDataAllowanceId": "",
  "relationships": [{
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_cca_refresh/primary/set_1/unltd-24m-1gb-cca-18gbp.json')}",
    "prices": [{
      "oneOff": "79.99",
      "monthly": "23.00"
    }, {
      "oneOff": "9.99",
      "monthly": "28.00",
      "isDefault": true
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/may/24_refresh_voice/primary/set4/unltd-24m-2gb-refresh-18-00gbp.json')}",
    "prices": [{
      "oneOff": "79.99",
      "monthly": "23.00"
    }, {
      "oneOff": "9.99",
      "monthly": "28.00"
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_cca_refresh/primary/set_1/unltd-24m-3gb-cca-21-5gbp.json')}",
    "prices": [{
      "oneOff": "69.99",
      "monthly": "23.00"
    }, {
      "oneOff": "0.00",
      "monthly": "28.00"
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_cca_refresh/primary/set_1/unltd-24m-5gb-cca-25gbp.json')}",
    "prices": [{
      "oneOff": "39.99",
      "monthly": "23.00"
    }, {
      "oneOff": "0.00",
      "monthly": "28.00"
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/may/24_refresh_voice/primary/set4/unltd-24m-6gb-refresh-21-50gbp.json')}",
    "prices": [{
      "oneOff": "69.99",
      "monthly": "23.00"
    }, {
      "oneOff": "0.00",
      "monthly": "28.00"
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/may/24_refresh_voice/primary/set4/unltd-24m-10gb-refresh-25-00gbp.json')}",
    "prices": [{
      "oneOff": "39.99",
      "monthly": "23.00"
    }, {
      "oneOff": "0.00",
      "monthly": "28.00"
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/may/24_refresh_voice/primary/set1/unltd-24m-20gb-refresh-30-00gbp.json')}",
    "prices": [{
      "oneOff": "19.99",
      "monthly": "23.00"
    }, {
      "oneOff": "0.00",
      "monthly": "28.00"
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_cca_refresh/primary/set_5_contingency/unltd-24m-30gb-cca-35gbp.json')}",
    "prices": [{
      "oneOff": "19.99",
      "monthly": "23.00"
    }, {
      "oneOff": "0.00",
      "monthly": "28.00"
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_cca_refresh/secondary/set_1/unltd-24m-shared-cca-16-5gbp.json')}",
    "prices": [{
      "oneOff": "79.99",
      "monthly": "23.00"
    }, {
      "oneOff": "9.99",
      "monthly": "28.00"
    }, {
      "oneOff": "681.99",
      "monthly": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_11/unltd-24m-1gb-paym-43gbp.json')}",
    "prices": [{
      "oneOff": "79.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_13/unltd-24m-1gb-paym-48gbp.json')}",
    "prices": [{
      "oneOff": "9.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_11/unltd-24m-3gb-paym-46-5gbp.json')}",
    "prices": [{
      "oneOff": "69.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_13/unltd-24m-3gb-paym-51-5gbp.json')}",
    "prices": [{
      "oneOff": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_11/unltd-24m-5gb-paym-50gbp.json')}",
    "prices": [{
      "oneOff": "39.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_13/unltd-24m-5gb-paym-55gbp.json')}",
    "prices": [{
      "oneOff": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_8/unltd-24m-20gb-paym-55gbp.json')}",
    "prices": [{
      "oneOff": "19.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_11/unltd-24m-20gb-paym-60gbp.json')}",
    "prices": [{
      "oneOff": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_8/unltd-24m-30gb-paym-60gbp.json')}",
    "prices": [{
      "oneOff": "19.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/q116/24m_paym/non_sharing/set_11/unltd-24m-30gb-paym-65gbp.json')}",
    "prices": [{
      "oneOff": "0.00"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/big_talker_and_international_tariffs/big_talker_triple_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/big_talker_and_international_tariffs/international_sim_triple_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/q114/big_bundle_10_triple_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/q114/big_bundle_15_triple_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/q114/big_bundle_25_triple_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/q114/big_bundle_20_triple_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/big_talker_and_international_tariffs/international_sim_triple_new_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/big_talker_and_international_tariffs/big_talker_triple_new_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "insurance",
    "id": "${idOf('/insurances/o2-insure-monthly-premier-plus.json')}"
  }, {
    "type": "insurance",
    "id": "${idOf('/insurances/o2-accidental-dam-6gbp.json')}"
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/q114/big_bundle_30_triple_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "plan",
    "id": "${idOf('/plan/prepaySims/q114/big_bundle_1gb_10_triple_sim.json')}",
    "prices": [{
      "oneOff": "629.99"
    }]
  }, {
    "type": "dataallowance",
    "id": "iphone"
  }],
  "simType": "Micro",
  "fulfillmentData": {
    "productType": "HAN",
    "productName": "",
    "risk": "2",
    "otherProducts": [{
      "productType": "POS",
      "productId": "24GTRIVN",
      "productName": "Pay Monthly Triple SIM 24GTRIVN SKU"
    }, {
      "productType": "LIT",
      "productId": "O2CN1252N",
      "productName": "LIT O2 Recycle Leaflet O2CN1252N"
    }]
  },
  "attachments": [],
  "classification": {
    "colour": {
      "display": "",
      "primary": ""
    },
    "memory": {
      "unit": "GB",
      "value": "",
      "display": ""
    }
  },
  "snippet": "",
  "colourGroup": "",
  "condition": "New",
  "lifecycle": {
    "status": "ComingSoon"
  },
  "alternativeDevices" : [],
  "disableClickAndCollectNow": true,
  "ccaProductInformation": ""
}


var leadModelInformation = {
  "bluetooth": true,
  "removableBattery": false,
  "hdCamera": true,
  "splashProof": false,
  "nfc": true,
  "cameraResolution": {
    "unit": "Megapixels",
    "value": "",
    "display": ""
  },
  "screenSize": {
    "unit": "Inches",
    "value": "",
    "display": ""
  },
  "batteryLife": {
    "unit": "Hours",
    "value": "",
    "display": ""
  },
  "weight": {
    "unit": "Grammes",
    "value": "",
    "display": ""
  }
  };

  var features = {
      "features": { 
        "banner": [{
                     "heading": "",
                     "imageUrl": ""
                    }, {
                     "heading": "",
                     "imageUrl": ""
                    }, {
                     "heading": "",
                     "imageUrl": ""
                    }, {
                     "heading": "",
                     "imageUrl": ""
                    }],
      "featuredItems": []
  }
  }

  var imageFeatures =
  [{
      "featureType": "image",
      "mediaData": {
        "url": "",
        "alignment": "left",
        "text": {
          "heading": "",
          "content": ""
        }
      }
  }];

  var textFeatures = [{
      "featureType": "text",
      "textData": [{
        "heading": "",
        "content": ""
      }, {
        "heading": "",
        "content": ""
      }]
    }]
  


var technicalSpecification = {
    "technicalSpecification" : {
        "featuredSpecifications": [{
      "name": "Camera",
      "imageUrl": "https://www.o2.co.uk/shop/homepage/images/shop15/common/spec/ico-tech-spec-screen-camera-bp3.png",
      "description": "12 megapixel"
    }, {
      "name": "Battery life",
      "imageUrl": "https://www.o2.co.uk/shop/homepage/images/shop15/common/spec/ico-tech-spec-screen-battery-bp3.png",
      "description": "Talk time: Up to 14 hours on 3G"
    }, {
      "name": "Weight",
      "imageUrl": "https://www.o2.co.uk/shop/homepage/images/shop15/common/spec/ico-tech-spec-screen-weight-bp3.png",
      "description": "152g"
    }, {
      "name": "Screen size",
      "imageUrl": "https://www.o2.co.uk/shop/homepage/images/shop15/common/spec/ico-tech-spec-screen-screen-size-bp3.png",
      "description": "4.7 inch"
    }],
    "techSpec": [{
      "title": "Overall Specification",
      "data": [{
        "canonicalKey": "talk-time",
        "detailsLabel": "Talk Time",
        "comparisonLabel": "Talk Time",
        "displayValue": "",
        "showOnComparison": true
      }, {
        "canonicalKey": "standby-time",
        "detailsLabel": "Standby Time",
        "comparisonLabel": "Standby Time",
        "displayValue": "",
        "showOnComparison": true
      }, {
        "canonicalKey": "dimensions",
        "detailsLabel": "Dimensions",
        "comparisonLabel": "Dimensions",
        "displayValue": "",
        "showOnComparison": true
      }, {
        "canonicalKey": "weight",
        "detailsLabel": "Weight",
        "comparisonLabel": "Weight",
        "displayValue": "",
        "showOnComparison": true
      }, {
        "canonicalKey": "screen-size",
        "detailsLabel": "Screen Size",
        "comparisonLabel": "Screen Size",
        "displayValue": "",
        "showOnComparison": true
      }, {
        "canonicalKey": "internal-phone-memory",
        "detailsLabel": "Internal Phone Memory",
        "comparisonLabel": "Internal Phone Memory",
        "displayValue": "32GB, 128GB or 256GB",
        "showOnComparison": true
      }, {
        "canonicalKey": "email-capability",
        "detailsLabel": "Email Capability",
        "comparisonLabel": "Email Capability",
        "displayValue": "Yes"
      }, {
        "canonicalKey": "business-recommended",
        "detailsLabel": "Business Recommended",
        "comparisonLabel": "Business Recommended",
        "displayValue": "Yes"
      }, {
        "canonicalKey": "operating-system",
        "detailsLabel": "Operating System",
        "comparisonLabel": "Operating System",
        "displayValue": "iOS 9",
        "showOnComparison": true
      }, {
        "canonicalKey": "splash-proof",
        "detailsLabel": "Splash proof",
        "comparisonLabel": "Splash proof",
        "displayValue": "",
        "showOnComparison": true
      }]
    }, {
      "title": "Entertainment",
      "data": [{
        "canonicalKey": "back-camera",
        "detailsLabel": "Back Camera",
        "comparisonLabel": "Back Camera",
        "displayValue": "",
        "showOnComparison": true
      }, {
        "canonicalKey": "front-camera",
        "detailsLabel": "Front Camera",
        "comparisonLabel": "Front Camera",
        "displayValue": "",
        "showOnComparison": true
      }, {
        "canonicalKey": "video-capture",
        "detailsLabel": "Video Capture",
        "comparisonLabel": "Video Capture",
        "displayValue": "Yes"
      }, {
        "canonicalKey": "nfc",
        "detailsLabel": "NFC",
        "comparisonLabel": "NFC",
        "displayValue": "Yes"
      }, {
        "canonicalKey": "music-player",
        "detailsLabel": "Music Player",
        "comparisonLabel": "Music Player",
        "displayValue": "Yes"
      }, {
        "canonicalKey": "fm-radio",
        "detailsLabel": "FM Radio",
        "comparisonLabel": "FM Radio",
        "displayValue": "No"
      }]
    }, {
      "title": "Connectivity",
      "data": [{
        "canonicalKey": "data-connectivity",
        "detailsLabel": "Data Connectivity",
        "comparisonLabel": "Data Connectivity",
        "displayValue": ""
      }, {
        "canonicalKey": "band-type",
        "detailsLabel": "Band Type",
        "comparisonLabel": "Band Type",
        "displayValue": "Quad"
      }, {
        "canonicalKey": "bluetooth",
        "detailsLabel": "Bluetooth",
        "comparisonLabel": "Bluetooth",
        "displayValue": "4.2"
      }, {
        "canonicalKey": "stereo-bluetooth",
        "detailsLabel": "Stereo Bluetooth",
        "comparisonLabel": "Stereo Bluetooth",
        "displayValue": "Yes"
      }, {
        "canonicalKey": "wi-fi",
        "detailsLabel": "Wi-Fi",
        "comparisonLabel": "Wi-Fi",
        "displayValue": ""
      }, {
        "canonicalKey": "gps",
        "detailsLabel": "GPS",
        "comparisonLabel": "GPS",
        "displayValue": "Yes",
        "showOnComparison": true
      }, {
        "canonicalKey": "3g",
        "detailsLabel": "3G",
        "comparisonLabel": "3G",
        "displayValue": "Yes"
      }, {
        "canonicalKey": "4g",
        "detailsLabel": "4G",
        "comparisonLabel": "4G",
        "displayValue": "Yes"
      }]
    }]
  }}



var tafCount = 0;
function prepareFileName(tariffData){
    var tariffFileName = "",filePath = "D:/NodeAutomations-master";

}

var childDeviceJSONStructure = deviceJSONStructure;
var childaccessoryJsonStructure = accessoryJsonStructure;

var leadPointer,deviceImageName,leadMod,arrayEnd,arrayEnd2;
function buildDevices(accModelData,deviceModelData){
//console.log("Test"+deviceModelData.length);
for (key in deviceModelData) {
    if(deviceModelData[key].status=='lead'){    
        
    deviceJSONStructure.brand = deviceModelData[key].brand;       
    deviceJSONStructure.leadModelInFamily = deviceModelData[key].guid;        
    deviceJSONStructure.model = deviceModelData[key].name+" "+deviceModelData[key].colors;
    deviceJSONStructure.sku.code = deviceModelData[key].SKU;
    deviceJSONStructure.classification.colour.display = deviceModelData[key].colors;
    deviceJSONStructure.classification.colour.primary = deviceModelData[key].hex;
    deviceJSONStructure.classification.memory.value = deviceModelData[key].sizes+"";
    deviceJSONStructure.classification.memory.display = deviceModelData[key].sizes+"GB";
    deviceJSONStructure.ccaProductInformation = deviceModelData[key].brand+" "+deviceModelData[key].name;    
    deviceJSONStructure.snippet = deviceModelData[key].snippet;
    deviceJSONStructure.colourGroup = deviceModelData[key].colorgroup;
    fullfilmentDataString = "HAN "+deviceJSONStructure.brand +" "+ 
                                                             deviceJSONStructure.model+" "+
                                                             deviceModelData[key].SKU;
        if(fullfilmentDataString.length > 50){
            console.log("\n\nfullfilment data lenght is : "+fullfilmentDataString.length+" And SKU : "+deviceJSONStructure.sku.code);
        }
        
        deviceJSONStructure.fulfillmentData.productName = fullfilmentDataString;
        technicalSpecification.technicalSpecification.featuredSpecifications[0].description =  deviceModelData[key].camera+"MP";
        technicalSpecification.technicalSpecification.featuredSpecifications[1].description =  deviceModelData[key].batterylife+" Hours";
        technicalSpecification.technicalSpecification.featuredSpecifications[2].description =  deviceModelData[key].weight+"g";
        technicalSpecification.technicalSpecification.featuredSpecifications[3].description =  deviceModelData[key].screen+" inch";
        
        technicalSpecification.technicalSpecification.techSpec[0].data[0].displayValue = deviceModelData[key].batterylife+" Hours";
        technicalSpecification.technicalSpecification.techSpec[0].data[1].displayValue = deviceModelData[key].standbytime+" Hours";
        technicalSpecification.technicalSpecification.techSpec[0].data[2].displayValue = deviceModelData[key].dimensions;
        technicalSpecification.technicalSpecification.techSpec[0].data[3].displayValue = deviceModelData[key].weight+"g";
        technicalSpecification.technicalSpecification.techSpec[0].data[4].displayValue = deviceModelData[key].screen+" inch";
        technicalSpecification.technicalSpecification.techSpec[0].data[5].displayValue = deviceModelData[key].sizes+"GB";
        technicalSpecification.technicalSpecification.techSpec[0].data[9].displayValue = deviceModelData[key].splashproof;
        technicalSpecification.technicalSpecification.techSpec[1].data[0].displayValue = deviceModelData[key].camera+"MP";
        technicalSpecification.technicalSpecification.techSpec[1].data[1].displayValue = deviceModelData[key].frontcamera;
        technicalSpecification.technicalSpecification.techSpec[2].data[0].displayValue = deviceModelData[key].dataconnection;
        technicalSpecification.technicalSpecification.techSpec[2].data[1].displayValue = deviceModelData[key].bandtype;
        technicalSpecification.technicalSpecification.techSpec[2].data[2].displayValue = deviceModelData[key].bluetooth;
        technicalSpecification.technicalSpecification.techSpec[2].data[4].displayValue = deviceModelData[key].wifi;
        
        leadModelInformation.screenSize.value = deviceModelData[key].screen+"";
        leadModelInformation.screenSize.display = deviceModelData[key].screen+" inch";
        leadModelInformation.batteryLife.value = deviceModelData[key].batterylife+"";
        leadModelInformation.batteryLife.display = deviceModelData[key].batterylife+" Hours";
        leadModelInformation.weight.value = deviceModelData[key].weight+"";
        leadModelInformation.weight.display = deviceModelData[key].weight+"g";
        leadModelInformation.cameraResolution.value = deviceModelData[key].camera+"";
        leadModelInformation.cameraResolution.display = deviceModelData[key].camera+"MP";
        
            
            
       
    
    leadMod = deviceModelData[key].name;
    leadMod = leadMod.split(" ");
    arrayEnd = leadMod.length;
    arrayEnd2 = arrayEnd-1;
     
    leadMod = leadMod.splice(-arrayEnd,arrayEnd2).join(" ");
    deviceJSONStructure.modelFamily = leadMod;
        console.log("array2 "    + deviceJSONStructure.modelFamily);
        
        
        
    
    //console.log("before is at "+deviceJSONStructure);

        
    deviceJSONStructure=merge_options(deviceJSONStructure,features);   
        if(deviceModelData[key].featuretype == 'image'){
            features.features.featuredItems = imageFeatures;
            deviceJSONStructure=merge_options(deviceJSONStructure,features);
            //console.log(features.features.featuredItems)
            
        }
        else if(deviceModelData[key].featuretype == 'text'){
            features.features.featuredItems = textFeatures;
            deviceJSONStructure=merge_options(deviceJSONStructure,features);
        
        }
        
        deviceJSONStructure=merge_options(deviceJSONStructure,leadModelInformation); 
        deviceJSONStructure=merge_options(deviceJSONStructure,technicalSpecification); 
        
        
        
        
    
    deviceJSONStructure.id = deviceModelData[key].guid;
        
   // console.log("Test"+deviceJSONStructure.brand);
    jsonName = ((deviceModelData[key].brand).toLowerCase()).replace(/ /g,"_") +"_"+                        
               ((deviceModelData[key].name).toLowerCase()).replace(/ /g,"_")  +"_"+ 
                ((deviceModelData[key].colors).toLowerCase()).replace(/ /g,"_") +".json";
    //console.log(jsonName);
    deviceImageName = ((deviceModelData[key].brand).toLowerCase()).replace(/ /g,"_") +"_"+                        
               ((deviceModelData[key].name).toLowerCase()).replace(/ /g,"_")  +"_"+ 
                ((deviceModelData[key].colors).toLowerCase()).replace(/ /g,"_");  
        
        changeUnderToHypen = deviceImageName.replaceAll("_","-");
    
    deviceJSONStructure.images.standard.listSingle = "${image('"+changeUnderToHypen+"-2x1-tile.png')}";       
    deviceJSONStructure.images.standard.details = "${image('"+changeUnderToHypen+"-sku-header.png')}";    
    deviceJSONStructure.images.standard.basket = "${image('"+changeUnderToHypen+"-basket.png')}";     
    deviceJSONStructure.images.standard.tariff = "${image('"+changeUnderToHypen+"-basket.png')}";     
       count =1; 
        
    finalJson = JSON.stringify(deviceJSONStructure, null, 4).replaceAll('"${image(','${image(').replaceAll(')}"',')}');
    finalJson = finalJson.replaceAll('"${idOf(','${idOf(');
    
    fs.mkdir(deviceImageName,function(e){});    
    writeToFile(deviceImageName+"/"+jsonName,finalJson);
        //console.log(deviceImageName+"/"+jsonName)
    leadPointer = key;
    }
    
    else if(deviceModelData[key].status=='child'){
    
    childDeviceJSONStructure.brand = deviceModelData[key].brand;
    delete childDeviceJSONStructure.snippet;
        
    childDeviceJSONStructure.model = deviceModelData[key].name+" "+deviceModelData[key].colors;    
    childDeviceJSONStructure.id = deviceModelData[key].guid;    
    childDeviceJSONStructure.leadModelInFamily = deviceModelData[leadPointer].guid;
    childDeviceJSONStructure.modelFamily = deviceJSONStructure.modelFamily;
    childDeviceJSONStructure.sku.code = deviceModelData[key].SKU;
    childDeviceJSONStructure.ccaProductInformation = deviceModelData[key].brand+" "+deviceModelData[key].name;
    childDeviceJSONStructure.classification.colour.display = deviceModelData[key].colors;
    childDeviceJSONStructure.classification.colour.primary = deviceModelData[key].hex;
    childDeviceJSONStructure.classification.memory.value = deviceModelData[key].sizes+"";
    childDeviceJSONStructure.classification.memory.display = deviceModelData[key].sizes+"GB"; 
    childDeviceJSONStructure.colourGroup = deviceModelData[key].colorgroup;    
     fullfilmentDataString = "HAN "+childDeviceJSONStructure.brand +" "+ 
                                                             childDeviceJSONStructure.model+" "+
                                                             deviceModelData[key].SKU;   
        
if(fullfilmentDataString.length>50){
            console.log("\n\nfullfilment data lenght is : "+fullfilmentDataString.length+" And SKU : "+childDeviceJSONStructure.sku.code);
        }
        childDeviceJSONStructure.fulfillmentData.productName = fullfilmentDataString;
        
    jsonName = ((deviceModelData[key].brand).toLowerCase()).replace(/ /g,"_") +"_"+                        
               ((deviceModelData[key].name).toLowerCase()).replace(/ /g,"_")  +"_"+ 
                ((deviceModelData[key].colors).toLowerCase()).replace(/ /g,"_") +".json";
        
//    console.log(jsonName);
    deviceImageName = ((deviceModelData[key].brand).toLowerCase()).replace(/ /g,"_") +"_"+                        
                       ((deviceModelData[key].name).toLowerCase()).replace(/ /g,"_")  +"_"+ 
                        ((deviceModelData[key].colors).toLowerCase()).replace(/ /g,"_");  
        
    changeUnderToHypen = deviceImageName.replaceAll("_","-");
        
    childDeviceJSONStructure.images.standard.listSingle = "${image('"+changeUnderToHypen+"-2x1-tile.png')}";      
    childDeviceJSONStructure.images.standard.details = "${image('"+changeUnderToHypen+"-sku-header.png')}";    
    childDeviceJSONStructure.images.standard.basket = "${image('"+changeUnderToHypen+"-basket.png')}";     
    childDeviceJSONStructure.images.standard.tariff = "${image('"+changeUnderToHypen+"-basket.png')}";

        finalJson = JSON.stringify(childDeviceJSONStructure, null, 4).replaceAll('"${image(','${image(').replaceAll(')}"',')}');
    finalJson = finalJson.replaceAll('"${idOf(','${idOf(');
    
    fs.mkdir(deviceImageName,function(e){});
    writeToFile(deviceImageName+"/"+jsonName,finalJson);   
        
    }
}

for (key in accModelData) {
    if(accModelData[key].status=='lead'){    
        
    accessoryJsonStructure.brand = accModelData[key].brand;       
    accessoryJsonStructure.leadModelInFamily = accModelData[key].guid;        
    accessoryJsonStructure.model = accModelData[key].name+" "+accModelData[key].colors;
    accessoryJsonStructure.sku.code = accModelData[key].SKU;
    accessoryJsonStructure.price = accModelData[key].price;
    accessoryJsonStructure.type = accModelData[key].type;
    accessoryJsonStructure.classification.colour.display = accModelData[key].colors;
    accessoryJsonStructure.classification.colour.primary = accModelData[key].hex; 
    accessoryJsonStructure.snippet = accModelData[key].snippet;
    accessoryJsonStructure.sellingPoints = accModelData[key].sellpoint;
    accessoryJsonStructure.compatibilityList = accModelData[key].compatible;
    accessoryJsonStructure["features"]["banner"][0]["heading"] = accModelData[key].sellpoint[0];
    accessoryJsonStructure["features"]["banner"][1]["heading"] = accModelData[key].sellpoint[1];
    accessoryJsonStructure["features"]["banner"][2]["heading"] = accModelData[key].sellpoint[2];
    accessoryJsonStructure["features"]["banner"][3]["heading"] = accModelData[key].sellpoint[3];
    accessoryJsonStructure.colourGroup = accModelData[key].colorgroup;
    fullfilmentDataString = "ACC "+accessoryJsonStructure.brand +" "+ 
                                                             accessoryJsonStructure.model+" "+
                                                             accModelData[key].SKU;
        if(fullfilmentDataString.length > 50){
            console.log("\n\nfullfilment data lenght is : "+fullfilmentDataString.length+" And SKU : "+accessoryJsonStructure.sku.code);
        }
        
        accessoryJsonStructure.fulfillmentData.productName = fullfilmentDataString;
   
            
            
       
    
    leadMod = accModelData[key].name;
    leadMod = leadMod.split(" ");
    arrayEnd = leadMod.length;
    arrayEnd2 = arrayEnd-1;
     
    leadMod = leadMod.splice(-arrayEnd,arrayEnd2).join(" ");
    accessoryJsonStructure.modelFamily = leadMod;
        console.log("array2 "    + accessoryJsonStructure.modelFamily);
        
        
        
    
    //console.log("before is at "+accessoryJsonStructure);

	accessoryJsonStructure.id = accModelData[key].guid;
        
   // console.log("Test"+accessoryJsonStructure.brand);
    jsonName = ((accModelData[key].brand).toLowerCase()).replace(/ /g,"_") +"_"+                        
               ((accModelData[key].name).toLowerCase()).replace(/ /g,"_")  +"_"+ 
                ((accModelData[key].colors).toLowerCase()).replace(/ /g,"_") +".json";
    //console.log(jsonName);
    deviceImageName = ((accModelData[key].brand).toLowerCase()).replace(/ /g,"_") +"_"+                        
               ((accModelData[key].name).toLowerCase()).replace(/ /g,"_")  +"_"+ 
                ((accModelData[key].colors).toLowerCase()).replace(/ /g,"_");  
        
        changeUnderToHypen = deviceImageName.replaceAll("_","-");
    
    accessoryJsonStructure.images.standard.listSingle = "${image('"+changeUnderToHypen+"-2x1-tile.png')}";       
    accessoryJsonStructure.images.standard.details = "${image('"+changeUnderToHypen+"-sku-header.png')}";    
    accessoryJsonStructure.images.standard.basket = "${image('"+changeUnderToHypen+"-basket.png')}";     
    accessoryJsonStructure.images.standard.tariff = "${image('"+changeUnderToHypen+"-basket.png')}";     
       count =1;
	   
	   console.log(accModelData[accModelData.length-1].status);
	   
		if(key!=(accModelData.length-2))	   
		{ 
	console.log(typeof(key);
		/* if(accModelData[key+1].status=='lead'){
			console.log(accModelData[key+1].status);
				delete accessoryJsonStructure.classification;
		}
		}else if(accModelData[accModelData.length-1].status=='lead')  {
			delete accessoryJsonStructure.classification;
		} */
    finalJson = JSON.stringify(accessoryJsonStructure, null, 4).replaceAll('"${image(','${image(').replaceAll(')}"',')}');
    finalJson = finalJson.replaceAll('"${idOf(','${idOf(');
    
    fs.mkdir(deviceImageName,function(e){});    
    writeToFile(deviceImageName+"/"+jsonName,finalJson);
        //console.log(deviceImageName+"/"+jsonName)
    leadPointer = key;
	
    }
    
    else if(accModelData[key].status=='child'){
    
    childaccessoryJsonStructure.brand = accModelData[key].brand;
    delete childaccessoryJsonStructure.snippet;
        
    childaccessoryJsonStructure.model = accModelData[key].name+" "+accModelData[key].colors;    
    childaccessoryJsonStructure.id = accModelData[key].guid;    
    childaccessoryJsonStructure.leadModelInFamily = accModelData[leadPointer].guid;
    childaccessoryJsonStructure.modelFamily = accessoryJsonStructure.modelFamily;
    childaccessoryJsonStructure.sku.code = accModelData[key].SKU;
    childaccessoryJsonStructure.classification.colour.display = accModelData[key].colors;
    childaccessoryJsonStructure.classification.colour.primary = accModelData[key].hex;
    childaccessoryJsonStructure.colourGroup = accModelData[key].colorgroup;    
     fullfilmentDataString = "ACC "+childaccessoryJsonStructure.brand +" "+ 
                                                             childaccessoryJsonStructure.model+" "+
                                                             accModelData[key].SKU;   
        
if(fullfilmentDataString.length>50){
            console.log("\n\nfullfilment data lenght is : "+fullfilmentDataString.length+" And SKU : "+childaccessoryJsonStructure.sku.code);
        }
        childaccessoryJsonStructure.fulfillmentData.productName = fullfilmentDataString;
        
    jsonName = ((accModelData[key].brand).toLowerCase()).replace(/ /g,"_") +"_"+                        
               ((accModelData[key].name).toLowerCase()).replace(/ /g,"_")  +"_"+ 
                ((accModelData[key].colors).toLowerCase()).replace(/ /g,"_") +".json";
        
//    console.log(jsonName);
    deviceImageName = ((accModelData[key].brand).toLowerCase()).replace(/ /g,"_") +"_"+                        
                       ((accModelData[key].name).toLowerCase()).replace(/ /g,"_")  +"_"+ 
                        ((accModelData[key].colors).toLowerCase()).replace(/ /g,"_");  
        
    changeUnderToHypen = deviceImageName.replaceAll("_","-");
        
    childaccessoryJsonStructure.images.standard.listSingle = "${image('"+changeUnderToHypen+"-2x1-tile.png')}";      
    childaccessoryJsonStructure.images.standard.details = "${image('"+changeUnderToHypen+"-sku-header.png')}";    
    childaccessoryJsonStructure.images.standard.basket = "${image('"+changeUnderToHypen+"-basket.png')}";     
    childaccessoryJsonStructure.images.standard.tariff = "${image('"+changeUnderToHypen+"-basket.png')}";

        finalJson = JSON.stringify(childaccessoryJsonStructure, null, 4).replaceAll('"${image(','${image(').replaceAll(')}"',')}');
    finalJson = finalJson.replaceAll('"${idOf(','${idOf(');
    fs.mkdir(deviceImageName,function(e){});
    writeToFile(deviceImageName+"/"+jsonName,finalJson);   
        
    }
}


}


// Main Function for the Application
(function(){
    console.log("Application has started");
    readDeviceInformation();
    buildDevices(accModelData,deviceModelData);
    //console.log("Tariffs are available in the "+filePath+" folder now");
    //console.log("Modified files created ..."+modifiedFileCount);
})();
