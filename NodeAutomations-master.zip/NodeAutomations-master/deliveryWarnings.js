var beautify = require('js-beautify');
var fs = require('fs');
var prettyjson = require('prettyjson');
var options = {
  noColor: true
};

    merchPricesSheetURL = 'ExcelOutput/DeviceStockInfo.xlsx',
	deviceSkuCell = 'A'
	stockCell = 'B',
	stockMessageCell = 'C',
	deviceTypeCell = 'D'
	
    payGTab_Min_Count = 1,payGTab_Max_Count = 1;
    
    var XLSX = require('xlsx'),excelbuilder = require('excel4node');


function loadPayGSKUPrices(){
    try{
        cashPriceCollection = [], paygPriceCollection = [];
        var workbook = XLSX.readFile(merchPricesSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading merchandising Pricing Sheet...");
        console.log(sheet_name_list);
        
        sheet_name_list.forEach(function(y) {
            
         if( y === "DeviceStockInfo"){
			 
          var worksheet = workbook.Sheets[y];
          for (z in worksheet) {
			  
              if(payGTab_Min_Count <= payGTab_Max_Count){
                  if(z[0] === '!') continue;
                  var deviceSku = deviceSkuCell+payGTab_Min_Count;
                  var stock = stockCell+payGTab_Min_Count;
                  var stockMessage = stockMessageCell+payGTab_Min_Count;
                  var deviceType = deviceTypeCell+payGTab_Min_Count;
                  
			
				
                  var deviceDeatils = {
                     "deviceSku": worksheet[priority].v,
					 "stock": worksheet[deviceId].v,
                     "stockMessage": worksheet[upfront].v,
                     "deviceType": worksheet[pid].v
					 }
                  paygPriceCollection.push(deviceDeatils);
                  //console.log(paygPriceCollection);
                  payGTab_Min_Count++; 
				  
             }
          }
         }
       });
  }
  catch(e){
        console.log("Oops.......");
        console.log("Something is wrong with Merch Price sheet");
        console.log(e);
  }
}




require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

var deviceDetailsCol = [], modifiedFileCount =0;


recursive('D:/IdeaProjects/productCatalogueData_Master2/catalogueData/device/', function (err, files) {
    
    var jsonFileCount = 0, jsonFilesIndex = 0;
    var json;
    console.log(files.length);
    var jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
    deviceDetailsCol =[];
    loadPayGSKUPrices();
    jsonFiles.forEach(function(file) {
        var content =  require(file);
       // console.log(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        //if(json["id"] == "8281864e-faf7-4d28-86d1-5346b64f1c7cdvsd")
        addCnCFlag(json,file,newPathsContainer,paygPriceCollection);
        
    });
});




function addCnCFlag(json,file,newPathsContainer,paygPriceCollection){
console.log(paygPriceCollection.length);
var tariffupsellpath = "D:/IdeaProjects/productCatalogueData_Master2/catalogueData/media/attachments/common/tariffUpsell.txt"
	
 	    fs.readFile(tariffupsellpath, 'utf8', function (err,data) {
			var myFlag = true;
			for(key in paygPriceCollection){
				myFlag = true;
				
				
      if (err) {
        return console.log(err);
      }
        data = JSON.parse(data);
		
         var objectLen = Object.keys(data).length;
        for (var x in data) { 
		
  if(data[x].deviceId==paygPriceCollection[key].deviceId){

			for (var y in data[x].tariffRows){
				

	if(data[x].tariffRows[y].planId == paygPriceCollection[key].pid && data[x].tariffRows[y].upfrontCostInPence == paygPriceCollection[key].upfront){	
				
		if(paygPriceCollection[key].additionalR!="NA" && paygPriceCollection[key].additionalR!="na" && paygPriceCollection[key].additionalR!="undefined" ){
				data[x].tariffRows[y].additional = paygPriceCollection[key].additionalR;
				
				}
		if(paygPriceCollection[key].secondaryR!="NA" && paygPriceCollection[key].secondaryR!="na" && paygPriceCollection[key].secondaryR!="undefined" ){
				data[x].tariffRows[y].secondary = paygPriceCollection[key].secondaryR;
				
				}
		if(paygPriceCollection[key].primary!="NA" && paygPriceCollection[key].primary!="na" && paygPriceCollection[key].primary!="undefined" ){
				data[x].tariffRows[y].primary = paygPriceCollection[key].primary;
				
				}
		if(paygPriceCollection[key].included!="NA" && paygPriceCollection[key].included!="na" && paygPriceCollection[key].included!="undefined" ){
				data[x].tariffRows[y].included = paygPriceCollection[key].included;
				
				}
		console.log(data[x].deviceId);
				}
       
	}
  }else if(myFlag) { 
		myFlag = false;
		//console.log(paygPriceCollection[key].deviceId);

		}
	
        }
		
          
     data=JSON.stringify(data);
        //console.log(data);
       data = beautify(data, { indent_size: 2 }); 
       writeToFile(tariffupsellpath,data);      
    }
    }); 
   }





function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}



function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } 
	else{console.log("modified");}
});
     
}
addCnCFlag();