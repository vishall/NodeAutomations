/* Please fill the below information before runing the script */
var prodCatURL = 'C:/Kanban/productCatalogueData_Master/catalogueData/',
    associationSheetURL = 'ExcelOutput/imagePathChange.xlsx',
    sourceSKUCell = 'A',
    accyAssociationContainer = [],
    accyAssociationContainerLength, newPathsContainer = [];

/* Do not modify the below script if you are not sure about the changes*/

var fs = require('graceful-fs'),
    XLSX = require('xlsx'),
    recursive = require('recursive-readdir'),
    beautify = require('js-beautify'),
    modifiedFileCount = 0;
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function loadAccyAssociations() {
    try {
        var workbook = XLSX.readFile(associationSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading Device Comp Sheet...");
        sheet_name_list.forEach(function(sheetName) {
            if (sheetName === "Sheet1") {
                var worksheet = workbook.Sheets[sheetName];
                var accy_Sheet_SKU_Count = 1;
                for (currentSheet in worksheet) {
                    if (currentSheet[0] === '!') continue;
                    if (currentSheet[0] === 'A') {
                        var currentAccyAssociationMatrix = {
                            "sourceSKU": worksheet[currentSheet].v,
                            "targetSKU": []
                        }
                        accyAssociationContainer.push(currentAccyAssociationMatrix);
                    } else {
                        accyAssociationContainer[(accyAssociationContainer.length - 1)]["targetSKU"].push({
                            "sku": worksheet[currentSheet].v
                        });
                    }
                }
            }

        });
    } catch (e) {
        console.log("Oops.......");
        console.log("Something is wrong with given Device sheet");
        console.log(e);
    }
}

function associateAccessories() {
    try {
        var prodCatAccyURL = prodCatURL + "/device/";
        accyAssociationContainerLength = accyAssociationContainer.length;
        recursive(prodCatAccyURL, function(err, files) {

            if (!err && files.length) {
                var jsonFiles = files.filter(function(file) {
                    return file.substr(-5) === '.json';
                })
                jsonFiles.forEach(function(file) {
                    checkStandard(file);
                    sourceJson = json;
                    for (var accyAssociationContainerCount = 0; accyAssociationContainerCount < accyAssociationContainerLength; accyAssociationContainerCount++) {
                        if (accyAssociationContainer[accyAssociationContainerCount]["sourceSKU"] === sourceJson["sku"]["code"]) {
                            sourcePath(file, sourceJson);
                            targetDeviceUpdate(sourceJson["images"]["standard"], accyAssociationContainerCount);
                        }
                    }
                });
            } else {
                console.log("Oops.......");
                console.log("Error in the ProdCat URL")
            }
        });
    } catch (e) {
        console.log("Oops.......");
        console.log("Something is wrong with devices ");
    }
}

function sourcePath(file, sourceJson) {
    var updatedPath = file.substr((file.indexOf("catalogueData")) + 13);
    updatedPath = updatedPath.substr(0, updatedPath.lastIndexOf("\\")).replace(/\\/g, '/') + "/";
    var imagesArray = ["listSingle", "listHalf", "listDouble", "details", "tariff", "basket", "side", "back"];
    for (var img = 0; img < imagesArray.length; img++) {
        if (sourceJson["images"]["standard"][imagesArray[img]]) {
            if (sourceJson["images"]["standard"][imagesArray[img]].indexOf("image") === -1) {
                sourceJson["images"]["standard"][imagesArray[img]] = "" + "${image('" + updatedPath + sourceJson["images"]["standard"][imagesArray[img]] + "')}";
            } else {
                var arr = sourceJson["images"]["standard"][imagesArray[img]].toString().split("\'");
                sourceJson["images"]["standard"][imagesArray[img]] = "" + "${image('" + updatedPath + arr[1] + "')}";
                newPathsContainer.push("${image('" + updatedPath + arr[1] + "')}");
            }
        }
    }
}

function targetDeviceUpdate(sourceImages, count) {
    var temp = sourceImages;
    recursive(prodCatURL + "/device", function(err, files) {
        var jsonFiles = files.filter(function(file) {
            return file.substr(-5) === '.json';
        })
        jsonFiles.forEach(function(file) {
            checkStandard(file)
            for (var accyAssociationContainerCount = 0; accyAssociationContainerCount < accyAssociationContainerLength; accyAssociationContainerCount++) {
                var deviceSKUObject = accyAssociationContainer[accyAssociationContainerCount]["targetSKU"],
                    deviceSKUObjectLength = accyAssociationContainer[accyAssociationContainerCount]["targetSKU"].length;
                for (var deviceSKUObjectCount = 0; deviceSKUObjectCount < deviceSKUObjectLength; deviceSKUObjectCount++) {
                    targetDeviceImages(json, temp, file, count);
                    break;
                }
            }

        });
    });
}

function writeToFile(file, content) {
    fs.writeFile(file, content, function(err) {
        if (err) {
            console.log(err);
        }
    });

}

function targetDeviceImages(json, sourceImages, file, count) {
    var deviceSKUObject = accyAssociationContainer[count]["targetSKU"],
        deviceSKUObjectLength = accyAssociationContainer[count]["targetSKU"].length;
    for (var deviceSKUObjectCount = 0; deviceSKUObjectCount < deviceSKUObjectLength; deviceSKUObjectCount++) {
        if (deviceSKUObject[deviceSKUObjectCount]["sku"] === json["sku"]["code"]) {
            updateFile(json, count, file, newPathsContainer, sourceImages);
            break;
        }
    }

}

function updateFile(json, count, file, newPathsContainer, sourceImages) {
    var imagePath = file.substr(0, file.lastIndexOf("\\")).replace(/\\/g, '/');
    json["images"]["standard"] = sourceImages;
    recursive(imagePath, function(err, files) {
        var allImages = files.filter(function(file) {
            return file.substr(-4) === '.png' || file.substr(-4) === '.jpg';
        });
        imageArray = allImages.toString().split(",");
        for (var deleteFile = 0; deleteFile < imageArray.length; deleteFile++) {
            fs.appendFile("ExcelOutput/deletedImages.txt", imageArray[deleteFile] + "\r\n", function(err) {
                if (err) {
                    return console.log(err);
                }
            })
            fs.unlink(imageArray[deleteFile], function(err) {
            });
        }
    });
    var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent, file, newPathsContainer);
}

function convertBacktoOriginalState(newContent, file, newPathsContainer) {
    var originalState;

    newContent = beautify(newContent, {
        indent_size: 3,
        "preserve_newlines": false,
        "keep_array_indentation": true
    });
    for (var jCount = 0; jCount < newPathsContainer.length; jCount++) {
        var oldPathValue = '"' + newPathsContainer[jCount] + '"';
        var regExpCheck = new RegExp(escapeRegExp(oldPathValue), "g");
        newContent = newContent.replace(regExpCheck, newPathsContainer[jCount]);
    }
    writeToFile(file, newContent);

}

function checkStandard(file) {
    var content = require(file);
    var newContent = content;
    var newSearch = newContent.match(pathRegExp);
    if (newSearch != null) {
        var uniqueArray = newSearch.filter(function(elem, pos) {
            return newSearch.indexOf(elem) == pos;
        });
        for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
            var newPathValue = '"' + uniqueArray[jCount] + '"';
            var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
            newPathsContainer.push(uniqueArray[jCount]);
            newContent = newContent.replace(regExpCheck, newPathValue);
            var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
        }
        json = JSON.parse(newContent);
    } else {
        json = JSON.parse(newContent);
    }
    return json;
}

// Main Function for the Application
(function() {
    console.log("Application has started");
    loadAccyAssociations();
    associateAccessories();
})();