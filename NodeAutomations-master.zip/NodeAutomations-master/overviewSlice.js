var beautify = require('js-beautify');
var fs = require('fs');
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};
var recursive = require('recursive-readdir');

var refurbJsonList = [];
var newPathsContainer = [],
    temp, json;
recursive('C:/Kanban/productCatalogueData_Master/catalogueData/device/sony-ericsson', function(err, files) {
    var allJsonFiles = files.filter(function(file) {
        return file.substr(-5) === '.json';
    });
    allJsonFiles.forEach(function(file) {
        checkStandard(file);
        if (json["id"] == json["leadModelInFamily"] && json["condition"] == "Refurb") {
            if (json["features"]) {
                if (json["features"]["overwriteWith"] || json["overwrites"])
                    console.log("Please check for the river page of " + json["model"]);
                if (json["features"]["featuredItems"]) {
                    var totalSlice = json["features"]["featuredItems"];
                    var slice = totalSlice.length;
                    while (slice--) {
                        if (totalSlice[slice]["textData"]) {
                            if (totalSlice[slice]["textData"][0]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") >= 0 && totalSlice[slice]["textData"][1]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") >= 0) {
                                totalSlice.splice(slice, 1);
                            } else if (totalSlice[slice]["textData"][0]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") >= 0 && totalSlice[slice]["textData"][1]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") < 0 && slice != totalSlice.length - 1) {
                                console.log("Please check overview slice of " + json["model"]);
                            } else if (totalSlice[slice]["textData"][0]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") < 0 && totalSlice[slice]["textData"][1]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") >= 0 && slice != totalSlice.length - 1) {
                                console.log("Please check overview slice of " + json["model"]);
                            } else if (totalSlice[slice]["textData"][0]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") >= 0 && totalSlice[slice]["textData"][1]["content"].toLowerCase().trim().length == 0 && slice == totalSlice.length - 1) {
                                totalSlice.splice(slice, 1);
                            } else if (totalSlice[slice]["textData"][0]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") >= 0 && totalSlice[slice]["textData"][1]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") < 0 && slice == totalSlice.length - 1) {
                                totalSlice[slice]["textData"][0]["content"] = totalSlice[slice]["textData"][1]["content"];
                                totalSlice[slice]["textData"][1]["content"] = " "
                                totalSlice[slice]["textData"][0]["heading"] = totalSlice[slice]["textData"][1]["heading"];
                                totalSlice[slice]["textData"][1]["heading"] = " "
                            } else if (totalSlice[slice]["textData"][0]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") < 0 && totalSlice[slice]["textData"][1]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") >= 0 && slice == totalSlice.length - 1) {
                                totalSlice[slice]["textData"][1]["content"] = " ";
                                totalSlice[slice]["textData"][1]["heading"] = " ";
                            }
                        } else if (totalSlice[slice]["mediaData"]) {
                            if (json["features"]["featuredItems"][slice]["mediaData"]["text"]["content"].toLowerCase().indexOf("o2 is working to try and reduce waste.") >= 0) {
                                totalSlice.splice(slice, 1);
                            }
                        }
                    }
                    var addNew = json["features"]["featuredItems"].length;
                    if (addNew === 4) {
                        json["features"]["featuredItems"][addNew] = {
                            "featureType": "image",
                            "mediaData": {
                                "url": "https://www.o2.co.uk/shop/homepage/images/shop15/brand/sony/xperia-m2/sony-m2-environment-img-m-right-3-device-details-bp3-270115.jpg",
                                "alignment": "right",
                                "text": {
                                    "heading": "Why doesn't this phone come with a charger?",
                                    "content": "O2 is working to try and reduce waste. And as 70% of people already have a USB charger at home, we've decided to not include one with your phone. If you do need a charger you can add one after choosing your tariff. o2 does not make money from selling the charger separately."
                                }
                            }
                        };
                    } else {
                        for (var i = addNew; i > 3; i--) {

                            json["features"]["featuredItems"][i] = json["features"]["featuredItems"][i - 1];
                            if (i === 4) {
                                json["features"]["featuredItems"][i] = {
                                    "featureType": "image",
                                    "mediaData": {
                                        "url": "https://www.o2.co.uk/shop/homepage/images/shop15/brand/sony/xperia-m2/sony-m2-environment-img-m-right-3-device-details-bp3-270115.jpg",
                                        "alignment": "right",
                                        "text": {
                                            "heading": "Why doesn't this phone come with a charger?",
                                            "content": "O2 is working to try and reduce waste. And as 70% of people already have a USB charger at home, we've decided to not include one with your phone. If you do need a charger you can add one after choosing your tariff. o2 does not make money from selling the charger separately."
                                        }
                                    }
                                }
                            }
                        }

                    }

                }
            }
            if (json["features"] && json["condition"] == "Refurb")
                if (json["features"]["featuredItems"])
                    var n = json["features"]["featuredItems"].length;
            if (n != 0)
                for (var k = 0; k < n; k++) {
                    if (json["features"]["featuredItems"][k]["mediaData"]) {
                        if (k % 2 == 0)
                            json["features"]["featuredItems"][k]["mediaData"]["alignment"] = "right";
                        else
                            json["features"]["featuredItems"][k]["mediaData"]["alignment"] = "left";
                    }
                }
            var fileNewContent = JSON.stringify(json);
            convertBacktoOriginalState(fileNewContent, file, newPathsContainer);
        }
    });
});

function checkStandard(file) {
    var content = require(file);
    var newContent = content;
    var newSearch = newContent.match(pathRegExp);
    if (newSearch != null) {
        var uniqueArray = newSearch.filter(function(elem, pos) {
            return newSearch.indexOf(elem) == pos;
        });
        for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
            var planPathValue = '"' + uniqueArray[jCount] + '"';
            var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
            newPathsContainer.push(uniqueArray[jCount]);
            newContent = newContent.replace(regExpCheck, planPathValue);
            var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
        }
        json = JSON.parse(newContent);
    } else {
        json = JSON.parse(newContent);
    }
    return json;
}

function writeToFile(file, content) {
    fs.writeFile(file, content, function(err) {
        if (err) {
            console.log(err);
        }
    });
}

function convertBacktoOriginalState(newContent, file, newPathsContainer) {
    var originalState;
    newContent = beautify(newContent, {
        indent_size: 3,
        "preserve_newlines": false,
        "keep_array_indentation": true
    });
    for (var jCount = 0; jCount < newPathsContainer.length; jCount++) {
        var oldPathValue = '"' + newPathsContainer[jCount] + '"';
        var regExpCheck = new RegExp(escapeRegExp(oldPathValue), "g");
        newContent = newContent.replace(regExpCheck, newPathsContainer[jCount]);
    }
    writeToFile(file, newContent);
}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}