import groovy.io.FileType
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

/**
 * Script to modify stockInfo, input is read from CSV file. format of CSV is sku, statusToBeChanged, duration, subtype (phone, tab etc.)
 * Sample CSV content:
 * ME434B/A, DelayedDelivery, up to 8 days, phone
 * ME433B/A, InStock, up to 5 days, phone
 * ME432B/A, OutOfStock, up to 6 days, phone
 * ME437B/A, InStock, up to 7 days, phone
 */

def pathToCSV = "D:/NodeAutomations-master/NodeAutomations-master/DeviceStockInfo.csv"




new File(pathToCSV).splitEachLine(",") { fields ->
    processStockInfo(fields[0].trim(), fields[1].trim(), fields[2].trim(), fields[3].trim())
}

def processStockInfo(String sku, String changeStatusTo, String stockMessage, String device) {
    def accessories = "D:/IdeaProjects/productCatalogueData_Master2/catalogueData/device"
    def stockExtendedMessage = "Your new <brand> <model> may take <duration>. You'll pay for the new <device> now," +
            " but won't start paying for your contract until your <device> is on its way."
    def files = []

    def dir = new File(accessories)

    dir.eachFileRecurse (FileType.FILES) { file ->
        if (file.name.endsWith('.json')) {
            files << file
        }
    }

    files.each {
        String buffer = new File(it.path).getText()
        def skuCode = buffer.find(/code.*\"/)

        if(skuCode != null && skuCode.contains(sku)) {
            def brand = buffer.find(/brand.*\"/).replace("brand", "")
            def model = buffer.find(/model.*\"/).replace("model", "")
            brand = brand.replace("\n", "").find(/[A-Za-z0-9\.\-\&]+(\s*[A-Za-z0-9\.\-\&]*)*/)
            model = model.replace("\n", "").find(/[A-Za-z0-9\.\-\&]+(\s*[A-Za-z0-9\.\-\&]*)*/)

            def stockInfo = buffer.find(/(?s)[\"\']stockInfo.*?\}/)
            stockInfo = stockInfo.substring(stockInfo.indexOf('{'), stockInfo.indexOf('}') + 1)
            def object = new JsonSlurper().parseText(stockInfo)
            if(changeStatusTo == "InStock") {
                if (object.stock != null) {
                    object.stock = changeStatusTo
                }
                object = "\"stockInfo\": " + JsonOutput.prettyPrint("{ \"stock\": " + "\"" + object.stock + "\" }")
                buffer = buffer.replaceFirst(/(?s)[\"\']stockInfo.*?\}/, object)
                buffer = buffer.replaceFirst(/[\'\"]disableClickAndCollectNow.*?\,/, "\"disableClickAndCollectNow\": false,")
                buffer = buffer.replaceFirst(/[\'\"]disableClickAndCollect[\'\"].*?\,/, "\"disableClickAndCollect\": false,")
            }
            else {
                if (changeStatusTo == "OutOfStock") {
                    if (object.stock != null) {
                        object.stock = changeStatusTo
                    }
                    object = "\"stockInfo\": " + JsonOutput.prettyPrint("{ \"stock\": " + "\"" + object.stock + "\" }")
                    buffer = buffer.replaceFirst(/(?s)[\"\']stockInfo.*?\}/, object)
                    buffer = buffer.replaceFirst(/[\'\"]disableClickAndCollectNow.*?\,/, "\"disableClickAndCollectNow\": false,")
                    buffer = buffer.replaceFirst(/[\'\"]disableClickAndCollect[\'\"].*?\,/, "\"disableClickAndCollect\": true,")
                }
                else {
                    if (changeStatusTo == "DelayedDelivery") {
                        if (object.stock != null) {
                            object.stock = changeStatusTo
                            object.stockMessage = stockMessage.toLowerCase()
                            object.stockExtendedMessage = stockExtendedMessage.replace("<brand>", brand).replace("<model>", model).replace("<duration>", stockMessage).replace("<device>", device)
                        }
                        object = "\"stockInfo\": " + JsonOutput.prettyPrint(JsonOutput.toJson(object))
                        buffer = buffer.replaceFirst(/(?s)[\"\']stockInfo.*?\}/, object)
                        buffer = buffer.replaceFirst(/[\'\"]disableClickAndCollectNow.*?\,/, "\"disableClickAndCollectNow\": false,")
                        buffer = buffer.replaceFirst(/[\'\"]disableClickAndCollect[\'\"].*?\,/, "\"disableClickAndCollect\": false,")
                    }
                }
            }
            new File(it.path).withWriter('UTF-8') {
                writer ->
                    writer.write(buffer)
            }
        }
    }
}