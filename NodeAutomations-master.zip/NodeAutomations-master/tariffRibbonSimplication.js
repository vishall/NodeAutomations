/* This Script will valoidate the Device PayG and Pay Monthly Prices */
/* Please fill the below information before runing the script */

var prodCatURL = 'D:/IdeaProjects/productCatalogueData_Master2/catalogueData/',
    associationSheetURL = 'D:/NodeAutomations-master/NodeAutomations-master/ExcelOutput/dictionary.xlsx',
    accySKUCell = 'A', accyAssociationContainer = [], accyAssociationContainerLength;
    

/* Do not modify the below script if you are not sure about the changes*/


var fs = require('fs'), XLSX = require('xlsx'),excelbuilder = require('excel4node'),
         recursive = require('recursive-readdir'),beautify = require('js-beautify'),
         prettyjson = require('prettyjson'),modifiedFileCount =0;
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;



function loadAccyAssociations(){
    try{
        var workbook = XLSX.readFile(associationSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading Accy Comp Sheet...");
        sheet_name_list.forEach(function(sheetName) {
          if( sheetName === "Sheet1"){
              var worksheet = workbook.Sheets[sheetName];
              var accy_Sheet_SKU_Count = 1;
              for (currentSheet in worksheet) {
                  if(currentSheet[0] === '!') continue;
                  if(currentSheet[0] === 'A'){
                     var currentAccyAssociationMatrix = {
                         "accysku": worksheet[currentSheet].v,
                         "devicesku" :[]
                     }
                     accyAssociationContainer.push(currentAccyAssociationMatrix);
                  }else{
					  
                     // accyAssociationContainer[(accyAssociationContainer.length-1)]["devicesku"].push({"sku" : worksheet[currentSheet].v});
                  }
              }
              //console.log(accyAssociationContainer);
          }
              
       });
  }
  catch(e){
       // console.log("Oops.......");
       // console.log("Something is wrong with Accys Association Price sheet");
        //console.log(e);
  }
}

 var   merchPricesSheetURL = 'ExcelOutput/MerchTariffSheet.xlsx',
	priorityCell = 'A'
	deviceIdCell = 'B',
	pidCell = 'C',
	upfrontCell = 'D',
	additionalRCell = 'E',
	secondaryRCell = 'F',
	primaryCell = 'G',
	includedCell1 = 'H',
	includedCell2 = 'I',
	includedCell3 = 'J',
    payGTab_Min_Count = 2,payGTab_Max_Count = 69;
    
    var XLSX = require('xlsx'),excelbuilder = require('excel4node');


function merchTariffSheetMaping(){
    try{
        cashPriceCollection = [], paygPriceCollection = [];
        var workbook = XLSX.readFile(merchPricesSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading merchandising Pricing Sheet...");
        console.log(sheet_name_list);
        
        sheet_name_list.forEach(function(y) {
            
         if( y === "Sheet1"){
			 
          var worksheet = workbook.Sheets[y];
          for (z in worksheet) {
			  
              if(payGTab_Min_Count <= payGTab_Max_Count){
                  if(z[0] === '!') continue;
                  var priority = priorityCell+payGTab_Min_Count;
                  var deviceId = deviceIdCell+payGTab_Min_Count;
                  var upfront = upfrontCell+payGTab_Min_Count;
                  var pid = pidCell+payGTab_Min_Count;
                  var additionalR = additionalRCell+payGTab_Min_Count;
                  var secondaryR = secondaryRCell+payGTab_Min_Count;
                  var primary = primaryCell+payGTab_Min_Count;
                  var included1 = includedCell1+payGTab_Min_Count;
                  var included2 = includedCell2+payGTab_Min_Count;
                  var included3 = includedCell3+payGTab_Min_Count;
                  
			
				
                  var priceDeatils = {
                     "priority": worksheet[priority].v,
					 "deviceId": worksheet[deviceId].v,
                     "upfront": worksheet[upfront].v,
                     "pid": worksheet[pid].v,
                     "additionalR": worksheet[additionalR].v,
                     "secondaryR": worksheet[secondaryR].v,
                     "primary": worksheet[primary].v,
                     "included": [ worksheet[included1].v,worksheet[included2].v,worksheet[included3].v]
					 }
                  paygPriceCollection.push(priceDeatils);
                 // console.log(paygPriceCollection);
                  payGTab_Min_Count++;  
				  
             }
          }
         }
       });
  }
  catch(e){
        //console.log("Oops.......");
        //console.log("Something is wrong with Merch Price sheet");
        //console.log(e);
  }
}


function generateExcelFile(){
loadAccyAssociations();
merchTariffSheetMaping();

var dLength = accyAssociationContainer.length,mLength = paygPriceCollection.length,newDevices = [],finalCollection = [];

console.log(mLength);
var myNewData = {};

for(var i = 0; i< dLength; i++){
	for(var j = 0; j< mLength; j++){
		if(accyAssociationContainer[i].accysku==paygPriceCollection[j].deviceId){
			//console.log(accyAssociationContainer[i].devicesku.length);
		
			for(var k=0;k<accyAssociationContainer[i].devicesku.length; k++){
				//console.log(accyAssociationContainer[i].devicesku[k].sku);
			myNewData = {
					"priority": 'NA',
					 "deviceId": accyAssociationContainer[i].devicesku[k].sku,
                     "upfront": paygPriceCollection[j].upfront,
                     "pid": paygPriceCollection[j].pid,
                     "additionalR": paygPriceCollection[j].additionalR,
                     "secondaryR": paygPriceCollection[j].secondaryR,
                     "primary": paygPriceCollection[j].primary,
                     "included": [ paygPriceCollection[j]['included'][0],paygPriceCollection[j]['included'][1],paygPriceCollection[j]['included'][2]]
};
		finalCollection.push(myNewData)
			
		}
		
		//console.log(myNewData.included);
		}
		else{
			if(newDevices.indexOf(paygPriceCollection[j].deviceId)<=-1)
			newDevices.push(paygPriceCollection[j].deviceId);
		}
	}
}
console.log(newDevices);



    var wb = new excelbuilder.WorkBook();
    var wbOpts = {
        jszip:{
            compression:'DEFLATE'
        }
    }
    var wb2 = new excelbuilder.WorkBook(wbOpts);
    var ws = wb.WorkSheet('New Worksheet');
    var wsOpts = {
        margins:{
            left : .75,
            right : .75,
            top : 1.0,
            bottom : 1.0,
            footer : .5,
            header : .5
        },
        printOptions:{
            centerHorizontal : true,
            centerVertical : false
        },
        view:{
            zoom : 100
        },
        outline:{
            summaryBelow : true
        }
    }
    var ws2 = wb.WorkSheet('Sheet1', wsOpts);
    ws.Cell(1,1).String('Priority');
    ws.Cell(1,2).String('deviceId/SKU');
    ws.Cell(1,3).String('Data');
    ws.Cell(1,4).String('Upfront Cost');
    ws.Cell(1,5).String('Additional Ribbon');
    ws.Cell(1,6).String('Secondary ribbon');
    ws.Cell(1,7).String('Roundel');
    ws.Cell(1,8).String('Included');
    for(var skuCountLength = 0;skuCountLength < finalCollection.length;skuCountLength++){
        var row = skuCountLength + 2;
        ws.Cell(row,1).String(finalCollection[skuCountLength]["priority"]);
        ws.Cell(row,2).String(finalCollection[skuCountLength]["deviceId"]);
        ws.Cell(row,3).String(finalCollection[skuCountLength]["pid"]);
        ws.Cell(row,4).Number(finalCollection[skuCountLength]["upfront"]);
        ws.Cell(row,5).String(finalCollection[skuCountLength]["additionalR"]);
        ws.Cell(row,6).String(finalCollection[skuCountLength]["secondaryR"]);
        ws.Cell(row,7).String(finalCollection[skuCountLength]["primary"]);
        ws.Cell(row,8).String(finalCollection[skuCountLength]["included"][0]);
        ws.Cell(row,9).String(finalCollection[skuCountLength]["included"][1]);
        ws.Cell(row,10).String(finalCollection[skuCountLength]["included"][2]);
		//console.log(finalCollection[skuCountLength]["included"]);
        

    }
    var myStyle = wb.Style();
    myStyle.Font.Bold();
    myStyle.Font.Italics();
    myStyle.Font.Family('Times New Roman');
    myStyle.Font.Color('FF0000');
    myStyle.Fill.Color('CCCCCC');
    ws.Cell(1,1).Style(myStyle);
    ws.Cell(1,2).Style(myStyle);
    ws.Cell(1,3).Style(myStyle);
    ws.Cell(1,4).Style(myStyle);
    ws.Cell(1,5).Style(myStyle);
    ws.Cell(1,6).Style(myStyle);
    ws.Cell(1,7).Style(myStyle);
    ws.Cell(1,8).Style(myStyle);
    wb.write("ExcelOutput/NewTariffAutomationSheet_04_08_2017.xlsx",function(err){
        //console.log("done");
    });
       
}

generateExcelFile();