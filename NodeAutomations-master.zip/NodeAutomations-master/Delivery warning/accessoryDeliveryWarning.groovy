import groovy.io.FileType
import groovy.json.JsonOutput
import groovy.json.JsonSlurper

/**
 * Script to modify stockInfo, input is read from CSV file. format of CSV is sku, statusToBeChanged, duration, subtype (phone, tab etc.)
 * Sample CSV content:
 *AKOA3FBN",InStock,upto 2 to 3 weeks
 *AKOA5SVN",InStock,upto 2 days
 *ADEHALBN",InStock,upto 2 days,Active

 "deliveryMessage" : "Your Samsung Galaxy A3 Flip Wallet Cover Gold may take up to 1 week",
 */

def pathToCSV = "D:/NodeAutomations-master/NodeAutomations-master/Delivery warning/accessoryStockInfo.csv"

new File(pathToCSV).splitEachLine(",") { fields ->
    processStockInfo(fields[0].trim(), fields[1].trim(), fields[2].trim(), fields[3]?.trim())
}

def processStockInfo(String sku, String changeStatusTo, String stockMessage, String active) {
    def accessories = "D:/IdeaProjects/productCatalogueData_Master2/catalogueData/accessories"
    def deliveryMessage = "Your <model> may take <duration>."
    def files = []

    def dir = new File(accessories)

    dir.eachFileRecurse (FileType.FILES) { file ->
        if (file.name.endsWith('.json')) {
            files << file
        }
    }

    files.each {
        String buffer = new File(it.path).getText()
        def skuCode = buffer.find(/code.*\"/)

        if(skuCode != null && skuCode.contains(sku)) {
            //println "sku found"
            def model = buffer.find(/model.*\"/).replace("model", "")
            model = model.replace("\n", "").find(/[A-Za-z0-9\.\-\&]+(\s*[A-Za-z0-9\.\-\&]*)*/)


            if (buffer.indexOf("OutOfStock")) {
                buffer = buffer.replace("OutOfStock", "InStock")
                if (active) {
                    buffer = buffer.replace("EndOfLife", "Active")

                    def channelPermission = buffer.find(/(?s)[\"\']channelPermissions.*?\}/)
                    channelPermission = channelPermission.substring(channelPermission.indexOf('{'), channelPermission.indexOf('}') + 1)
                    def object = new JsonSlurper().parseText(channelPermission)
                    object.ConsumerNew = "Buyable"
                    object.ConsumerUpgrade = "Buyable"
                    object.VoiceNew = "Buyable"
                    object.VoiceUpgrade = "Buyable"

                    object = "\"channelPermissions\": {\n" +
                            "    \"ConsumerNew\": \"Buyable\",\n" +
                            "    \"ConsumerUpgrade\": \"Buyable\",\n" +
                            "    \"VoiceNew\": \"Buyable\",\n" +
                            "    \"VoiceUpgrade\": \"Buyable\"\n" +
                            "  }"
                    buffer = buffer.replaceFirst(/(?s)[\"\']channelPermissions.*?\}/, object)
                }
            }

            deliveryMessage = deliveryMessage.replace("<model>", model).replace("<duration>", stockMessage)
            if (buffer.indexOf("deliveryMessage\"") < 0) {
                buffer = buffer.replace("InStock\"", "InStock\",\n  \"deliveryMessage\": \"$deliveryMessage\"")
            } else {
              //  println buffer.find("deliveryMessage.*\"")
                buffer = buffer.replaceFirst("deliveryMessage.*\"", "deliveryMessage\": \"$deliveryMessage\"")
            }

            new File(it.path).write(buffer)
            return
        }
    }
}
