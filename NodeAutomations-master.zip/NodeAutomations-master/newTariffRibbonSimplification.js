var fs = require('fs');

var excelbuilder = require('excel4node');

require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir'),XLSX = require('xlsx');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

var deviceDetailsCol = [],payMonthlyPriceCollection = [], payGPriceCollection = [],mapDeviceCollection = [];
var urlDictonaryPriceValidation = "D:/NodeAutomations-master/NodeAutomations-master/ExcelOutput/MerchTariffSheet.xlsx";
var urlDictonaryPriceValidation2 = "D:/NodeAutomations-master/NodeAutomations-master/ExcelOutput/deviceNameList.xlsx";
var make='A',model='B',condition='C',costToO2='D',pgPrice='E',pmPrice='F', payGTab_Min_Count =2,payGTab_Max_Count = 154;

function loadAccyAssociations(){
    try{
        var workbook = XLSX.readFile(urlDictonaryPriceValidation2);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading Accy Comp Sheet...");
        sheet_name_list.forEach(function(sheetName) {
          if( sheetName === "Sheet1"){
              var worksheet = workbook.Sheets[sheetName];
              var accy_Sheet_SKU_Count = 1;
              for (currentSheet in worksheet) {
                  if(currentSheet[0] === '!') continue;
                  if(currentSheet[0] === 'A'){
                     var currentAccyAssociationMatrix = {
                         "accysku": worksheet[currentSheet].v,
                         "devicesku" :[]
                     }
                     accyAssociationContainer.push(currentAccyAssociationMatrix);
                  }
              }
              //console.log(accyAssociationContainer);
          }
              
       });
  }
  catch(e){
       // console.log("Oops.......");
       // console.log("Something is wrong with Accys Association Price sheet");
        //console.log(e);
  }
}

var priorityCell = 'A'
	deviceIdCell = 'B',
	pidCell = 'C',
	upfrontCell = 'D',
	additionalRCell = 'E',
	secondaryRCell = 'F',
	primaryCell = 'G',
	includedCell1 = 'H',
	includedCell2 = 'I',
	includedCell3 = 'J',
	payGTab_Min_Count = 2,payGTab_Max_Count = 69;
	
	function merchTariffSheetMaping(){
    try{
        cashPriceCollection = [], devicePriceCollection = [];
        var workbook = XLSX.readFile(merchPricesSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading merchandising Pricing Sheet...");
        console.log(sheet_name_list);
        
        sheet_name_list.forEach(function(y) {
            
         if( y === "Sheet1"){
			 
          var worksheet = workbook.Sheets[y];
          for (z in worksheet) {
			  
              if(payGTab_Min_Count <= payGTab_Max_Count){
                  if(z[0] === '!') continue;
                  var priority = priorityCell+payGTab_Min_Count;
                  var deviceId = deviceIdCell+payGTab_Min_Count;
                  var upfront = upfrontCell+payGTab_Min_Count;
                  var pid = pidCell+payGTab_Min_Count;
                  var additionalR = additionalRCell+payGTab_Min_Count;
                  var secondaryR = secondaryRCell+payGTab_Min_Count;
                  var primary = primaryCell+payGTab_Min_Count;
                  var included1 = includedCell1+payGTab_Min_Count;
                  var included2 = includedCell2+payGTab_Min_Count;
                  var included3 = includedCell3+payGTab_Min_Count;
                  
			
				
                  var priceDeatils = {
                     "priority": worksheet[priority].v,
					 "deviceId": worksheet[deviceId].v,
                     "upfront": worksheet[upfront].v,
                     "pid": worksheet[pid].v,
                     "additionalR": worksheet[additionalR].v,
                     "secondaryR": worksheet[secondaryR].v,
                     "primary": worksheet[primary].v,
                     "included": [ worksheet[included1].v,worksheet[included2].v,worksheet[included3].v]
					 }
                  devicePriceCollection.push(priceDeatils);
                 // console.log(devicePriceCollection);
                  payGTab_Min_Count++;  
				  
             }
          }
         }
       });
  }
  catch(e){
        //console.log("Oops.......");
        //console.log("Something is wrong with Merch Price sheet");
        //console.log(e);
  }
}



function merchPriceSheetMaping(payGPriceCollection){
    try{
		loadAccyAssociations();
        var workbook = XLSX.readFile(urlDictonaryPriceValidation);
        var sheet_name_list = workbook.SheetNames;
		var checkArr=[];
        /* console.log("Loading merchandising Pricing Sheet...");
        console.log(sheet_name_list); */
        
        sheet_name_list.forEach(function(y) {
            
         if( y === "Sheet1"){
			   
          var worksheet = workbook.Sheets[y];
		  
          for (z in worksheet) {
			 
              if(payGTab_Min_Count <= payGTab_Max_Count){
                  if(z[0] === '!') continue;

                  var Make = make+payGTab_Min_Count;
                  var Model = model+payGTab_Min_Count;
                  var Condition = condition+payGTab_Min_Count;
                  var CostToO2 = costToO2+payGTab_Min_Count;
                  var PgPrice = pgPrice+payGTab_Min_Count;
                  var PmPrice = pmPrice+payGTab_Min_Count;
				
                  var myDeviceDeatils = {
                     "make": worksheet[Make].v+"",
					 "model": worksheet[Model].v+"",
                     "condition": worksheet[Condition].v+"",
                     "costToO2": worksheet[CostToO2].v,
                     "pgPrice": worksheet[PgPrice].v,
                     "pmPrice": worksheet[PmPrice].v,
					 "realDeviceModelFamily" : [],
					 "costToO2R" : [],
					 "pgPriceR":[],
					 "pmPriceR":[]
                     
					 }
                  mapDeviceCollection.push(myDeviceDeatils);
                 //console.log(mapDeviceCollection);
                  payGTab_Min_Count++;  
				  
             }
          }
         }
       }
	   );
	   
		   var patt = new RegExp("GB");
		   
		   for(var i=0; i<mapDeviceCollection.length; i++){
			   
			   
			   var compArr = mapDeviceCollection[i]["model"].split(" ");
			   var checkModel="",checkModelArr=[];
						checkModelArr = mapDeviceCollection[i]["model"].split(" ");
					     if(patt.test(mapDeviceCollection[i]["model"]))
						{ 
							checkModelArr.length = (checkModelArr.length-1>0) ? checkModelArr.length-1 : checkModelArr.length;
						}
						else{
							checkModelArr.length = checkModelArr.length;
						} 
						checkModel = checkModelArr.join(" ");
						var patt2 = new RegExp(checkModel);
			   
			   //console.log(compArr);
			 
for(var j=0; j<payMonthlyPriceCollection.length; j++){ 
	  if(checkModel.toLowerCase()==payMonthlyPriceCollection[j]["modelfamly"].toLowerCase() && (mapDeviceCollection[i]["condition"]=="New"))
	  {
		   //console.log(checkModel+ "  => "+payMonthlyPriceCollection[j]["modelfamly"]);
		  if(patt.test(payMonthlyPriceCollection[j]["model"])&& patt.test(mapDeviceCollection[i]["model"])){
		   for(key in compArr){
			   //console.log(compArr[key]);
				   if(patt.test(compArr[key])){
						
								var sizePointer = compArr[key];
								sizePointer = new RegExp(sizePointer);
								if(sizePointer.test(payMonthlyPriceCollection[j]["model"]))
								{
									//console.log(sizePointer+" => "+payMonthlyPriceCollection[j]["model"])
							if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
									{
										mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
										 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
										//console.log(payMonthlyPriceCollection[j]["costToO2"]+"  "+payMonthlyPriceCollection[j]["payGo"]+"  "+payMonthlyPriceCollection[j]["payMonthly"]);
									}
								}
						}
					   
		   } 
		   }
		   else if(patt.test(payMonthlyPriceCollection[j]["model"]) && !patt.test(mapDeviceCollection[i]["model"])) {
			var proArr = payMonthlyPriceCollection[j]["model"].slice();
					 for(key in proArr){
						if(patt.test(proArr[key])){
					   
								var sizePointer = proArr[key];
								sizePointer = new RegExp(sizePointer);
								if(sizePointer.test(payMonthlyPriceCollection[j]["model"]))
								{
						if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
						{
							mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
							 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
						} 
						}
						}
					 }
					 }
			   
			   
			 else if(!patt.test(payMonthlyPriceCollection[j]["model"]) && !patt.test(mapDeviceCollection[i]["model"])) {
						if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
						{
							mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
							 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
						} 
					}
			   
	  }     
			   
			   
		 else if((checkModel+" Like New").toLowerCase()==payMonthlyPriceCollection[j]["modelfamly"].toLowerCase() &&(mapDeviceCollection[i]["condition"]=="Grade A"))
			{
			if(patt.test(payMonthlyPriceCollection[j]["model"])&& patt.test(mapDeviceCollection[i]["model"]) ){
				 for(key in compArr){
			   // console.log(compArr[key]);
				   if(patt.test(compArr[key])){
					   
								var sizePointer = compArr[key];
								sizePointer = new RegExp(sizePointer);
								var perfect = new RegExp("Perfect Like New");
								var almostNot = new RegExp("Almost");
								
								if(sizePointer.test(payMonthlyPriceCollection[j]["model"]) && perfect.test(payMonthlyPriceCollection[j]["model"]) && !almostNot.test(payMonthlyPriceCollection[j]["model"]))
								{
							if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
									{
										mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
										 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
										// console.log(mapDeviceCollection[i]["realDeviceModelFamily"]);
									}
								}
						}
					
			
			}
			
			}
			   else if(patt.test(payMonthlyPriceCollection[j]["model"]) && !patt.test(mapDeviceCollection[i]["model"])) {
					 var proArr = payMonthlyPriceCollection[j]["model"].slice();
					 for(key in proArr){
						if(patt.test(proArr[key])){
					   
								var sizePointer = proArr[key];
								sizePointer = new RegExp(sizePointer);
								var perfect = new RegExp("Perfect Like New");
								var almostNot = new RegExp("Almost");
								
								if(sizePointer.test(payMonthlyPriceCollection[j]["model"]) && perfect.test(payMonthlyPriceCollection[j]["model"]) && !almostNot.test(payMonthlyPriceCollection[j]["model"]))
								{
							if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
									{
										mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
										 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
										// console.log(mapDeviceCollection[i]["realDeviceModelFamily"]);
									}
								}
						}
			
			}
					}
			   
			   
			 else if(!patt.test(payMonthlyPriceCollection[j]["model"]) && !patt.test(mapDeviceCollection[i]["model"])) {
						if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
						{
							mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
							 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
						} 
					}
			
			}
			else if((checkModel+" Like New").toLowerCase()==payMonthlyPriceCollection[j]["modelfamly"].toLowerCase() &&(mapDeviceCollection[i]["condition"]=="Grade B"))
			{
				 if(patt.test(payMonthlyPriceCollection[j]["model"])&& patt.test(mapDeviceCollection[i]["model"]) ){
				   for(key in compArr){
			   // console.log(compArr[key]);
				   if(patt.test(compArr[key])){
					   
								var sizePointer = compArr[key];
								sizePointer = new RegExp(sizePointer);
								var almost = new RegExp("Almost Perfect Like New");
								
								if(sizePointer.test(payMonthlyPriceCollection[j]["model"]) && almost.test(payMonthlyPriceCollection[j]["model"]))
								{
							if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
									{
										mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
										 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
										// console.log(mapDeviceCollection[i]["realDeviceModelFamily"]);
									}
								}
						}
					
			
			}
			}
			else if(patt.test(payMonthlyPriceCollection[j]["model"]) && !patt.test(mapDeviceCollection[i]["model"])) {
				 var proArr = payMonthlyPriceCollection[j]["model"].slice();
					 for(key in proArr){
						if(patt.test(proArr[key])){
					   
								var sizePointer = proArr[key];
								sizePointer = new RegExp(sizePointer);
								var almost = new RegExp("Almost Perfect Like New");
								
								if(sizePointer.test(payMonthlyPriceCollection[j]["model"]) && almost.test(payMonthlyPriceCollection[j]["model"]))
								{
							if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
									{
										mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
										 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
										// console.log(mapDeviceCollection[i]["realDeviceModelFamily"]);
									}
								}
						}
					}
					}
			   
			   
			 else if(!patt.test(payMonthlyPriceCollection[j]["model"]) && !patt.test(mapDeviceCollection[i]["model"])) {
						if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
						{
							mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
							 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
						} 
					}
			}
			else if((checkModel+" Like New").toLowerCase() ==payMonthlyPriceCollection[j]["modelfamly"].toLowerCase() &&(mapDeviceCollection[i]["condition"]=="Grade C"))
			{
				if(patt.test(payMonthlyPriceCollection[j]["model"])&& patt.test(mapDeviceCollection[i]["model"]) ){
						
				  for(key in compArr){
			   // console.log(compArr[key]);
				   if(patt.test(compArr[key])){
					   
								var sizePointer = compArr[key];
								sizePointer = new RegExp(sizePointer);
								var perfectly = new RegExp("Perfectly Fine Like New");
								
								if(sizePointer.test(payMonthlyPriceCollection[j]["model"]) && perfectly.test(payMonthlyPriceCollection[j]["model"]))
								{
							if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
									{
										mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
										 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
										// console.log(compArr[key]+" => "+mapDeviceCollection[i]["realDeviceModelFamily"]);
									}
								}
						}
								
			}
			}
			else if(patt.test(payMonthlyPriceCollection[j]["model"]) && !patt.test(mapDeviceCollection[i]["model"])) {
				 var proArr = payMonthlyPriceCollection[j]["model"].slice();
					 for(key in proArr){
						if(patt.test(proArr[key])){
					   
								var sizePointer = proArr[key];
								sizePointer = new RegExp(sizePointer);
								var perfectly = new RegExp("Perfectly Fine Like New");
								
								if(sizePointer.test(payMonthlyPriceCollection[j]["model"]) && perfectly.test(payMonthlyPriceCollection[j]["model"]))
								{
							if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
									{
										mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
										 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
										// console.log(compArr[key]+" => "+mapDeviceCollection[i]["realDeviceModelFamily"]);
									}
								}
						}
					}
					}
			   
			   
			 else if(!patt.test(payMonthlyPriceCollection[j]["model"]) && !patt.test(mapDeviceCollection[i]["model"])) {
						if((mapDeviceCollection[i]["realDeviceModelFamily"].indexOf(payMonthlyPriceCollection[j]["model"])<=-1))
						{
							mapDeviceCollection[i]["realDeviceModelFamily"].push(payMonthlyPriceCollection[j]["model"]);
							 mapDeviceCollection[i]["costToO2R"].push(payMonthlyPriceCollection[j]["costToO2"]);
										mapDeviceCollection[i]["pgPriceR"].push(payMonthlyPriceCollection[j]["payGo"]);
										mapDeviceCollection[i]["pmPriceR"].push(payMonthlyPriceCollection[j]["payMonthly"]);
						} 
					}
			} 
}	
		   
			   
		
		   
		   
	   }
	   //console.log(checkArr);
  }
  catch(e){
        console.log("Oops.......");
        console.log("Something is wrong with Merch Price sheet");
        console.log(e);
  }
}
    
 recursive('D:/IdeaProjects/productCatalogueData_Master2/catalogueData/device/', function (err, files) {
    var jsonFileCount = 0, jsonFilesIndex = 0;
    var json;
    console.log("Reading JSON files.....");
    var jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
    deviceDetailsCol =[];
    jsonFiles.forEach(function(file) {
        var content =  require(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        readdeviceDetails(json);
		merchPriceSheetMaping(payMonthlyPriceCollection,payGPriceCollection);
      if(jsonFiles.length === jsonFilesIndex){
           generateExcelFile(payMonthlyPriceCollection,payGPriceCollection)
        } 
		
 });
 
 });

function readdeviceDetails(deviceJSON){
    if(deviceJSON["cashPrice"]) {
        var payMPriceObj = {
                       "sku": deviceJSON["sku"]["code"],
                       "name": deviceJSON["ccaProductInformation"],
                       "model": deviceJSON["model"],
                        "modelfamly": deviceJSON["modelFamily"],
					   "costToO2": deviceJSON["costToO2"],
                       "payMonthly": deviceJSON["cashPrice"],
					   "payGo": deviceJSON["replacementCost"]
                       
        };

        payMonthlyPriceCollection.push(payMPriceObj);
		
    }
   
    if(deviceJSON["replacementCost"]){
        var payGPriceObj = {
                       "sku": deviceJSON["sku"]["code"],
                       "name": deviceJSON["ccaProductInformation"],
                       "model": deviceJSON["model"],
                       "modelfamly": deviceJSON["modelFamily"],
   					   "costToO2": deviceJSON["costToO2"],
                       "payGo": deviceJSON["replacementCost"]
					  
        };
	

        payGPriceCollection.push(payGPriceObj);
    }
	
	
	
}

function generateExcelFile(payMCollection,payGCollection){
    var wb = new excelbuilder.WorkBook();
    var wbOpts = {
        jszip:{
            compression:'DEFLATE'
        }
    }
    var wb2 = new excelbuilder.WorkBook(wbOpts);
    var ws = wb.WorkSheet('PayM');
    var wsOpts = {
        margins:{
            left : .75,
            right : .75,
            top : 1.0,
            bottom : 1.0,
            footer : .5,
            header : .5
        },
        printOptions:{
            centerHorizontal : true,
            centerVertical : false
        },
        view:{
            zoom : 100
        },
        outline:{
            summaryBelow : true
        }
    }
	var flagCondition="false";
    var ws2 = wb.WorkSheet('PayG', wsOpts);
    ws.Cell(1,1).String('SKU');
    ws.Cell(1,2).String('Model');
    ws.Cell(1,3).String('Name');
	ws.Cell(1,4).String('price');
	var dyStyle = wb.Style();
    for(var skuCountLength = 0;skuCountLength < mapDeviceCollection.length;skuCountLength++){
        var row = skuCountLength + 2;
        ws.Cell(row,1).String(mapDeviceCollection[skuCountLength]["make"]);
        ws.Cell(row,2).String(mapDeviceCollection[skuCountLength]["model"]);
        ws.Cell(row,3).String(mapDeviceCollection[skuCountLength]["condition"]);
        ws.Cell(row,4).Number(mapDeviceCollection[skuCountLength]["costToO2"]);
        ws.Cell(row,5).Number(mapDeviceCollection[skuCountLength]["pgPrice"]);
        ws.Cell(row,6).Number(mapDeviceCollection[skuCountLength]["pmPrice"]);
		
		
		
    for(var key=0; key < mapDeviceCollection[skuCountLength]["realDeviceModelFamily"].length; key++){
		if((mapDeviceCollection[skuCountLength]["costToO2"]==mapDeviceCollection[skuCountLength]["costToO2R"][key]) && (mapDeviceCollection[skuCountLength]["pgPriceR"][key]==mapDeviceCollection[skuCountLength]["pgPrice"]) && (mapDeviceCollection[skuCountLength]["pmPriceR"][key]==mapDeviceCollection[skuCountLength]["pmPrice"]))
		{
		flagCondition = "All True";
		dyStyle.Font.Color('008000');
		ws.Cell(row,key+7).String(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"~"+mapDeviceCollection[skuCountLength]["costToO2R"][key]+"~"+mapDeviceCollection[skuCountLength]["pgPriceR"][key]+"~"+mapDeviceCollection[skuCountLength]["pmPriceR"][key]+"~"+flagCondition).Style(dyStyle);
		}
		else if((mapDeviceCollection[skuCountLength]["costToO2"]==mapDeviceCollection[skuCountLength]["costToO2R"][key]) && (mapDeviceCollection[skuCountLength]["pgPriceR"][key]==mapDeviceCollection[skuCountLength]["pgPrice"]) && (mapDeviceCollection[skuCountLength]["pmPriceR"][key]!=mapDeviceCollection[skuCountLength]["pmPrice"]))
		{
		dyStyle.Font.Color('CCCC00');
		flagCondition = "costToO2 & pgPrice True";	
		ws.Cell(row,key+7).String(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"~"+mapDeviceCollection[skuCountLength]["costToO2R"][key]+"~"+mapDeviceCollection[skuCountLength]["pgPriceR"][key]+"~"+mapDeviceCollection[skuCountLength]["pmPriceR"][key]+"~"+flagCondition).Style(dyStyle);
		}
		else if((mapDeviceCollection[skuCountLength]["costToO2"]!=mapDeviceCollection[skuCountLength]["costToO2R"][key]) && (mapDeviceCollection[skuCountLength]["pgPriceR"][key]==mapDeviceCollection[skuCountLength]["pgPrice"]) && (mapDeviceCollection[skuCountLength]["pmPriceR"][key]==mapDeviceCollection[skuCountLength]["pmPrice"]))
		{
		dyStyle.Font.Color('0000ff');	
		flagCondition = "pmPrice & pgPrice True";	
		ws.Cell(row,key+7).String(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"~"+mapDeviceCollection[skuCountLength]["costToO2R"][key]+"~"+mapDeviceCollection[skuCountLength]["pgPriceR"][key]+"~"+mapDeviceCollection[skuCountLength]["pmPriceR"][key]+"~"+flagCondition).Style(dyStyle);
		}
		else if((mapDeviceCollection[skuCountLength]["costToO2"]==mapDeviceCollection[skuCountLength]["costToO2R"][key]) && (mapDeviceCollection[skuCountLength]["pgPriceR"][key]!=mapDeviceCollection[skuCountLength]["pgPrice"]) && (mapDeviceCollection[skuCountLength]["pmPriceR"][key]==mapDeviceCollection[skuCountLength]["pmPrice"]))
		{
			dyStyle.Font.Color('FFA500');
		flagCondition = "costToO2 & pmPrice True";	
		ws.Cell(row,key+7).String(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"~"+mapDeviceCollection[skuCountLength]["costToO2R"][key]+"~"+mapDeviceCollection[skuCountLength]["pgPriceR"][key]+"~"+mapDeviceCollection[skuCountLength]["pmPriceR"][key]+"~"+flagCondition).Style(dyStyle);
		}
		else if((mapDeviceCollection[skuCountLength]["costToO2"]==mapDeviceCollection[skuCountLength]["costToO2R"][key]) && (mapDeviceCollection[skuCountLength]["pgPriceR"][key]!=mapDeviceCollection[skuCountLength]["pgPrice"]) && (mapDeviceCollection[skuCountLength]["pmPriceR"][key]!=mapDeviceCollection[skuCountLength]["pmPrice"]))
		{
			dyStyle.Font.Color('FFD700');
		flagCondition = "costToO2 True";	
		ws.Cell(row,key+7).String(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"~"+mapDeviceCollection[skuCountLength]["costToO2R"][key]+"~"+mapDeviceCollection[skuCountLength]["pgPriceR"][key]+"~"+mapDeviceCollection[skuCountLength]["pmPriceR"][key]+"~"+flagCondition).Style(dyStyle);
		}
		else if((mapDeviceCollection[skuCountLength]["costToO2"]!=mapDeviceCollection[skuCountLength]["costToO2R"][key]) && (mapDeviceCollection[skuCountLength]["pgPriceR"][key]==mapDeviceCollection[skuCountLength]["pgPrice"]) && (mapDeviceCollection[skuCountLength]["pmPriceR"][key]!=mapDeviceCollection[skuCountLength]["pmPrice"]))
		{
			dyStyle.Font.Color('FF8C00');
		flagCondition = "pgPrice True";	
		ws.Cell(row,key+7).String(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"~"+mapDeviceCollection[skuCountLength]["costToO2R"][key]+"~"+mapDeviceCollection[skuCountLength]["pgPriceR"][key]+"~"+mapDeviceCollection[skuCountLength]["pmPriceR"][key]+"~"+flagCondition).Style(dyStyle);
		}
		else if((mapDeviceCollection[skuCountLength]["costToO2"]!=mapDeviceCollection[skuCountLength]["costToO2R"][key]) && (mapDeviceCollection[skuCountLength]["pgPriceR"][key]!=mapDeviceCollection[skuCountLength]["pgPrice"]) && (mapDeviceCollection[skuCountLength]["pmPriceR"][key]==mapDeviceCollection[skuCountLength]["pmPrice"]))
		{
			dyStyle.Font.Color('808080');
		flagCondition = "pmPrice True";	
		ws.Cell(row,key+7).String(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"~"+mapDeviceCollection[skuCountLength]["costToO2R"][key]+"~"+mapDeviceCollection[skuCountLength]["pgPriceR"][key]+"~"+mapDeviceCollection[skuCountLength]["pmPriceR"][key]+"~"+flagCondition).Style(dyStyle);
		}
		else{
			flagCondition = "false";
			dyStyle.Font.Color('ff0000');
			ws.Cell(row,key+7).String(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"~"+mapDeviceCollection[skuCountLength]["costToO2R"][key]+"~"+mapDeviceCollection[skuCountLength]["pgPriceR"][key]+"~"+mapDeviceCollection[skuCountLength]["pmPriceR"][key]+"~"+flagCondition).Style(dyStyle);
		}
		
		//console.log(mapDeviceCollection[skuCountLength]["realDeviceModelFamily"][key]+"  "+mapDeviceCollection[skuCountLength]["pmPriceR"][key]);
		
		}
    }
    
    for(var skuCountLength = 0;skuCountLength < payGCollection.length;skuCountLength++){
        var row = skuCountLength + 2;
        ws2.Cell(row,1).String(payGCollection[skuCountLength]["sku"]);
        ws2.Cell(row,2).String(payGCollection[skuCountLength]["model"]);
        ws2.Cell(row,3).String(payGCollection[skuCountLength]["name"]);
        ws2.Cell(row,4).String(payGCollection[skuCountLength]["payGo"]);
		ws2.Cell(row,5).String(payGCollection[skuCountLength]["costToO2"]);
		ws2.Cell(row,6).String(payGCollection[skuCountLength]["modelfamly"]);
    }
    
    ws.Row(1).Height(30);
    ws.Column(1).Width(50);
    var myStyle = wb.Style();
    myStyle.Font.Bold();
    myStyle.Font.Italics();
    myStyle.Font.Family('Times New Roman');
    myStyle.Font.Color('FF0000');
    myStyle.Fill.Color('CCCCCC');
    ws.Cell(1,1).Style(myStyle);
    ws.Cell(1,2).Style(myStyle);
	ws.Cell(1,3).Style(myStyle);
	ws.Cell(1,4).Style(myStyle);
    wb.write("ExcelOutput/KuldeepTest.xlsx",function(err){
        console.log("done");
    });
        
}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
        modifiedFileCount++;
        console.log("Modified Files"+modifiedFileCount);
        
    }
});
     
}


function convertBacktoOriginalState(newContent,file,newPathsContainer){
    var originalState;
    
    newContent = beautify(newContent, { indent_size: 3 });
    for(var jCount =0;jCount<newPathsContainer.length;jCount++){
               var oldPathValue = '"'+newPathsContainer[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(oldPathValue),"g");
               newContent = newContent.replace(regExpCheck,newPathsContainer[jCount]);
    }
    writeToFile(file,newContent);  
    
}
