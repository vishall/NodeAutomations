var beautify = require('js-beautify');
var fs = require('fs');
//var prettyjson = require('prettyjson');
var options = {
  noColor: true
};

    merchPricesSheetURL = 'D:/NodeAutomations-master/NodeAutomations-master/ExcelOutput/pgpricechange.xlsx',
    payGSKUCellColumn = 'A',payGPriceCellColumn = 'B',
    payGTab_Min_Count = 2,payGTab_Max_Count = 4;
    
    var XLSX = require('xlsx'),excelbuilder = require('excel4node');






    var tariffUpsell = "D:/IdeaProjects/productCatalogueData_Master2/catalogueData/media/attachments/common/tariffUpsell.txt";
    
    fs.readFile(tariffUpsell, 'utf8', function (err,data) {
      if (err) {
        return console.log(err);
      }
        
        
        
        data = JSON.parse(data);
        var objectLen = Object.keys(data).length;
        
        
        for (var x in data) {
            for (var y in data[x].tariffRows){
            
            if(data[x]["tariffRows"][y].hasOwnProperty('promotionAttachmentId')){
                    delete data[x]["tariffRows"][y].promotionAttachmentId;
            }
                
            
            }
        }
        data=JSON.stringify(data);
        console.log(data);
       data = beautify(data, { indent_size: 2 }); 
       writeToFile(tariffUpsell,data); 
           
    });




function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
       
        console.log("Modified File");
        
    }
});
     
}
