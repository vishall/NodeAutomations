var beautify = require('js-beautify');
var fs = require('fs');
var prettyjson = require('prettyjson');
var options = {
  noColor: true
};

    merchPricesSheetURL = 'C:/NodeAutomations/ExcelOutput/costToO2.xlsx',
    costToO2SKUCellColumn = 'A',costToO2CopyCellColumn = 'B',
    costToO2Tab_Min_Count = 2,costToO2Tab_Max_Count = 482;
    
    var XLSX = require('xlsx'),excelbuilder = require('excel4node');


function loadSKUcostToO2(){
    try{
        costToO2Collection = [];
        var workbook = XLSX.readFile(merchPricesSheetURL);
        var sheet_name_list = workbook.SheetNames;
        console.log("Loading merchandising costToO2 Sheet...");
        console.log(sheet_name_list);
        
        sheet_name_list.forEach(function(y) {
            
         if( y === "costToO2"){
			 
          var worksheet = workbook.Sheets[y];
          for (z in worksheet) {
			  
              if(costToO2Tab_Min_Count <= costToO2Tab_Max_Count){
                  if(z[0] === '!') continue;
                  var skuCell = costToO2SKUCellColumn+costToO2Tab_Min_Count;
                  var costToO2CopyCell = costToO2CopyCellColumn+costToO2Tab_Min_Count;
                  var costToO2Details = {
                     "sku": worksheet[skuCell].v,
                     "costToO2": worksheet[costToO2CopyCell].v
					 
                  }
                  costToO2Collection.push(costToO2Details);
                  //console.log(costToO2Collection);
                  costToO2Tab_Min_Count++; 
             }
          }
         }
       });
  }
  catch(e){
        console.log("Oops.......");
        console.log("Something is wrong with Merch costToO2 Sheet");
        console.log(e);
  }
}




require.extensions['.json'] = function (module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};

var recursive = require('recursive-readdir');

var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

var deviceDetailsCol = [], modifiedFileCount =0;

recursive('C:/Idea/productCatalogueData_Master/catalogueData/device/', function (err, files) {
    
    var jsonFileCount = 0, jsonFilesIndex = 0;
    var json;
    console.log(files.length);
    var jsonFiles = files.filter(function(file) {jsonFileCount++; return file.substr(-5) === '.json'; });
    deviceDetailsCol =[];
    loadSKUcostToO2();
    jsonFiles.forEach(function(file) {
        var content =  require(file);
        //console.log(file);
        var newContent = content;
        var newSearch = newContent.match(pathRegExp);
        var newPathsContainer = [];
        if(newSearch != null){
            var uniqueArray = newSearch.filter(function(elem, pos) {
                return newSearch.indexOf(elem) == pos;
            }); 
            for(var jCount =0;jCount<uniqueArray.length;jCount++){ 
               var newPathValue = '"'+uniqueArray[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]),"g");
               newPathsContainer.push(uniqueArray[jCount]);
               newContent = newContent.replace(regExpCheck,newPathValue);
               var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'),"g");
            }
            json = JSON.parse(newContent);
        }
        else{
            json = JSON.parse(newContent);
        }
        jsonFilesIndex++;
        //if(json["id"] == "8281864e-faf7-4d28-86d1-5346b64f1c7cdvsd")
        addCnCFlag(json,file,newPathsContainer);
        
    });
});

function addCnCFlag(json,file,newPathsContainer){
    var sku = json["sku"]["code"];

//check the sku id to change costToO2
   for(key in costToO2Collection){
    if(sku == costToO2Collection[key].sku){
         json["costToO2"]=""+costToO2Collection[key].costToO2;
		 //console.log(file);
           var fileNewContent = JSON.stringify(json);
    convertBacktoOriginalState(fileNewContent,file,newPathsContainer);
        

    }
   
   }
}


function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}

function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
        modifiedFileCount++;
        
        //console.log("Modified Files"+modifiedFileCount);
        fs.appendFile("ExcelOutput/log.txt",file+ "\r\n", function(err) {
                if(err) {
                    return console.log(err);
                }
				else{
					
				}
            }); 
    }
	
});
     
}


function convertBacktoOriginalState(newContent,file,newPathsContainer){
    var originalState;
    
    newContent = beautify(newContent, { indent_size: 2 });
    for(var jCount =0;jCount<newPathsContainer.length;jCount++){
               var oldPathValue = '"'+newPathsContainer[jCount]+'"';  
               var regExpCheck = new RegExp(escapeRegExp(oldPathValue),"g");
               newContent = newContent.replace(regExpCheck,newPathsContainer[jCount]);
    }
	fs.writeFile("ExcelOutput/log.txt","",function(err) {
		if(err) {return console.log(err);}
	});
    writeToFile(file,newContent);  
    
}