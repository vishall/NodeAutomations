// Please don't use this automation until you are sure about this code
var beautify = require('js-beautify');
var fs = require('fs');
var pathRegExp = /\$\{(.*?)\}/g;
var modifiedPathregExp = /\"\$\{(.*?)\"\}/g;

require.extensions['.json'] = function(module, filename) {
    module.exports = fs.readFileSync(filename, 'utf8');
};
var recursive = require('recursive-readdir');

var newPathsContainer = [],
    conditionNewArray = [],
    conditionRefurbArray = [];
recursive('C:/Kanban/Kanban/catalogueData/accessories/', function(err, files) {
    var allJsonFiles = files.filter(function(file) {
        return file.substr(-5) === '.json';
    });
    allJsonFiles.forEach(function(file) {
        checkStandard(file);
		 var imagesArray = ["listSingle", "listHalf", "listDouble", "details", "tariff", "basket", "side", "back"];
                for (var img = 0; img < imagesArray.length; img++) {
                    if (json["images"]["standard"][imagesArray[img]]) {
                        if (json["images"]["standard"][imagesArray[img]].indexOf("image") === -1) {
                            json["images"]["standard"][imagesArray[img]] = "" + "${image('" + json["images"]["standard"][imagesArray[img]] + "')}";
                        } 
                    }
                }
				var fileNewContent = JSON.stringify(json);
					convertBacktoOriginalState(fileNewContent, file, newPathsContainer);
    });
});

function checkStandard(file) {
    var content = require(file);
    var newContent = content;
    var newSearch = newContent.match(pathRegExp);
    if (newSearch != null) {
        var uniqueArray = newSearch.filter(function(elem, pos) {
            return newSearch.indexOf(elem) == pos;
        });
        for (var jCount = 0; jCount < uniqueArray.length; jCount++) {
            var planPathValue = '"' + uniqueArray[jCount] + '"';
            var regExpCheck = new RegExp(escapeRegExp(uniqueArray[jCount]), "g");
            newPathsContainer.push(uniqueArray[jCount]);
            newContent = newContent.replace(regExpCheck, planPathValue);
            var doubleQuoteRegEx = new RegExp(escapeRegExp('""$'), "g");
        }
        json = JSON.parse(newContent);
    } else {
        json = JSON.parse(newContent);
    }
    return json;
}

function writeToFile(file, content) {
    fs.writeFile(file, content, function(err) {
        if (err) {
            console.log(err);
        }
    });
}

function convertBacktoOriginalState(newContent, file, newPathsContainer) {
    var originalState;
    newContent = beautify(newContent, {
        indent_size: 3,
        "preserve_newlines": false,
        "keep_array_indentation": true
    });
    for (var jCount = 0; jCount < newPathsContainer.length; jCount++) {
        var oldPathValue = '"' + newPathsContainer[jCount] + '"';
        var regExpCheck = new RegExp(escapeRegExp(oldPathValue), "g");
        newContent = newContent.replace(regExpCheck, newPathsContainer[jCount]);
    }
    writeToFile(file, newContent);
}

function escapeRegExp(str) {
    return str.replace(/[\-\[\]\/\{\}\(\)\*\+\?\.\\\^\$\|]/g, "\\$&");
}