var beautify = require('js-beautify');
var fs = require('fs');
//var prettyjson = require('prettyjson');
var options = {
  noColor: true
};

    merchPricesSheetURL = 'D:/NodeAutomations-master/NodeAutomations-master/ExcelOutput/pgpricechange.xlsx',
    payGSKUCellColumn = 'A',payGPriceCellColumn = 'B',
    payGTab_Min_Count = 1,payGTab_Max_Count = 236;
    
    var XLSX = require('xlsx'),excelbuilder = require('excel4node');






    var tariffUpsell = "D:/IdeaProjects/productCatalogueData_Master2/catalogueData/media/attachments/common/tariffUpsell.txt";
    
    fs.readFile(tariffUpsell, 'utf8', function (err,data) {
      if (err) {
        return console.log(err);
      }
        
        
        
        data = JSON.parse(data);
        var objectLen = Object.keys(data).length;
        console.log(objectLen);
        //console.log(data.tariffRows[0]);
        for (var x in data) {
            
            for (var y in data[x].tariffRows){
            
            if(data[x]["tariffRows"][y].hasOwnProperty('dataAllowanceId')){
                //data[x]["tariffRows"][y].upfrontCostInPence  = parseInt(data[x]["tariffRows"][y].upfrontCostInPence);
				delete data[x]["tariffRows"][y].dataAllowanceId;
				//console.log(data[x]["tariffRows"][y].upfrontCostInPence);
            }
                
                
        }
        }
        data=JSON.stringify(data);
       data = beautify(data, { indent_size: 2 }); 
       writeToFile(tariffUpsell,data); 
           
    });




function writeToFile(file,content){
  fs.writeFile(file, content, function(err) {
    if(err) {
        console.log(err);
    } else {
       
        console.log("Modified File");
        
    }
});
     
}
